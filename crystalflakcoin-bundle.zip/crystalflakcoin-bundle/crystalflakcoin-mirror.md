---
title: "CrystalFlakCoin is now live on the web — without the parts that aren't"
description: "A digital asset project goes from repository to deployed site. The token contract is still to be announced."
published: "2026-09-15"
tags: ["launch", "transparency", "web3", "ethereum", "digital-asset", "nextjs"]
---

## TL;DR

- A public site and a role-gated admin panel for CrystalFlakCoin (CFC) are live and verifiable; the source is in a public GitHub organization.
- The token contract, swap, staking program, audit, and multisig treasury are all **not yet announced** — and the UI says so on every page that touches them.
- A repository-wide brand scanner fails the build if anyone (including the team) reintroduces forbidden terms, fake stats, or recruitment-style copy.
- This site does not constitute financial advice. We never sell tokens, accept investment, or promise returns.

---

> These are features of the project, not bugs: "honest by design" means the things which do not yet exist are labeled, in the UI, as not yet existing.

---

## Risks

Digital assets are volatile. This site does not constitute financial advice, an offer to sell securities, or a solicitation in any jurisdiction. Nothing here is investment, legal, or tax advice; you may lose some or all of the value of any assets you hold. Never share your seed phrase or private key with anyone, and always verify a contract address on a public block explorer before interacting with it.

## What we built

A public website and admin panel for the [CrystalFlakCoin (CFC)](https://9mqcfm3l5y3.space.minimax.io) project, on Next.js 14, TypeScript, Tailwind, Prisma, and `wagmi`/`viem`. We are not claiming the project is finished; what is on screen is the truth, including the parts that say "not yet" out loud.

In concrete terms:

- **A public site of fifteen routes** — `/`, `/about`, `/token`, `/tokenomics`, `/ecosystem`, `/swap`, `/stake`, `/governance`, `/transparency`, `/docs`, `/faq`, `/legal`, `/contact`, `/connect`, and `/daily-prize`. Each page that touches tokens, staking, or swapping carries a co-located risk disclosure.
- **A role-gated admin panel** at `/admin`, with Argon2id password hashing, `iron-session` cookies, double-submit CSRF, per-IP rate limiting, Zod validation, and an append-only audit log.
- **A daily spin / prize feature** at `/daily-prize`, with the randomness source abstracted in a `RandomnessConfig` table so it can later migrate to commit–reveal or Chainlink VRF. Prizes are not yet disbursed; the page renders "not yet active" until they are.
- **A legacy-brand scanner** that walks the repository in CI and fails the build if anyone reintroduces a forbidden brand reference or a misleading financial claim. It runs on every `prebuild`, before `next build`.
- **A verified deployment** accompanied by `DEPLOYMENT.md`, a `Dockerfile` + `docker-compose.yml` for local development, a [`SECURITY.md`](https://9mqcfm3l5y3.space.minimax.io/transparency) covering in-scope and out-of-scope controls, and an [`ADMIN_GUIDE.md`](https://9mqcfm3l5y3.space.minimax.io/docs) for non-technical operators.

That is the entire scope of this launch. The site is the deliverable; the token is not.

## What's not built yet

We would rather list the missing pieces here than have you discover them on the site. The following are **to be announced**:

- **The CFC token contract itself.** The web platform is read-mostly; it has no authority to pause, upgrade, or recover a deployed contract. There is no on-chain contract to inspect yet, and the site says so on `/token` and `/transparency`.
- **The actual swap.** The `/swap` page is built and visible, but disabled by feature flag until a verified liquidity pool exists. No fake depth chart, no fake price.
- **The actual staking program.** The `/stake` page is built and visible, but disabled, and says "Staking is not yet available."
- **The audit report.** The transparency page renders "Not available" rather than waving at a PDF of unclear provenance. A real audit from a named firm will be linked when one exists.
- **A public multisig treasury with named signers.** Not yet announced. The team is also not yet public.

## Why we built it this way

Most token sites have three tells: a fake APY, a fake partnership, and a "we never share your keys" disclaimer followed immediately by a custodial deposit flow. We have built a site with none of those.

The brand scanner is the most visible part of the discipline: if any contributor — including us — adds a sentence that drifts toward shadiness, the build fails. Every page that touches tokens, staking, or swapping has a co-located risk disclosure, and the FAQ answers the questions we wish more projects would — no investment, no promised returns, no trading bot, no recruitment compensation.

The no-fake-stats policy is the third part. The platform has no live market data because there is nothing to measure yet, and the UI does not invent numbers. The five tokenomics buckets render as "Not configured" until configured, and the server rejects any allocation set whose percentages do not sum to exactly one hundred. A constraint enforced in code is harder to forget than a constraint written in a brand guide.

## How to try it

- **Live site:** [https://9mqcfm3l5y3.space.minimax.io](https://9mqcfm3l5y3.space.minimax.io)
- **Documentation:** [https://9mqcfm3l5y3.space.minimax.io/docs](https://9mqcfm3l5y3.space.minimax.io/docs)
- **Source code:** the GitHub organization linked from [`/transparency`](https://9mqcfm3l5y3.space.minimax.io/transparency)

## How to verify

- **[Security policy](https://9mqcfm3l5y3.space.minimax.io/transparency)** — in-scope controls, response-time commitments, out-of-scope threats, and the disclosure contact.
- **[Admin guide](https://9mqcfm3l5y3.space.minimax.io/docs)** — the operator manual for non-technical admins.
- **Brand scanner** — `scripts/legacy-brand-scan.mjs` runs in `prebuild`; the deny-list is mirrored in `src/lib/brand.ts`. Run `npm run brand:scan` to reproduce.
- **Daily-prize / history verification:** [https://9mqcfm3l5y3.space.minimax.io/daily-prize](https://9mqcfm3l5y3.space.minimax.io/daily-prize). The schema is designed so that, when randomness migrates on-chain, every historical spin remains verifiable against the on-chain commit.

## What's next

A short, honest list:

- **Token contract deployment** on Sepolia first, then Ethereum mainnet. The address will be published in `/transparency` the moment the deployment transaction confirms, and the source will be verified on a public block explorer.
- **A named audit** from a recognized firm, with a public report linked from `/transparency` and `SECURITY.md`.
- **A multisig treasury** with named signers and a published threshold.
- **Raffle / prize draws** against verified on-chain randomness, only after the contract is deployed and the audit is in hand.

## Disclaimer

CrystalFlakCoin is a digital asset project. It is not an investment vehicle, securities offering, or financial product, and is not registered as a security in any jurisdiction. Digital assets are volatile and subject to market, technical, regulatory, and operational risk; you may lose some or all of the value of any assets you hold. Never share your seed phrase or private key with anyone, and always verify contract addresses on a block explorer before interacting.

## Funding

This project accepts voluntary donations via GitHub Sponsors, Open Collective, and direct crypto. See `/donate` for details. We never sell tokens, accept investment, or promise returns. Donations are gifts, not purchases; nothing is minted or promised in return. Surplus funds are held in the treasury and reported on `/transparency`.

## About CrystalFlakCoin

CrystalFlakCoin is a small, self-funded digital asset project. We are publishing on Mirror because this audience knows what a working site looks like versus a marketing screenshot, and because Arweave-permanent storage is the right home for a post we expect to be quoted long after the launch hype cycle is over. If we disappear, the post and the source still resolve.

Three working principles, in order: (1) say what is built and what is not, in the UI itself; (2) ship the boring infrastructure — security model, brand scanner, no-fake-stats policy — before the on-chain parts; (3) treat the reader's attention and capital with the same care we would want for our own.
