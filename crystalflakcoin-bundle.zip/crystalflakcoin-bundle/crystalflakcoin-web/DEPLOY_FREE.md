# CrystalFlakCoin — Free Deployment Guide

This guide explains how to deploy the public **CrystalFlakCoin (CFC)** marketing
site and the lightweight admin / daily-prize surface to a free-tier host, with
zero monthly cost. It is intentionally narrow: production-grade concerns (backups,
secrets, monitoring, custom domains, paid tiers) are covered in
[`DEPLOYMENT.md`](./DEPLOYMENT.md).

> **What this is not.** This is not a guide for deploying the on-chain CFC token
> contract, and it is not legal, financial, or tax advice. Nothing on the
> deployed site promises returns; values shown to the user are sourced from
> either the database or a "not yet deployed" placeholder. See
> `src/app/page.tsx` and `next.config.mjs` for how the UI is wired.

---

## 0. Before you start

You need exactly one thing:

- **A GitHub account** with the ability to push to a new (or existing) repository
  containing this code. The free tiers of all three providers below are tied
  to a Git repository, so this is not optional.

You do **not** need:

- A credit card. All three providers below have a free tier that is sufficient
  for the marketing site, with the caveats in §6.
- A domain name. You can ship on a `*.vercel.app`, `*.netlify.app`, or
  `*.pages.dev` subdomain and add a custom domain later.
- A managed database for the first deploy. The public marketing pages work
  with no database — they render "not yet deployed" placeholders for any
  value that has not been published yet (see `src/lib/env.ts` and
  `prisma/schema.prisma`). Add a database later when you turn on the daily
  prize or the admin surface.

The full list of environment variables the application reads is in
[`.env.example`](./.env.example). You will set them in the host's dashboard,
not in a `.env` file in the repo.

---

## 1. Vercel (recommended default)

Vercel is built and maintained by the team behind Next.js. Free tier is enough
for the marketing site. The application has `output: 'standalone'` in
`next.config.mjs`, but Vercel ignores that and uses its own serverless output
— no code change required.

### 1.1 Steps

1. **Push the repo to GitHub** if it is not already there.
   ![Step 1 placeholder — GitHub new-repo screen]

2. **Sign in to Vercel** at <https://vercel.com> with the same GitHub account.
   Click **Add New → Project** and import the `crystalflakcoin-web` repository.
   ![Step 2 placeholder — Vercel "Import Git Repository" screen]

3. **Configure the project.** Vercel auto-detects the framework as Next.js.
   The `vercel.json` in the repo already pins the build command to
   `prisma generate && npm run build`, the install command to `npm ci`, and
   the region to `iad1`. You do not need to change anything on this screen.
   ![Step 3 placeholder — Vercel "Configure Project" screen with Framework Preset = Next.js]

4. **Add environment variables** before the first deploy. Open
   **Settings → Environment Variables** and add (at minimum) the values below.
   For the marketing-only first deploy, you can leave the database, admin, and
   SMTP variables empty — the UI will render placeholders.

   | Variable | Value (example / note) |
   | --- | --- |
   | `NODE_ENV` | `production` |
   | `NEXT_PUBLIC_APP_URL` | the URL Vercel shows on the project page, e.g. `https://crystalflakcoin.vercel.app` |
   | `NEXT_PUBLIC_APP_NAME` | `CrystalFlakCoin` |
   | `NEXT_PUBLIC_TOKEN_SYMBOL` | `CFC` |
   | `NEXT_PUBLIC_TOKEN_NAME` | `CrystalFlakCoin` |
   | `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | get one free at <https://cloud.walletconnect.com> |
   | `NEXT_PUBLIC_BLOCK_EXPLORER_URL` | `https://etherscan.io` (or the network you publish on) |
   | `SESSION_PASSWORD` | `openssl rand -base64 32` — required to be ≥ 32 chars (`src/lib/env.ts` validates this) |
   | `DATABASE_URL` | leave blank for the marketing-only first deploy, or paste a Neon/Supabase URL — see §1.2 |
   | `DIRECT_DATABASE_URL` | same as above, or blank |

   The complete canonical list (with `CHANGE_ME` defaults) is in
   [`.env.example`](./.env.example).

5. **Click Deploy.** The first build runs `prisma generate` (via the build
   command) and then `next build`. Once it finishes, Vercel assigns a URL.
   Visit `https://<your-project>.vercel.app/api/health` — you should see a
   JSON response with `"status": "ok"`. If `db: false`, the database is not
   configured; the marketing pages will still render correctly.
   ![Step 5 placeholder — Vercel deployment success screen]

### 1.2 Where to get a free PostgreSQL database

Vercel does not bundle a database on the free tier. The two well-trodden
free paths for Postgres that work with `prisma/schema.prisma` are:

- **Neon** — <https://neon.tech>. Free tier includes a Postgres branch with
  a generous compute allowance. The connection string looks like
  `postgresql://user:pass@ep-xxx.us-east-1.aws.neon.tech/neondb?sslmode=require`.
  Set both `DATABASE_URL` and `DIRECT_DATABASE_URL` to this value (the
  `directUrl` field in `prisma/schema.prisma` exists for pooler/transaction
  mode separation; setting both to the same string works on free tier).
- **Supabase** — <https://supabase.com>. Free tier includes a Postgres
  instance. Use the **direct connection** string (port `5432`), not the
  pooler, for `DIRECT_DATABASE_URL`.

Either way, the first time you set `DATABASE_URL`, run the migrations from
your laptop (or from the Vercel build) once:

```bash
DATABASE_URL="<paste-connection-string>" npx prisma migrate deploy
```

After that, every new build runs `prisma generate` automatically; you only
need to re-run `migrate deploy` when you add a new migration file.

### 1.3 First-deploy verification

- `/` — home page renders the hero and the "not yet deployed" contract
  placeholder if `NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS` is empty.
- `/token` — token page renders placeholders for everything that is not set.
- `/daily-prize` — renders the spin UI; the spin endpoint at
  `src/app/api/daily-prize/spin/route.ts` requires a database, so the
  button will return an error until `DATABASE_URL` is set. The page itself
  is still served.
- `/admin` — renders a "Database not configured" message until `DATABASE_URL`
  is set.
- `/api/health` — returns JSON with `db: true` once the database is wired.

---

## 2. Netlify

Netlify supports Next.js 14 through the official `@netlify/plugin-nextjs`
plugin, which is already declared in [`netlify.toml`](./netlify.toml). The
free tier includes 100 GB of bandwidth and 125k serverless function requests
per month, which is more than enough for the marketing site.

### 2.1 Steps

1. **Push the repo to GitHub** (same as Vercel §1.1 step 1).
   ![Step 1 placeholder — GitHub new-repo screen]

2. **Sign in to Netlify** at <https://app.netlify.com> with GitHub.
   Click **Add new site → Import an existing project → GitHub** and select
   the repo.
   ![Step 2 placeholder — Netlify "Import from Git" screen]

3. **Configure the build.** The `netlify.toml` in the repo already sets
   `command = "npm run build"`, `publish = ".next"`, the
   `@netlify/plugin-nextjs` plugin, and `NODE_VERSION = "20"`. Netlify
   should detect this file and pre-fill the build settings. Confirm:
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
   - **Functions directory:** leave blank (the Next.js plugin manages it)
   ![Step 3 placeholder — Netlify "Site settings" build panel]

4. **Add environment variables** under **Site settings → Environment
   variables**. The same set as Vercel §1.1 step 4 applies, plus
   `NODE_VERSION = "20"` and `NPM_VERSION = "10"` (already in
   `netlify.toml` but you can also set them in the UI).
   ![Step 4 placeholder — Netlify environment variables screen]

5. **Click Deploy site.** The first build will install dependencies with
   `npm ci`, run the plugin, and produce a `.next/` output. The
   `pages_build_output_dir` is handled by the plugin; you do not need to
   touch Functions configuration. The site is live at
   `https://<site-name>.netlify.app`. Visit `/api/health` to confirm.
   ![Step 5 placeholder — Netlify deploy success screen]

### 2.2 Database on Netlify

Netlify does not bundle a Postgres database. Use the same Neon or Supabase
free tier as in §1.2. Set `DATABASE_URL` and `DIRECT_DATABASE_URL` in
**Site settings → Environment variables** and run `prisma migrate deploy`
from your laptop pointing at the same connection string.

---

## 3. Cloudflare Pages

Cloudflare Pages free tier is generous: unlimited bandwidth, 500 builds per
month, and 100k Workers requests per day. The trade-off is that the standard
Next.js build does not run on Cloudflare's edge by default — you need the
[`@cloudflare/next-on-pages`](https://github.com/cloudflare/next-on-pages)
adapter, which is **not** installed in this repo by default. You have two
options:

- **A. Static export (simplest, no DB).** If you do not need the admin
  surface or the daily-prize endpoints to be live yet, you can run `next
  build` and Cloudflare will serve the static pages. This is what
  [`wrangler.toml`](./wrangler.toml) is configured for out of the box.
- **B. Full Next.js on Pages (opt in).** Install the
  `@cloudflare/next-on-pages` adapter as a dev dependency, add a build
  command, and remove (or conditionally set) `output: 'standalone'` in
  `next.config.mjs`. This is the path that supports the API routes and
  server components on Cloudflare's runtime.

### 3.1 Steps — path A (static marketing site)

1. **Push the repo to GitHub.**
   ![Step 1 placeholder — GitHub new-repo screen]

2. **Sign in to Cloudflare** at <https://dash.cloudflare.com>, open
   **Workers & Pages → Create application → Pages → Connect to Git**, and
   select the repository.
   ![Step 2 placeholder — Cloudflare Pages "Connect to Git" screen]

3. **Configure the build.**
   - **Framework preset:** Next.js
   - **Build command:** `npm run build`
   - **Build output directory:** `.next`
   - **Root directory (advanced):** leave blank
   - **Environment variables:** add the same set as Vercel §1.1 step 4.
   The `wrangler.toml` in the repo pins the compatibility date
   (`2024-09-01`) and flag (`nodejs_compat`) that the runtime uses; you
   do not need to touch those for a static export.
   ![Step 3 placeholder — Cloudflare Pages "Build settings" screen]

4. **Click Save and Deploy.** The first build runs `prisma generate` (via
   the `npm run build` script in `package.json`) and then `next build`.
   The site is live at `https://<project>.pages.dev`. `/api/health` may
   return a 404 in path A because the API routes are not part of the static
   export — that is expected.
   ![Step 4 placeholder — Cloudflare Pages deployment success screen]

5. **(Optional) Add a custom domain** under **Custom domains** in the
   project settings. Cloudflare provisions the certificate automatically.

### 3.2 Steps — path B (full Next.js with the adapter)

> **Why this is opt-in.** The adapter is actively maintained and works well,
> but it is an extra moving piece. If you do not need the API routes live
> yet, path A is the simpler choice.

```bash
npm install --save-dev @cloudflare/next-on-pages
```

Then, in `next.config.mjs`, gate the standalone output on an env var:

```js
const nextConfig = {
  // ...
  output: process.env.CFC_DEPLOY_TARGET === 'docker' ? 'standalone' : undefined,
  // ...
};
```

And in Cloudflare Pages build settings, set:

- **Build command:** `npx @cloudflare/next-on-pages@1`
- **Build output directory:** `.vercel/output/static`
- **Environment variable:** `CFC_DEPLOY_TARGET` is **not** set (so
  `output: 'standalone'` is skipped).

After the build, the adapter produces a `.vercel/output/` directory that
Cloudflare Pages can deploy. See the adapter's README for the full flow.

### 3.3 Database on Cloudflare Pages

Same as Vercel / Netlify: use Neon or Supabase free tier, set
`DATABASE_URL` / `DIRECT_DATABASE_URL` in **Settings → Environment
variables**, and run `prisma migrate deploy` from your laptop.

---

## 4. Switching providers later

The three providers in this guide are interoperable. The repo does not
contain provider-specific code in the application source — only in the
config files at the root:

- `vercel.json` (Vercel)
- `netlify.toml` (Netlify)
- `wrangler.toml` (Cloudflare Pages / Workers)

To switch from one to another:

1. **Sign in** to the new provider with the same GitHub account.
2. **Import the same repository.** The build settings are pre-baked in
   the corresponding config file (`vercel.json`, `netlify.toml`, or
   `wrangler.toml` + dashboard build settings).
3. **Copy the environment variables** from the old provider's dashboard to
   the new one. The variable names are the same (they are defined in
   [`.env.example`](./.env.example)).
4. **Re-point your custom domain** if you use one. DNS is the only piece
   that has to move.
5. **Decommission the old project** once you confirm the new one is
   healthy (`/api/health` returns `status: ok`).

The application code, the database schema, and the data itself do not
need to change. Migrations are committed to the repo
(`prisma/migrations/`) and applied on whichever host you point at.

---

## 5. Cost summary

| Provider | Marketing site | + free Postgres (Neon) | + free Postgres (Supabase) |
| --- | --- | --- | --- |
| Vercel | $0 / month | $0 / month | $0 / month |
| Netlify | $0 / month | $0 / month | $0 / month |
| Cloudflare Pages | $0 / month | $0 / month | $0 / month |

The "marketing site" row assumes you are not running the daily-prize or
the admin surface yet (see §6 for the caveat). Once you turn those on,
the free-tier limits to watch are:

- **Vercel** — 100 GB egress / month, serverless function execution
  timeout 10 s on the free tier (overridden to 30 s for `src/app/api/**`
  in `vercel.json`, but the per-function cap still applies to the
  underlying serverless invocation).
- **Netlify** — 100 GB egress / month, 125k function invocations / month.
- **Cloudflare Pages** — unlimited egress, 500 builds / month, 100k
  Workers requests / day. No hard egress cap is the main differentiator
  here for a read-mostly site.

If you outgrow the free tier, the next step on any of the three is a
paid plan. None of that is required for the public site as it is
shipped today.

---

## 6. The database question — when do you need it?

The marketing site is built to **work without a database**. The
`prisma/schema.prisma` defines the full data model (users, roles, daily
spins, raffles, governance, content, etc.), but the public pages only
read from the database for things that have not been published yet. If
the value is missing or empty, the UI renders a "not yet deployed" or
"to be announced" placeholder — see `src/lib/env.ts` and
`src/components/layout/risk-disclaimer.tsx` for the disclosure language.

Concretely:

| Feature | Needs a database? | What you see without one |
| --- | --- | --- |
| `/`, `/about`, `/token`, `/ecosystem`, `/docs`, `/faq`, `/governance`, `/transparency`, `/legal` | No | The static content from the repo, with placeholders for unpublished values. |
| `/daily-prize` page (the UI) | No | The page renders. The **spin** button returns a 500 because `src/app/api/daily-prize/spin/route.ts` queries the DB. |
| `/api/daily-prize/*` endpoints | Yes | 500 / "database not configured". |
| `/admin` (login, content, token, tokenomics, daily-prize admin, raffle draw) | Yes | The login page renders. Authentication and all data paths fail until `DATABASE_URL` is set. |
| `/api/health` | No (but reports DB status) | Always returns `status: ok`; `db` is `false` if not configured. |

So you can ship a useful marketing site to any of the three providers
without setting up a database. The moment you want the daily prize
or the admin to work, wire up Neon or Supabase as described in §1.2.

---

## 7. References

- Application source: `src/app/`, `src/components/`, `src/lib/`.
- Prisma schema: [`prisma/schema.prisma`](./prisma/schema.prisma).
- Environment variable catalog: [`.env.example`](./.env.example).
- Build scripts: [`package.json`](./package.json) — `dev`, `build`,
  `start`, `prisma:generate`, `prisma:migrate`, `prisma:deploy`, `db:seed`.
- Security headers (source of truth): [`next.config.mjs`](./next.config.mjs).
- Production deployment (paid tiers, monitoring, backups):
  [`DEPLOYMENT.md`](./DEPLOYMENT.md).
- Admin operations: [`ADMIN_GUIDE.md`](./ADMIN_GUIDE.md).
- Security policy and reporting: [`SECURITY.md`](./SECURITY.md).
