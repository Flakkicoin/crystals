/**
 * CrystalFlakCoin — Database seed
 * Run with: `npm run db:seed`
 *
 * Seeds the default roles and a TokenMetadata row.
 * It does NOT seed fake tokenomics numbers or fake contract addresses —
 * those must be supplied through the admin panel.
 */
import { PrismaClient } from '@prisma/client';
import argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  // Roles
  const roles = [
    {
      name: 'ADMIN',
      permissions: [
        'token:read', 'token:write',
        'tokenomics:read', 'tokenomics:write',
        'content:read', 'content:write',
        'announcement:read', 'announcement:write',
        'logs:read',
        'networks:read', 'networks:write',
      ],
    },
    { name: 'EDITOR', permissions: ['content:read', 'content:write', 'announcement:read', 'announcement:write'] },
    { name: 'VIEWER', permissions: ['token:read', 'tokenomics:read', 'content:read', 'announcement:read', 'logs:read'] },
  ];
  for (const r of roles) {
    await prisma.role.upsert({
      where: { name: r.name },
      update: { permissions: r.permissions },
      create: r,
    });
  }

  // Default TokenMetadata row — clearly marked as not deployed
  const existing = await prisma.tokenMetadata.findFirst();
  if (!existing) {
    await prisma.tokenMetadata.create({
      data: {
        name: 'CrystalFlakCoin',
        symbol: 'CFC',
        decimals: 18,
        isDeployed: false,
        description: 'Token metadata is not yet finalized. Update through the admin panel once the contract is deployed and verified.',
        updatedBy: 'system',
      },
    });
  }

  // Default supported networks
  const networks = [
    { chainId: 1, name: 'Ethereum Mainnet', shortName: 'Ethereum', rpcUrl: 'https://eth.publicnode.com', explorerUrl: 'https://etherscan.io', isTestnet: false, enabled: true },
    { chainId: 11155111, name: 'Sepolia Testnet', shortName: 'Sepolia', rpcUrl: 'https://ethereum-sepolia-rpc.publicnode.com', explorerUrl: 'https://sepolia.etherscan.io', isTestnet: true, enabled: true },
  ];
  for (const n of networks) {
    await prisma.supportedNetwork.upsert({
      where: { chainId: n.chainId },
      update: n,
      create: n,
    });
  }

  // Default RandomnessConfig
  const existingRandom = await prisma.randomnessConfig.findFirst();
  if (!existingRandom) {
    await prisma.randomnessConfig.create({
      data: {
        source: 'server',
        description: 'Server-issued 32-byte seed combined with wallet + UTC date. Seeds are recorded in the audit log. Future versions will support commit-reveal and Chainlink VRF.',
        updatedBy: 'system',
      },
    });
  }

  // Bootstrap admin (only if env provided and no admin exists yet)
  const email = process.env.ADMIN_BOOTSTRAP_EMAIL;
  const password = process.env.ADMIN_BOOTSTRAP_PASSWORD;
  if (email && password && !email.includes('CHANGE_ME')) {
    const adminRole = await prisma.role.findUnique({ where: { name: 'ADMIN' } });
    const existingAdmin = await prisma.user.findFirst({ where: { roleId: adminRole!.id } });
    if (!existingAdmin) {
      const hash = await argon2.hash(password, { type: argon2.argon2id });
      await prisma.user.create({
        data: {
          email,
          passwordHash: hash,
          roleId: adminRole!.id,
        },
      });
      console.log(`[seed] Bootstrap admin created: ${email}`);
      console.log('[seed] IMPORTANT: change the password on first login.');
    }
  } else {
    console.log('[seed] Skipping admin bootstrap (env not set or contains placeholder).');
  }

  console.log('[seed] Done.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
