# Monetization policy

> Internal policy for the CrystalFlakCoin project. This document is the source of
> truth for what the project does and does not do to fund itself. Any change to
> the rules below requires a pull request and an entry in `CHANGELOG.md`.

## 1. What we do

CrystalFlakCoin is a transparent, open-source digital asset project. The only
funding the project accepts is **voluntary, non-refundable support** from
individuals and organizations that want the project to exist. The allowed
channels are:

- **Voluntary donations** through GitHub Sponsors, Open Collective, and direct
  crypto (BTC, ETH) to addresses published on the official `/donate` page.
- **Grants from public-goods funders**, e.g. Gitcoin Grants, Octant, or
  comparable retroactive-funding programs whose mission is open-source
  public-goods support. Grant applications are reviewed by the maintainers
  before submission.
- **Newsletter sponsorships**, only once the newsletter has a substantial
  readership, and only with sponsors that are clearly disclosed at the top
  of the issue. Sponsored content is labeled as such; it is never disguised
  as editorial.

Each of these is opt-in for the donor, has no return commitment, and is
fully accounted for in the public ledger (Open Collective) and in the
annual transparency report.

## 2. What we never do

The following monetization methods are explicitly forbidden for the
CrystalFlakCoin project. This list is **not** aspirational; it is enforced.

| Forbidden method | Why it is forbidden |
| --- | --- |
| Token sale, ICO, IEO, IDO, presale, or any primary token offering | Would make CFC a securities offering in most jurisdictions and contradicts the project's stated purpose. |
| Fundraising round (seed, strategic, private) of any kind | Would make the project a venture-backed entity with investor obligations, not a transparent community project. |
| Token allocation, whitelist, or airdrop tied to a contribution | Would make the contribution a purchase, not a donation, and would attach a return expectation to a contribution. |
| NFTs issued for fundraising | The same reasoning as a token sale, plus the additional reputational and legal risk of treating fundraisers as collectibles. |
| Paid "premium" tier that gates information, documentation, or tooling | Information gating is incompatible with the project's transparency principle. |
| Paid course, paid tutorial, paid "masterclass", or paid membership | Same. The project's purpose is to be open and inspectable. |
| Recruitment, multi-level, affiliate, or referral compensation | Recruitment-based compensation is a recognized pyramid pattern. Any structure where a contributor is paid primarily for bringing in new contributors is rejected, regardless of how it is labeled. |
| Trading bot, signal service, copy-trading, or "auto-trader" | None of these exist on this project. The site is not a trading venue and provides no trading strategy. |
| Promised returns, guaranteed profit, "risk-free", "passive income", or "you cannot lose" language | The project does not promise returns of any kind. Such language is incompatible with honest disclosure. |
| Win-rate or performance claims ("97% win rate", "best bot", etc.) | The project does not publish performance claims because it does not operate a trading system. |
| Limited-time, urgency-driven financial offers ("act now", "limited spots", "last chance") | Urgency pressure in fundraising is a recognized fraud pattern. |
| "Get rich" framing in any form | The project's purpose is to be a verifiable on-chain primitive, not a vehicle for personal enrichment. |
| Paid promotion, paid influencers, paid reviews, paid KOL endorsements, paid group pumps | Paid promotion is not part of the project's funding model. It is not a line item in the budget and is not a justification for any donation. |
| Accepting funds through any channel not listed in Section 1 | New channels must be added to this document first. |

If a third party claims to be raising funds "for" or "in partnership with"
CrystalFlakCoin, that party is not affiliated with this project. The
official list of funding channels is the `.github/FUNDING.yml` file in
this repository and the `/donate` page of the website. Anything else is
not us.

## 3. How donations are accounted

- **GitHub Sponsors** payouts are processed by GitHub. Each month's
  contribution and recipient breakdown is visible on
  `github.com/sponsors/crystalflakcoin`.
- **Open Collective** is the project's primary ledger. Every contribution
  (incoming) and every expense (outgoing) is published in real time on
  `opencollective.com/crystalflakcoin`. This is the channel used for
  grants and is the channel that grantors should be pointed to.
- **Direct crypto** donations are received at the wallet addresses
  published on the official `/donate` page. Each address is documented in
  this repository's `.github/FUNDING.yml` comment block so that it can be
  cross-referenced against the website. Outgoing transactions from these
  wallets (e.g. to pay for hosting) are not on-chain linked to incoming
  donations; the link is established in the Open Collective ledger.
- **Currency conversion** is recorded at the time of contribution, using
  a published reference rate (e.g. the daily CoinGecko reference, recorded
  in the ledger entry).
- **Donor data** is not sold, rented, or shared with third parties for
  marketing. Aggregate, non-identifying donation statistics may be
  published in the annual transparency report.

## 4. Where the money goes

The project's expense categories, in priority order. This is the same list
that appears on the `/donate` and `/sponsors` pages.

1. **Infrastructure.** Hosting, RPC endpoints, IPFS pinning, monitoring,
   the daily-prize RNG service, and the database behind the transparency
   pages. Recurring. Largest single line item.
2. **Security audits and tooling.** Independent third-party smart-contract
   and full-stack audits, static analysis, fuzzing, dependency scanning.
   Lumpy — we audit when code is ready, not on a marketing timeline.
3. **Contributor compensation.** Time-based or per-milestone, at fair
   market rates, for documentation, translation, design, and reviewed
   code work. Tracked publicly on Open Collective.
4. **Bug-bounty payouts.** Paid to reporters through the public security
   email channel listed on `/transparency`.
5. **Documentation, translation, design.** Reviewed work only; never
   promotional content.
6. **Legal review.** Jurisdictional review, terms, and risk disclosures,
   by independent counsel.
7. **Reserve / contingency.** Maintained to keep the project running
   through a bad quarter. The reserve level is published in the
   transparency report.

The project does not have a marketing budget, a promotion budget, or a
"growth" budget. Any request to fund those categories should be rejected.

## 5. How we report

- **Open Collective** publishes the running ledger continuously.
- **Quarterly update** posted to `/transparency` summarizing: total
  contributions, expense breakdown, reserve level, in-progress work.
- **Annual transparency report** published on the website, covering:
  - Full contribution and expense ledger for the year.
  - Audit status (audited, in-progress, not-yet-scheduled — stated as
    such, not implied).
  - List of grants applied for, received, or rejected.
  - List of contributors and total compensation, with role categories.
  - Aggregate donation statistics (total, count, average, currency mix),
    non-identifying.
  - Incident reports for the year (security, operational, governance).
  - Planned budget for the next year, with the same category breakdown
    as Section 4.

If the report is not published on schedule, that itself is reported.

## 6. No promises

CrystalFlakCoin does not promise, and has never promised:

- A return on any contribution, donation, or support payment.
- Allocation of any kind of token, NFT, airdrop, or governance right to
  a contributor, donor, sponsor, or supporter.
- That the project will succeed, ship, or appreciate in value.
- That a contribution will be used for any specific purpose other than
  the categories listed in Section 4.
- That a contributor, donor, sponsor, or supporter will be credited in
  any particular way (credit is given for reviewed work, not for funding).

Donations are voluntary and non-refundable. The project does not maintain
a refund process because it does not sell anything. If a donation was
sent to the wrong address, the project cannot recover it; this is a
property of public blockchains, not a project decision.

Nothing on this site, in this repository, or in any communication from
the project's maintainers is financial, investment, legal, or tax advice.

## 7. Reporting violations

If you observe the project — or a party claiming to be the project —
engaging in any of the forbidden activities in Section 2, please open a
public issue or email the security contact listed on `/transparency`.

If you observe a third party misrepresenting the project's funding
arrangements, please report the misrepresentation on the official
channels listed on `/contact` so it can be documented and addressed.

---

*This policy is reviewed at least annually. The current version is the
one in the default branch of this repository. Earlier versions are in
the git history.*
