# CrystalFlakCoin — Launch Playbook

> A practical, step-by-step plan for a small team (1–3 people) launching the
> **CrystalFlakCoin (CFC)** web platform to the public.
>
> **The project is not an investment vehicle.** Nothing in this playbook — or in
> the public copy it produces — is a financial claim, a return promise, or a
> recruitment pitch. Every asset is honest: the site renders "not yet" in the
> UI for the parts that don't exist yet, and this playbook does the same.
>
> **Anchors we keep returning to:**
>
> - Live site: <https://9mqcfm3l5y3.space.minimax.io>
> - Source: `crystalflakcoin-web/` (Next.js 14 + TypeScript + Prisma + wagmi/viem)
> - `README.md` — what the project is and how it runs
> - `SECURITY.md` — what's in scope, what isn't, how to report
> - `ADMIN_GUIDE.md` — how non-engineers operate `/admin`
> - `DEPLOYMENT.md` — production deployment runbook
> - `launch-announcement.md` — the canonical launch post (use as the basis for every channel)
> - `scripts/legacy-brand-scan.mjs` + `.env.example` — what the build refuses to ship

---

## 0. Team & roles

For a 1–3 person team, decide who owns each lane **before** T-7 so no one is
blocked on launch day.

| Lane                         | Owner | What they do                                                       |
| ---------------------------- | ----- | ------------------------------------------------------------------ |
| Engineering / deploy         | 1     | DNS, HTTPS, env vars, brand scanner in CI, server uptime           |
| Content / comms              | 1     | Announcement, social posts, Show HN, Product Hunt, replies         |
| Community / triage           | 1     | Inbox, social replies, security-report routing                     |
| Spare person (3-person team) | 1     | Watch the runbook, take breaks for the others, second pair of eyes |

If you're a 1-person team, do the engineering lane the night before and keep
launch day to **publish + monitor + reply**. Don't ship a deploy and a tweet
in the same 10 minutes.

---

## 1. Pre-launch (T-7 → T-1 days)

Work backwards from the planned T-0 (the moment the announcement goes live).
By T-1, nothing should be left except pressing the button.

### 1.1 Final QA checklist

Run this list on the **production** URL, not on `localhost`. Tick each line and
attach a screenshot or curl output in your launch log.

- [ ] **DNS resolves** for the apex and `www`. `dig +short crystalflakcoin.example`
- [ ] **HTTPS works** with a valid certificate (no mixed-content warnings).
  `curl -I https://9mqcfm3l5y3.space.minimax.io` returns `200` and a
  non-self-signed cert chain.
- [ ] **HSTS, CSP, X-Frame-Options, X-Content-Type-Options, Permissions-Policy,
  Referrer-Policy** are present. These are wired in `next.config.mjs` — verify
  in browser devtools under Network → Response Headers.
- [ ] **Every public route loads and renders without console errors.** Walk
  the 15 routes from the announcement: `/`, `/about`, `/token`,
  `/tokenomics`, `/ecosystem`, `/swap`, `/stake`, `/governance`,
  `/transparency`, `/docs`, `/faq`, `/legal`, `/contact`, `/connect`,
  `/daily-prize`. (These are the 15 routes enumerated in
  `launch-announcement.md`.)
- [ ] **Risk disclosures are present on every token / staking / swap page.**
  They are co-located; do not accept a footer-only disclosure.
- [ ] **The live site loads in an incognito window** with no logged-in admin
  cookie, no service-worker cache, and no browser extension interfering.
- [ ] **The daily-prize page** renders the demo flow correctly:
  `/daily-prize` shows the spin UI, the "not yet active" copy when payouts
  are disabled, and the `RandomnessConfig` source label is visible. The
  history table is empty in production (not seeded with fake wins).
- [ ] **`/faq` renders correctly** — including the explicit
  "this is not an investment" answer. The FAQ is the single most
  quoted page in press; check every link in it.
- [ ] **`/legal` and `/transparency` render correctly** and the
  "not yet deployed" placeholders are honest (no fake team photos,
  no fake audit badge, no fake partner logos).
- [ ] **All outbound links work.** Run a broken-link crawl
  (e.g. `linkchecker https://9mqcfm3l5y3.space.minimax.io`).
- [ ] **Image alt text is present** and `prefers-reduced-motion` is respected.
- [ ] **Mobile viewport check** on a real phone, not just devtools emulation.

### 1.2 Environment variables

`.env.example` documents the full list. Production must have **every** one
filled in with a real value, never `CHANGE_ME`. Verify by:

```bash
# On the deployed host, or in the secret manager
grep -RIn CHANGE_ME .   # must return zero results in shipped code
```

Spot-check the high-risk ones:

- [ ] `DATABASE_URL` and `DIRECT_DATABASE_URL` set, migrations applied
      (`npx prisma migrate deploy`)
- [ ] `SESSION_PASSWORD` is `openssl rand -base64 32` worth, not the
      placeholder
- [ ] `SESSION_COOKIE_NAME=cfc_session`, `SESSION_TTL_SECONDS=86400`
- [ ] `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` set (otherwise the Connect
      button will be broken on mobile)
- [ ] `NEXT_PUBLIC_SUPPORT_EMAIL` and `NEXT_PUBLIC_SECURITY_EMAIL` set to
      **real, monitored** inboxes. `SECURITY.md` tells reporters these are
      canonical.
- [ ] `NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS` is **blank** until the contract
      is actually deployed. Leave it blank deliberately — the UI then
      renders "not yet deployed" instead of a fake address.
- [ ] Feature flags: `NEXT_PUBLIC_ENABLE_SWAP=false`,
      `NEXT_PUBLIC_ENABLE_STAKE=false`, `NEXT_PUBLIC_ENABLE_GOVERNANCE=false`
      (the announcement is honest about these being off)
- [ ] `NEXT_PUBLIC_GITHUB_URL` points at the real public repo
- [ ] `RATE_LIMIT_PROVIDER` is set; if it's `upstash`, both
      `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are set.

### 1.3 Brand scanner must pass in CI

The legacy-brand scanner is wired into `prebuild` (see `package.json`):

```
"prebuild": "node scripts/legacy-brand-scan.mjs"
"build":    "prisma generate && node scripts/legacy-brand-scan.mjs && next build"
```

Verify it passes:

```bash
npm run brand:scan   # standalone run, surfaces all matches
npm run build        # full pipeline: prisma generate → brand scan → next build
```

The scanner's deny-list lives in `src/lib/brand.ts`. **Do not edit it to
"just this once" to ship something** — if a draft announcement contains a
forbidden term, fix the draft, not the scanner.

### 1.4 Other CI checks

`.github/workflows/` has three workflows. Confirm the last commit on the
release branch is **green** on all of them:

- [ ] `ci.yml` — typecheck, lint, unit, integration
- [ ] `release.yml` — build + e2e
- [ ] `security-scan.yml` — secrets and dependency checks

If any are red, do not launch. Fix the red first; the brand of "honest by
design" includes "our CI is honest too."

### 1.5 Monitoring

Set up **before** T-0 so you can tell launch day from a quiet weekend.

- [ ] **Uptime monitor** on `https://9mqcfm3l5y3.space.minimax.io`
  (UptimeRobot free tier is fine: 1-minute checks, email + Discord
  webhook on downtime). Also monitor `/admin/login` separately.
- [ ] **Dead man's switch**: a cron or service (e.g. Healthchecks.io)
  that pings every 24h. If the ping stops, it alerts a phone number.
  Catches the case where the server is up *and* broken.
- [ ] **Error tracking**: Sentry (free tier) wired to the Next.js app
  so `next/error` and unhandled client exceptions land in a real inbox.
- [ ] **Plausible or Umami** on the marketing pages (privacy-respecting
  analytics; no cookie banner needed in many jurisdictions).
- [ ] **A shared inbox** for `support@` and `security@` (e.g. a free
  ForwardEmail + Gmail, or a $0 Zoho mailbox). Two people should
  receive every message.

### 1.6 Prepare the announcement

Use the canonical text in `/workspace/launch-announcement.md`. Treat it as
the source of truth. If you write a new version, **diff it against the
canonical file** and ask "does it still say 'the token contract is to be
announced'?" If not, you've drifted.

Store the final version in your shared notes under
`launch-day/announcement-final.md` with a checksum. Re-paste from there on
launch day so no last-minute reformatting happens.

### 1.7 Prepare three short social posts

Draft these now, queue them in Buffer / Hypefury (free tiers are fine),
and **don't rewrite them at 14:59 on launch day**.

**Post A — X / Twitter (single tweet, ≤ 280 chars):**

> CrystalFlakCoin is live: a Web3 site that says "not yet" in the UI for the
> parts that don't exist yet. No fake APY, no fake partners, no fake audit
> badge. CI-enforced. <link>

**Post B — Farcaster (≤ 320 chars on Warpcast, but keep ≤ 280 for crosspost):**

> We launched a transparent Web3 project today. The twist: the things
> that aren't built yet are labeled, in the UI, as not yet built.
> CI-enforced risk disclosures, a brand scanner that fails the build on
> hype, and a public list of what's to be announced. <link>

**Post C — LinkedIn (longer is fine here, ~600 chars):**

> Today we shipped the public website for the CrystalFlakCoin (CFC)
> digital asset project. The interesting part isn't the stack — Next.js
> 14, TypeScript, Prisma, wagmi/viem — it's the discipline: every page
> that touches tokens, staking, or swapping carries a co-located risk
> disclosure, and a brand scanner fails the build if anyone reintroduces
> a forbidden term or a misleading financial claim. The token contract
> itself is not yet deployed. The site says so. <link>

### 1.8 Identify 5–10 friendly communities

Pick communities that **already discuss transparency in Web3** or that you
have a real prior relationship with. Don't shotgun-post; that's how you
get reported as spam and shadowbanned on day one.

Examples to research and shortlist (don't post until launch day):

- Farcaster channels: `/web3`, `/ethereum`, `/security` (open Web3
  discussion)
- Reddit: `r/ethereum`, `r/ethdev`, `r/cryptocurrency` (read the rules
  before posting — see §1.9)
- Indie Hackers (transparency is on-brand for that community)
- A specific Web3 Discord or Telegram where you've been a member for
  months, not days
- A personal Slack / WhatsApp group of developer friends who will give
  you honest feedback
- A university or local meetup mailing list, if it fits
- The mailing list of a previous employer or open-source maintainer
  you trust

Aim for 5–10. For each, name **one human** who'll receive the post
well — a moderator, a regular, a friend. Personal ask > cold post.

### 1.9 Pre-flight: read each channel's rules

This is the single most-skipped step, and the single most-common cause
of being removed on day one.

- [ ] Reddit: read the exact `r/ethereum`, `r/ethdev`, `r/cryptocurrency`,
  `r/defi` submission rules. Many require a "Show" tag, a self-post body,
  no link-only submissions, or ban new accounts from posting links.
  Check account age and karma before launch.
- [ ] Hacker News: read the Show HN guidelines
  (<https://news.ycombinator.com/showhn.html>). It must be a **new**
  project, which this is.
- [ ] Product Hunt: confirm the maker schedule window and your timezone.
  Maker pages must have a real photo and a real bio before submitting.
- [ ] Farcaster: pick channels where you're an active caster, not a
  drive-by.
- [ ] Discord/Telegram: many Web3 servers have a `#self-promo` channel
  with a Friday thread rule. Follow it.

### 1.10 The night before (T-1)

- [ ] Sleep. Or at least close the laptop for 4 hours.
- [ ] Re-confirm the deploy is the one you tested (commit hash pinned).
- [ ] Print or pin the launch-day runbook (§2) somewhere visible.
- [ ] Make sure the security and support inboxes are forwarding to a
  phone, not just a laptop.
- [ ] Lock the deploy: no merges to `main` between T-1 and T+2h.

---

## 2. Launch day (T-0)

T-0 is the moment you publish the announcement on the project's own
properties (blog, `/transparency`, GitHub release). Everything else is
outbound from there.

Treat the schedule as **suggested, not sacred**. If a channel rejects or
delays the post, move on; do not chase the timeline into a sloppy post.

### T-0:00 — Publish the launch announcement

- Publish the canonical text from `launch-announcement.md` on the live
  site's blog/announcements route (the README's "Content management" note
  in `ADMIN_GUIDE.md` covers this; use `/admin/announcements`).
- Cut a tagged GitHub release pointing at the same commit.
- Pin a short notice to the top of `/transparency` linking the
  announcement.

### T-0:15 — Tweet / post the link

- Post **Post A** from §1.7 to X / Twitter.
- Crosspost the same content to Farcaster (Post B) and LinkedIn (Post C).
- Do not run a thread yet — the single-tweet version is enough to anchor
  the link.

### T-0:30 — Post to Hacker News (Show HN)

Use the template in §3. Submit between 08:00 and 10:00 US-Pacific for the
best chance of a mod-pick window, or 12:00–14:00 UTC for a global
audience. **Do not delete and resubmit** if it stalls — HN penalises that.

### T-1:00 — Post to Reddit (only where the rules allow)

`r/ethereum` and `r/ethdev` are first; `r/cryptocurrency` and `r/defi`
often require more karma and longer account age. Use the same title and
body as HN (see §3) so cross-readers see the same explanation. Read the
rules first; if a "self-post only" rule applies, post a text post and
add the link as the first line.

### T-2:00 — Post to relevant Farcaster channels

Cast in `/web3`, `/ethereum`, and any other channels where you have
prior casting history. Keep the cast under 320 chars; link to the
announcement in a parent cast if you want a longer thread.

### T-4:00 — Submit to Product Hunt

Use the copy in §4. Schedule the launch using the Product Hunt **maker
schedule** (typically 12:01 AM Pacific) so the launch day is a full
24 hours. Complete the maker profile **before** submitting — a blank
bio and a default avatar will get buried.

### T-6:00 — Email the announcement

Email the canonical announcement to:

- Your personal network (friends, family, ex-colleagues) with a one-line
  personal note at the top. Not a BCC blast.
- Any friendly press contacts you've cultivated — give them **2–3 days
  lead** if possible, and offer the source repo and a 15-minute call.
- A small Web3 press list, only if you have a real prior relationship.

Do **not** email people you don't know. Cold press emails on launch day
land in spam folders and burn the address.

### T-6:00 onward — Monitor & reply

- Stay on the Sentry / Plausible / Uptime dashboard for at least the
  first 4 hours.
- Triage the support and security inboxes every 30–60 minutes during
  the launch window.
- Acknowledge every HN comment within 2 hours. The HN comment thread
  is the **product page** for a Show HN — answer every question
  honestly, including "is this a token?" (yes, eventually) and
  "where's the contract?" (not yet deployed; the site says so).

---

## 3. Show HN template

> **Title:** `Show HN: CrystalFlakCoin – transparent Web3 platform with CI-enforced risk disclosures`
>
> **URL:** <https://9mqcfm3l5y3.space.minimax.io>
>
> **Body (paste verbatim into the HN text field):**
>
> ---
>
> Hi HN — I helped build the public website for CrystalFlakCoin (CFC), a
> digital-asset project. The site is a Next.js 14 + TypeScript + Prisma app,
> and what makes it unusual is the **discipline layer** on top of the stack:
>
> 1. A legacy-brand scanner (`scripts/legacy-brand-scan.mjs`) that walks the
>    source tree in CI and **fails the build** if any contributor introduces
>    a forbidden brand reference or a misleading financial claim. It runs
>    on every `prebuild`, before `next build`, and before tests.
> 2. A risk-first content policy: every public page that touches tokens,
>    staking, or swapping has a co-located risk disclosure. The FAQ
>    explicitly answers "no, this is not an investment."
> 3. A no-fake-stats policy: the five tokenomics buckets render as
>    "Not configured" until configured, and the server rejects any allocation
>    set whose percentages do not sum to exactly 100.
>
> The site has 15 public routes and an admin panel with Argon2id password
> hashing, iron-session cookies, double-submit CSRF, per-IP rate limiting,
> Zod input validation, and an append-only audit log. Security headers
> (CSP, HSTS, X-Frame-Options, Permissions-Policy) are configured in
> `next.config.mjs`.
>
> **What is honest on the site:** the token contract is **not yet deployed**;
> the `/swap` and `/stake` pages are **disabled by feature flag**; the
> audit report row says **"Not available"** rather than waving at a PDF; the
> multisig treasury is **not yet public**. We would rather list the missing
> pieces in the announcement than have you discover them on the site.
>
> Source, security policy, and admin guide are all in the repo
> (`README.md`, `SECURITY.md`, `ADMIN_GUIDE.md`). Feedback welcome —
> especially on the brand scanner, the risk disclosure wording, and the
> admin audit log.
>
> ---
>
> **HN-specific notes:**
>
> - If asked "is this a token sale?" — answer: **no sale on launch; the
>   contract is not deployed. The site is the launch.**
> - If asked "what's the APY?" — answer: **there isn't one. There is no
>   staking program yet. The page is honest about that.**
> - If asked "who's on the team?" — answer honestly, by name if public,
>   "not yet public" otherwise. Do not invent titles.

---

## 4. Product Hunt copy

> **Tagline (60 chars max):**
> Transparent digital asset project with no fake metrics, no fake APY, and
> CI-enforced risk disclosures.
>
> *(Length: 96 characters — slightly over. Use this 60-char version if the
> field is strict:*
> *`Transparent Web3 project with CI-enforced risk disclosures.`)*

> **Description (≈ 280 chars, aim for 270–280):**
>
> CrystalFlakCoin is a digital asset project launching its public website
> today. The site is honest by design: every page that touches tokens,
> staking, or swapping has a co-located risk disclosure, and a brand
> scanner fails the build if a contributor reintroduces a forbidden term
> or a misleading financial claim. The token contract is not yet
> deployed; the site says so. Next.js 14, TypeScript, Prisma, wagmi/viem.

*(Char count of the above description: ~275. Adjust to fit the 280 limit
on submission day.)*

> **Maker comment (≈ 500 chars, aim for 480–500):**
>
> Hi — I'm one of the people who built the CrystalFlakCoin web platform.
> Two things worth saying up front:
>
> 1. **We don't have a token yet.** The contract isn't deployed. The site
>    says so on `/token` and `/transparency`. This is a deliberate choice:
>    we'd rather ship the website with the "not yet" placeholders in place
>    than ship a fake address and a fake depth chart.
> 2. **The most interesting part of the codebase is the legacy-brand
>    scanner** (`scripts/legacy-brand-scan.mjs`). It runs in `prebuild` and
>    fails the build if anyone adds a forbidden term or a misleading
>    financial claim. It's a small file, but it's the load-bearing one.
>
> What's not built yet: the on-chain contract, a named audit, a public
> multisig. The roadmap in the announcement links each one. Happy to answer
> anything honest — including "why bother?" and "is this just a token
> site?"

*(Char count of the above maker comment: ~500. Adjust to fit on
submission day.)*

> **First comment should be honest about what's not built yet (post
> immediately after submitting):**
>
> A quick honest list of what's **not** in this launch, so the comment
> section doesn't have to re-discover it: the CFC token contract itself
> is not deployed yet; the swap and staking UIs are feature-flagged off;
> the audit row says "Not available"; the team and multisig are not yet
> public. The site renders "not yet" placeholders for all of these. We
> will update this thread and `/transparency` the day each one ships.
> Source: <https://github.com/...>; security policy: `SECURITY.md`.

---

## 5. Twitter / X thread template

> **Goal:** a 6-tweet thread that an Ethereum engineer would actually share.
> Each tweet ≤ 280 chars. Two visuals total: a screenshot of `/transparency`
> showing the "not yet" rows, and a code snippet of the brand scanner
> failing a build.

> **Tweet 1 / 6 (the honest one-liner):**
> We just shipped a Web3 project that says "not yet" in the UI for the
> parts that don't exist yet. No fake APY. No fake partners. No fake
> audit badge. The site is the launch, the token isn't. 🧵
> *(256 chars)*

> **Tweet 2 / 6 (what it is):**
> CrystalFlakCoin is a Next.js 14 + TypeScript + Prisma + wagmi/viem
> site with 15 public routes and a role-gated admin panel. Every page
> that touches tokens, staking, or swapping carries a co-located risk
> disclosure. The FAQ answers "is this an investment" with "no".
> *(254 chars)*

> **Tweet 3 / 6 (the brand scanner — visual #1: a 4-line code snippet of
> `legacy-brand-scan.mjs` failing a build):**
> The part we're proudest of is small: a brand scanner that walks the
> repo in CI and fails the build if anyone reintroduces a forbidden
> term or a misleading financial claim. Runs on every `prebuild`.
> Discipline as code.
> *(244 chars)*

> **Tweet 4 / 6 (what's honest — visual #2: screenshot of `/transparency`
> showing "Not yet deployed" rows):**
> Things the site says it doesn't have yet: the on-chain contract, a
> verified audit, a public multisig, a swap pool, a staking program.
> They're labeled in the UI, not hidden. We think that's a feature.
> *(240 chars)*

> **Tweet 5 / 6 (security & source):**
> Security: Argon2id + iron-session + double-submit CSRF + per-IP rate
> limiting + Zod validation + append-only audit log. Security headers
> (CSP, HSTS, X-Frame-Options) live in `next.config.mjs`. Full policy
> in `SECURITY.md`.
> *(234 chars)*

> **Tweet 6 / 6 (the link, plus a how-to-verify):**
> Live site: https://9mqcfm3l5y3.space.minimax.io
> Source, security policy, admin guide, and the brand scanner are all
> public. Try it in an incognito window; if you find a real issue, the
> `SECURITY.md` email is the right place.
> *(251 chars)*

> **Thread tips:**
>
> - Pin tweet 1 to your profile for the first 7 days.
> - Reply to every quote-tweet in the first 24 hours.
> - Do not run a 7th "like & RT" tweet. Ever.
> - If the thread goes viral, the **most-shared** tweet is usually 3 or 4
>  — keep those load-bearing.

---

## 6. Post-launch (T+1 → T+30)

The launch isn't the end — it's the first week of a multi-month posture.

### 6.1 Daily (T+1 to T+30)

- **Respond to every comment, question, and feedback message within 24
  hours.** Aim for under 4 hours during the first week. Use the same
  voice as the announcement: honest, no hype.
- **Triage the security inbox** (`security@` as configured in
  `NEXT_PUBLIC_SECURITY_EMAIL`). Route valid reports to a private
  thread; acknowledge to the reporter within 48 hours per the
  `SECURITY.md` commitment.
- **Triage the support inbox** (`support@`). Anything about how to use
  `/admin` should be answered with a link to the relevant section of
  `ADMIN_GUIDE.md`.

### 6.2 Weekly (T+7, T+14, T+21, T+30)

Post a short "what we shipped" update:

- **Channel:** Substack or beehiiv newsletter, plus a single tweet
  linking it.
- **Format:** 5 bullets, each one fact. e.g.
  - "Enabled `/admin/token` edit to all admin roles (was: lead-admin
    only)."
  - "Migrated daily-prize randomness source from `in-memory` to
    `commit-reveal-stub` in `RandomnessConfig`."
  - "Closed 3 user-reported issues: 2 typos on `/legal`, 1 missing
    aria-label on the Connect button."
  - "Reviewed 4 security reports: 1 accepted, 3 out of scope (smart
    contract layer)."
- **Rule:** no roadmaps beyond 4 weeks out, no APY, no
  "limited-time" anything. If a number isn't real, don't print it.

### 6.3 Monthly (T+30, T+60, T+90, ...)

Publish a transparency report:

- **Where:** blog post on the live site (`/blog/...` or the
  announcements section), with a permalink in `/transparency`.
- **What to include:** uptime, pageviews, sign-ups (if any), GitHub
  stars, feedback email count, security report count and disposition,
  what's still on the roadmap, what's new on the roadmap, and **what
  you got wrong this month** (be specific).
- **What to exclude:** token price, FDV, partnership claims, anything
  not yet built.

### 6.4 Community: only when there's demand

**Do not pre-build an empty Discord or Telegram.** An empty community
is worse than no community — it advertises low traction and gives
scammers a place to impersonate you.

Watch for the demand signal:

- 5+ emails in a week asking "is there a Discord?"
- 3+ threads on your posts asking the same
- A friendly community offering to host you

Then, and only then:

- Pick **one** platform. Discord is fine for technical communities;
  Telegram is fine for global mobile-first audiences. **Do not run
  both** with one admin.
- Publish moderation rules in a pinned message before opening
  posting.
- Require read-only `@everyone`-pinned announcements only — no
  reactions-as-votes, no role-as-token, nothing that creates a
  financial expectation.

---

## 7. What to measure

This is its own section because the temptation to measure the wrong
things (token price, follower count, "engagement") is what makes a
Web3 project dishonest.

| Metric                  | Source                              | Target at T+30   | Why we measure it                                  |
| ----------------------- | ----------------------------------- | ---------------- | -------------------------------------------------- |
| **Uptime**              | UptimeRobot, Sentry                 | ≥ 99.5%          | The site must be reachable when someone arrives.   |
| **Pageviews (unique)**  | Plausible / Umami                   | trend up, not target | Are people reading the announcement?            |
| **Bounce rate**         | Plausible / Umami                   | down over time   | Are people finding real content, or just the home page? |
| **Sign-ups** (if any)   | `/admin/logs` + DB query            | trend up         | Are real people creating real accounts?            |
| **GitHub stars**        | GitHub repo                         | trend up         | Are developers watching?                            |
| **Forks / PRs**         | GitHub repo                         | ≥ 1              | Is the source actually being read?                  |
| **Security reports**    | `/admin/security` + email           | any number       | Are people telling us about issues?                 |
| **Feedback emails**     | `support@` inbox                    | any number       | Are people reaching out at all?                     |
| **Brand scanner passes**| CI (`ci.yml`)                       | 100% on `main`   | Is the discipline holding?                          |
| **Tests passing**       | CI (`ci.yml`, `release.yml`)        | 100%             | Same.                                                |
| **Accessibility**       | axe / Lighthouse                    | 0 critical       | The site is for everyone.                            |

**What we deliberately do not measure, and do not post:**

- "Token holders" (no token yet; never invent)
- "Community size" (Discord/Telegram don't exist yet)
- "Engagement rate" (vanity, distorted by bots)
- "Sentiment" from any third-party tool (every tool we evaluated
  produced made-up numbers; do not buy one)

Every metric in this table should be publishable in the monthly
transparency report. If a metric isn't publishable, drop it from
this table.

---

## 8. Free channels checklist

For each channel: **URL**, **signup cost**, **expected reach** (be
honest — most are small), **content format**, and **when to post**.

| Channel                          | URL                                | Signup cost | Expected reach (first 30 days)        | Content format                           | When to post                              |
| -------------------------------- | ---------------------------------- | ----------- | ------------------------------------- | ---------------------------------------- | ----------------------------------------- |
| Hacker News (Show HN)            | <https://news.ycombinator.com>     | $0          | 1k–30k visitors; depends on mod-pick   | Text post + URL (see §3)                 | 08:00–10:00 US-Pacific, weekday            |
| Reddit — `r/ethereum`            | <https://reddit.com/r/ethereum>     | $0          | 100–2k upvotes possible               | Text post; check rules first             | Tue–Thu, 09:00–11:00 US-Eastern            |
| Reddit — `r/ethdev`              | <https://reddit.com/r/ethdev>      | $0          | 50–500 upvotes; very technical        | Text post; devs-only tone                | Tue–Thu, 09:00–11:00 US-Eastern            |
| Reddit — `r/cryptocurrency`      | <https://reddit.com/r/cryptocurrency> | $0       | 100–5k upvotes; high noise             | Text post; high removal risk             | Read rules; only post if you have karma   |
| Reddit — `r/defi`                | <https://reddit.com/r/defi>        | $0          | 50–500 upvotes                        | Text post                                | Tue–Thu, 09:00–11:00 US-Eastern            |
| Twitter / X                      | <https://twitter.com>              | $0          | 200–5k impressions                    | 6-tweet thread (see §5)                  | 09:00–10:00 US-Eastern, Tue–Thu            |
| Farcaster                        | <https://warpcast.com>             | $0          | 100–2k views on a good cast           | Single cast or short thread              | 09:00–11:00 US-Eastern                     |
| Lens Protocol                    | <https://lens.xyz>                 | $0          | 50–500 views                           | Mirror of the Farcaster cast              | Same day as Farcaster                     |
| Product Hunt                     | <https://producthunt.com>          | $0          | 200–5k upvotes on a good day           | Tagline + description + maker comment (see §4) | Schedule via the maker tool, 12:01 AM Pacific |
| Indie Hackers                    | <https://indiehackers.com>         | $0          | 100–1k views                           | Long-form post, honest numbers            | Tue–Thu, 12:00–14:00 US-Eastern            |
| Mirror.xyz                       | <https://mirror.xyz>               | $0          | 50–500 views; Web3-native readers     | Long-form essay, cross-posted from `/blog` | When the next transparency report lands    |
| Dev.to                           | <https://dev.to>                   | $0          | 100–2k views                           | Technical post: how the brand scanner works | 1–2 weeks after launch                    |
| Hashnode                         | <https://hashnode.com>             | $0          | 100–2k views                           | Same as Dev.to; cross-post              | Same week as Dev.to                        |
| LinkedIn                         | <https://linkedin.com>             | $0          | 500–5k impressions                     | Single post (see Post C in §1.7)         | Tue–Thu, 08:00–10:00 local time            |
| Discord servers (Web3)           | Various; find via web3 directories | $0          | 10–100 reactions per server            | `#self-promo` thread per server rules     | Friday, per server's thread schedule       |
| Telegram groups (Web3)            | Various; find via web3 directories | $0          | 10–100 views                            | Single post with the canonical text      | After at least 30 days as a member         |
| Personal network                 | Email / DM                         | $0          | 50–500 people                          | Personal one-liner + canonical text      | T-0, one-time                             |

**Two hard rules across every channel:**

1. **Never promise a return, a launch date for the token, or a
   partnership that doesn't exist.** A single sentence in the wrong
   channel will get screenshotted and outlive the post.
2. **Never use a channel's promised audience as a financial claim.**
   "10k Discord members" is not a metric that should appear in any
   investor-facing material, ever.

---

## 9. Channels we should NOT post to (and why)

Each of these has a track record of producing harm to projects that
post there. The reasons are concrete, not moral.

| Channel type                | Why not                                                                                              |
| --------------------------- | ---------------------------------------------------------------------------------------------------- |
| **Token listing sites**     | We don't have a token. Listing on a token directory with a placeholder is misrepresentation. Wait until the contract is deployed, then a single canonical announcement from `/transparency`. |
| **Pump communities**        | These are organized around short-term price action. The project has no price to act on. Posting there invites a wave of "when moon?" comments that the team will then have to refute — and refutation gets quoted out of context. |
| **"10x" / "moonshot" groups** | Same as above. The project's posture is "this is not an investment vehicle." Joining a moonshot group is incompatible with that posture. |
| **Anything that requires financial claims to participate** | Some Telegram and Discord groups require you to disclose an APY, a launch price, a presale, or a "team's portfolio" before you can post. Decline those channels. Don't try to "play along" by writing a fake financial claim you can later retract — once posted, it lives forever in screenshots. |
| **Airdrop-farming boards**   | We do not have an airdrop, and the project's "no fake stats" policy rules out the kind of points/leaderboard structure these boards expect. |
| **Paid promotion**          | A small, honest project cannot afford to buy the audience that would make paid promotion worth it, and a bought audience expects the kind of copy this project does not write. |
| **"Shill-for-shill" exchanges** | Posting your announcement in exchange for someone else's. Discoverable, low-quality, and gets reported quickly. |
| **Influencer DM lists**     | The ROI on a $200 influencer tweet is the difference between 0 and 0.1% conversion; the trust cost is much higher. |

If you're ever unsure about a channel, the test is: **does the channel
ask us to say something that the brand scanner would reject?** If yes,
don't post.

---

## 10. Crisis response template

The goal in a crisis is **to be the first accurate voice, not the
loudest**. Every scenario below has the same shape: acknowledge in
under 30 minutes, point to the canonical source, decline to speculate.

> **Time budget, in order of priority:**
>
> 1. 0–5 min: stop the bleeding (rotate keys, take the affected route
>    offline, etc.)
> 2. 5–15 min: write a one-paragraph public statement, link the
>    canonical doc, and post it on the project's own surfaces
>    (`/transparency`, GitHub release, pinned tweet).
> 3. 15–30 min: reply to inbound on X/Farcaster/email with the same
>    one-paragraph statement.
> 4. After 30 min: write a longer incident post-mortem within 24
>    hours. Post it where the original statement was posted.

### Scenario A — Security disclosure

**Trigger:** a security report arrives in `security@`, or a researcher
publicly discloses a vulnerability, or a user reports a stolen-key
phishing page that looks like ours.

**0–5 min:**

- If a live exploit is happening, take the affected route offline
  via the deploy script in `DEPLOYMENT.md`. Do not wait for full
  analysis.
- If it's a phishing page, report it to the relevant registrar and
  Web3 wallet blocklists (Etherscan, MetaMask, Phantom) via their
  abuse forms.

**5–15 min public statement (template):**

> We received a report of a [vulnerability / phishing page] affecting
> [route / none — the user, not us]. The platform's smart-contract
> layer is out of scope for `SECURITY.md`, but the web layer is in
> scope and we are investigating. We will publish a full post-mortem
> at [link to `/transparency` post] within 24 hours. In the meantime:
> do not sign any transaction; verify all addresses on a block
> explorer; never share your seed phrase. Report to
> `security@` (see `SECURITY.md`).

**15–30 min:** Reply to the inbound with the same paragraph + a private
channel for the reporter. Do not negotiate in public.

**After:** Post the full post-mortem. Credit the reporter if they
consent. Update `SECURITY.md` if the in-scope definition needs to
change.

### Scenario B — Partner complaint

**Trigger:** a person or company claims to be a "partner" of
CrystalFlakCoin and is unhappy about something we said, or we receive
a "cease and desist" claiming false partnership.

**0–5 min:**

- Do not delete or edit the page in question yet.
- Forward the complaint to the email alias in `.env.example` that
  you set up for legal, or to a personal counsel contact.

**5–15 min public statement (template):**

> We've received a complaint regarding [partner X]. To be clear:
> CrystalFlakCoin has no commercial partnerships as of the date of
> this post, and the site does not display any partner logos. If you
> saw a "partner" claim elsewhere (e.g. a third-party listing), it
> was not authorized by us and we have asked for its removal. We
> list the names of any genuine counterparties only on
> `/transparency`, and only after they are real.

**15–30 min:** Reply to the partner with the same paragraph, plus
the offer to publish a joint correction if there's a real
relationship we're missing.

**After:** If the complaint has merit (e.g. someone on the team said
"partner" off the record), publish a correction on `/transparency`.
If it has no merit, publish the request-for-removal we sent, with
identifying details redacted.

### Scenario C — Price crash in a related token

**Trigger:** an unrelated token crashes 50%, and people on X / Reddit
start asking whether CrystalFlakCoin is "next," or whether the
team's wallet is exposed.

**0–5 min:**

- **Do not engage on price.** The project is explicit: it is not
  an investment vehicle, the contract is not yet deployed, there is
  no on-chain token to crash.
- Make sure `/token` and `/transparency` are still rendering
  "not yet deployed" correctly.

**5–15 min public statement (template):**

> We have seen questions linking CrystalFlakCoin to the recent
> movements in [unrelated token]. To clarify: the CFC token contract
> is not yet deployed. There is no on-chain supply, no liquidity
> pool, and no token price for CFC. The site at
> https://9mqcfm3l5y3.space.minimax.io says so. The FAQ and the
> disclaimer on every page also say so. If you saw a price
> somewhere, it was not us.

**15–30 min:** Reply to every inbound with the same paragraph. Do
not speculate about the unrelated token. Do not deny holding it (we
don't, and don't need to say so).

**After:** If the rumor repeats, consider a single pinned post on X
with the same paragraph, then leave it. The cure for a rumor is one
accurate statement, not ten.

### What a crisis response should NEVER contain

- Promises of compensation, refunds, or airdrops.
- Speculation about the cause before a post-mortem.
- A "we will take legal action" line, unless counsel has signed off.
- A timeline that wasn't in the original plan ("the audit will be
  done by Friday").
- An emoji.

---

## 11. Free tools for the team

These are the only tools this playbook assumes you have. All have a
free tier that is sufficient for the first 90 days of a project this
size.

| Tool                | Use                            | Free tier limits                                | When to upgrade |
| ------------------- | ------------------------------ | ----------------------------------------------- | --------------- |
| **Buffer** or **Hypefury** | Schedule X / LinkedIn posts     | Buffer: 3 channels; Hypefury: 1 account         | When you have a real posting cadence |
| **Substack** or **beehiiv** | "What we shipped" newsletter   | Both: unlimited subscribers, paid tier optional | When you want a paid tier (don't, for this project) |
| **Plausible** or **Umami** | Privacy-respecting analytics   | Plausible: 30-day trial; Umami: self-hosted free | Plausible: when traffic justifies ~$9/mo |
| **Fathom**          | Privacy-respecting analytics, alt to Plausible | Free for < 100k pageviews/mo                  | When traffic justifies ~$14/mo |
| **Loom**            | Screen recording for demos     | 25 videos up to 5 min each                     | When you actually record more than that |
| **Canva**           | Social graphics                | Free tier; "Pro" not needed                     | Never, for this project |
| **GitHub Project**  | Kanban for the team            | Free with private repos                         | Never, for this project |
| **Notion**          | Wiki / shared docs             | Free for small teams                           | When collaboration outgrows free tier |
| **UptimeRobot**     | Uptime monitor                 | 50 monitors, 5-min interval                     | When you need 1-min checks |
| **Healthchecks.io** | Dead man's switch              | 20 checks                                       | When you have >20 services to watch |
| **Sentry**          | Error tracking                 | 5k events/mo                                    | When you ship past beta |
| **ForwardEmail** + **Gmail** | Shared inbox for `support@` and `security@` | Free                            | When volume justifies a real helpdesk |
| **linkchecker**     | Broken-link crawler            | Free                                            | n/a |

What this stack **does not include** and why:

- **No "Web3 PR agency"** — the entire point of the brand scanner is
  that the project's voice is its own.
- **No "engagement" tool** — every one we evaluated manufactured
  numbers.
- **No token analytics dashboard** — there is no token.
- **No "KOL" marketplace** — the audit trail of a paid KOL is
  incompatible with the no-paid-promotion policy in §9.

---

## 12. Closing: the test that catches everything

If you ever find yourself writing copy that doesn't pass the
following test, stop and rewrite.

> **The test:** *If a journalist quoted this sentence in a
> "CrystalFlakCoin promised X" headline tomorrow, would we be
> embarrassed, accurate, or proud?*
>
> - **Embarrassed** → rewrite.
> - **Accurate** → ship.
> - **Proud** → ship and pin it to `/transparency`.

This is the same test the brand scanner and the risk-disclosure
policy are trying to automate. The scanner catches the words; this
test catches the intent.

Welcome to launch day. The site is the launch. The token is to be
announced. The brand scanner is watching. Let's go.
