# CrystalFlakCoin (CFC) — Web Platform

A production-grade Next.js 14 + TypeScript + Tailwind + shadcn/ui + Prisma + wagmi/viem
website and Web3 dashboard for the **CrystalFlakCoin (CFC)** digital asset project.

The codebase is **honest by design**: no fake prices, no fabricated statistics, no
guaranteed returns. Every on-chain value displayed by the UI is read from a verified
source or clearly labeled "Not yet deployed".

---

## Highlights

- **Next.js 14 App Router** with TypeScript strict mode
- **Tailwind CSS + shadcn/ui** — accessible, dark, crystalline visual style
- **Prisma + PostgreSQL** with a typed schema covering users, wallets, roles, content,
  token metadata, tokenomics, governance, security reports, audit logs, and supported
  networks
- **Wallet integration** via wagmi + RainbowKit (EVM-compatible)
- **Admin panel** with email+password auth, role-based access, audit logging, CSRF,
  rate limiting, input validation (Zod), and Argon2 password hashing
- **Risk-first content** — every page that touches tokens, staking, or swapping has a
  risk disclosure; the FAQ explicitly answers "no, this is not an investment"
- **Legacy-brand scanner** (`scripts/legacy-brand-scan.mjs`) — fails the build if any
  forbidden term (legacy brand references or misleading financial claims) is found
- **Tests** — unit (Jest + RTL), integration, and end-to-end (Playwright)
- **Docker** + docker-compose for local development and production deployment
- **Security headers** — CSP, HSTS, X-Frame-Options, Permissions-Policy, Referrer-Policy
- **Accessibility** — skip-to-content link, focus rings, `prefers-reduced-motion`

---

## Project structure

```
crystalflakcoin-web/
├── prisma/                     # Prisma schema + seed
├── public/                     # Static assets
├── scripts/                    # legacy-brand-scan.mjs (CI gate)
├── src/
│   ├── app/                    # App Router pages + API routes
│   │   ├── (public pages)      # /, /about, /token, /tokenomics, /ecosystem,
│   │   │                       #   /swap, /stake, /governance, /transparency,
│   │   │                       #   /docs, /faq, /legal, /contact, /connect
│   │   ├── admin/              # Authenticated admin panel
│   │   └── api/                # Public + admin API routes
│   ├── components/             # shadcn-style UI + layout + wallet
│   ├── lib/                    # env, prisma, wagmi, auth, validation, audit,
│   │                           # rate-limit, csrf, brand, chain-utils
│   └── middleware.ts           # Edge guard for /admin
├── tests/
│   ├── unit/                   # Jest unit tests
│   ├── integration/            # API integration tests
│   └── e2e/                    # Playwright e2e tests
├── Dockerfile
├── docker-compose.yml
├── next.config.mjs
├── tailwind.config.ts
└── package.json
```

---

## Quick start

```bash
# 1. Install
cp .env.example .env
# Edit .env: set DATABASE_URL, SESSION_PASSWORD, and any NEXT_PUBLIC_* values.
npm install

# 2. Database (Postgres required)
npx prisma migrate dev --name init
npm run db:seed     # optional: creates default roles, networks, and a token row

# 3. Dev server
npm run dev
# → http://localhost:3000
```

### With Docker

```bash
cp .env.example .env
# generate a real session secret and put it in .env
docker compose up --build
# → http://localhost:3000
```

---

## Environment variables

All required variables are documented in `.env.example`. Highlights:

- `DATABASE_URL` — Postgres connection string
- `SESSION_PASSWORD` — at least 32 random bytes (base64). Generate: `openssl rand -base64 32`
- `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` — from <https://cloud.walletconnect.com>
- `NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS` — leave empty until the contract is deployed
- `NEXT_PUBLIC_ENABLE_SWAP`, `NEXT_PUBLIC_ENABLE_STAKE`, `NEXT_PUBLIC_ENABLE_GOVERNANCE` —
  feature flags; default to `false`
- `NEXT_PUBLIC_SUPPORT_EMAIL`, `NEXT_PUBLIC_SECURITY_EMAIL` — for the contact page

> If a value contains `CHANGE_ME` or is empty, the UI renders a "Not yet deployed" or
> "To be announced" placeholder. This is intentional and explicit.

---

## Scripts

```bash
npm run dev            # Next.js dev server
npm run build          # Generate Prisma client → run brand scanner → next build
npm run start          # Production server
npm run typecheck      # tsc --noEmit
npm run lint           # next lint
npm run test           # Jest unit + integration
npm run test:e2e       # Playwright
npm run brand:scan     # Standalone brand-reference scanner
npm run prisma:migrate # prisma migrate dev
npm run prisma:studio  # prisma studio
```

The **brand scanner** is wired into `prebuild` and runs before every production build.
It walks the source tree, scans files for forbidden legacy terms and misleading
financial claims, and exits non-zero if any are found.

---

## Admin panel

- Sign in at `/admin/login` (use the bootstrap admin from `.env` after `npm run db:seed`).
- The admin can:
  - Edit token metadata (`/admin/token`)
  - Configure tokenomics allocations (`/admin/tokenomics`)
  - Manage documentation and announcements
  - View audit logs (`/admin/logs`)
  - Review security reports (`/admin/security`)
- All write actions are validated with Zod, rate-limited per IP, CSRF-protected,
  checksum-validated, and recorded in the audit log.

---

## Security model

- **No private keys or seed phrases** are ever stored or transmitted.
- Authentication uses Argon2id password hashing + iron-session cookies.
- Sessions are HTTP-only, SameSite=Lax, Secure in production.
- CSRF: double-submit cookie token (see `src/lib/csrf.ts`).
- Rate limiting: per-IP sliding window (in-memory in dev, Upstash Redis in production).
- Input validation: every API route uses Zod schemas in `src/lib/validation.ts`.
- Address validation: EIP-55 checksum via viem.
- Read-only blockchain calls by default; transaction methods always require explicit
  wallet signature, with the contract and method shown before signing.
- Security headers: CSP, HSTS, X-Frame-Options, X-Content-Type-Options,
  Permissions-Policy, Referrer-Policy (`next.config.mjs`).
- Admin actions are appended to `AuditLog`.

---

## Risk disclosure (applies to the entire platform)

CrystalFlakCoin is a digital asset project. It is not an investment vehicle and is not
registered as a security in any jurisdiction. Digital assets are volatile; you may lose
some or all of the value of your assets. Nothing on this site is financial, investment,
legal, or tax advice. Always verify contract addresses on a block explorer, never share
your seed phrase or private key, and consult a qualified professional before acting.

---

## Deployment

1. Provision a managed Postgres (or run the bundled `docker-compose.yml`).
2. Set every variable in `.env.example` to a real value.
3. `npm ci`
4. `npx prisma migrate deploy`
5. `npm run build`
6. `npm start` (or `docker compose up -d`)

For Vercel-style deploys, the same build pipeline works; just provide the environment
variables through the platform's secret manager.

---

## License

Source-available; license to be announced. All third-party libraries retain their
original licenses (see `package.json`).
