# CrystalFlakCoin — Admin Guide

> A non-technical guide for the team lead (or anyone else trusted with admin
> access) on how to use the admin panel that lives at `/admin` on the
> CrystalFlakCoin website.
>
> **Audience:** people who run the project, not the people who build it. You
> don't need to know how to code. You do need to be careful — every change
> you make through this panel is saved to the database and (in most cases)
> recorded in the audit log forever.
>
> **Read this first.** Mistakes in the admin panel can be hard to undo.
> Several actions are **irreversible** (e.g. running a real raffle draw). If
> you are unsure, ask a developer before you click.

---

## Table of contents

1. [What the admin panel is, and what it isn't](#what-the-admin-panel-is-and-what-it-isnt)
2. [First-time setup](#first-time-setup)
3. [Signing in](#signing-in)
4. [The overview page (`/admin`)](#the-overview-page-admin)
5. [Token management (`/admin/token`)](#token-management-admintoken)
6. [Tokenomics management (`/admin/tokenomics`)](#tokenomics-management-admintokenomics)
7. [Daily prize management (`/admin/daily-prize`)](#daily-prize-management-admindaily-prize)
8. [Randomness source](#randomness-source)
9. [Content management (`/admin/content` and `/admin/announcements`)](#content-management-admincontent-and-adminannouncements)
10. [Security reports (`/admin/security`)](#security-reports-adminsecurity)
11. [Audit log (`/admin/logs`)](#audit-log-adminlogs)
12. [Network management (`/admin/networks`)](#network-management-adminnetworks)
13. [Best practices](#best-practices)
14. [If something goes wrong](#if-something-goes-wrong)
15. [Glossary](#glossary)

---

## What the admin panel is, and what it isn't

The admin panel is a small, password-protected section of the website at
`/admin`. From here you can:

- Edit the token's name, symbol, contract address, and "is it deployed" flag.
- Configure the **tokenomics** (how the token supply is split between
  categories like community, treasury, liquidity, etc.).
- Manage the **daily spin** prizes and run raffle draws.
- Switch the **randomness source** that powers the spin and the raffle.
- Review and update documentation pages and public announcements.
- Triage **security reports** submitted by the public.
- Read the **audit log** — a tamper-evident list of every administrative
  action that anyone has taken.
- View the list of supported blockchain **networks**.

**The admin panel is not** a code editor. You cannot change colours, fonts,
or page copy from here. For those, ask a developer.

**The admin panel is not** a database browser. Although every page reads from
the same database, you should never connect directly to the database to make
changes (see [Best practices](#best-practices)). Always go through the panel
so the change is validated and recorded.

[Screenshot: The admin sign-in card, with a dark crystalline background, a
"Sign in" button, and email/password fields.]

---

## First-time setup

You will only do this once, on a brand-new deployment. After that, you sign
in normally.

### 1. Make sure a developer has prepared the database

The project needs a running PostgreSQL database. If `npm run dev` (or the
deployed site) is working, this is already done. If not, ask a developer to
follow the steps in the main `README.md` (`Quick start` section).

### 2. Set the bootstrap admin email in your environment

The first time you seed the database, you create one (and only one) admin
account. You do this by setting two environment variables **before** running
the seed:

| Variable                    | What to set it to                                       |
| --------------------------- | ------------------------------------------------------- |
| `ADMIN_BOOTSTRAP_EMAIL`     | The email address you want to use to sign in.           |
| `ADMIN_BOOTSTRAP_PASSWORD`  | A temporary password (you will change it on first use). |

These live in the `.env` file at the root of the project. **Never** commit
`.env` to source control. **Never** reuse a personal password here.

> A "bootstrap" admin is the very first admin. Once it exists, the seed
> script will not create another one, even if you re-run it. This is
> intentional — we don't want a stray script to silently add a second
> admin.

### 3. Run the seed

```bash
npm run db:seed
```

You should see a line like:

```
[seed] Bootstrap admin created: you@yourdomain.com
[seed] IMPORTANT: change the password on first login.
```

If you don't see that line, the seed probably found the placeholder
(`CHANGE_ME`) instead of a real email — go back to step 2.

The seed also creates the default **roles** (`ADMIN`, `EDITOR`, `VIEWER`),
two **supported networks** (Ethereum Mainnet and Sepolia testnet), a default
**token metadata row** marked "not deployed", and a default **randomness
source** ("server"). It does **not** create any prize catalogue entries —
those are loaded from code unless you add your own (see [Daily prize
management](#daily-prize-management-admindaily-prize)).

### 4. Sign in and change your password

- Go to `/admin/login`.
- Sign in with the email and the temporary password you set in step 2.
- **Immediately change the temporary password** to something only you know.
  Until the project adds a self-service "change password" screen (it's on
  the roadmap), do this through a developer running
  `prisma.user.update(...)` on your behalf, or by signing up for a
  dedicated password manager to hold the temporary one for the short time
  you'll need it.

### 5. Enable MFA (multi-factor authentication) — when available

Multi-factor authentication ("MFA", or "two-factor") means signing in
requires something you **know** (your password) and something you **have**
(a code from an authenticator app on your phone).

The login page (`/admin/login`) and the user model in the database are
already wired up to support MFA. A self-service "enable MFA" button in the
admin panel is on the roadmap and is not yet available in the UI. In the
meantime:

- The model field `User.mfaEnabled` defaults to `false`. Once enabled, the
  login form will require a one-time code.
- Track the rollout of the MFA-enable endpoint in the project's release
  notes.
- Until MFA is available, treat your admin password like a master key:
  long, unique, and never written down anywhere it could leak (no email,
  no Slack, no Notion page).

[Screenshot: The first-login experience. The same login card, with a banner
that says "Welcome — please change your temporary password and enable MFA."]

---

## Signing in

The sign-in page is at **`/admin/login`**.

You need:

- The **email** you set as `ADMIN_BOOTSTRAP_EMAIL` (or the one a developer
  later added to your account).
- Your **password**.
- A **one-time code** from your authenticator app, if your account has
  MFA enabled.

### Locked out?

The sign-in page is rate-limited: you get **10 attempts per 5 minutes per
IP address**. If you hit that limit, you'll see "Too many attempts. Please
try again later." and the form will refuse any submission for the rest of
the window.

If you have genuinely forgotten your password or lost your MFA device:

1. **Wait 5 minutes** for the rate-limit window to roll over, then try once
   more with the correct credentials. Many "lockouts" are just typos or
   autocomplete mistakes.
2. **If that doesn't work**, ask a developer with database access to reset
   your password using `prisma studio` (`npm run prisma:studio`) or a
   one-off script. The new password must be set via a fresh hash — **never**
   store a plain-text password.
3. **If the database itself is unreachable**, that's a hosting problem —
   escalate to whoever runs the server (Vercel, your VPS, etc.).
4. **If you suspect someone else has your password**, treat it as a
   security incident: see [Security reports](#security-reports-adminsecurity)
   and ask a developer to invalidate all admin sessions by rotating
   `SESSION_PASSWORD` in the environment.

[Screenshot: The login page mid-error. The form has red borders and a red
"Sign in failed" alert under the button.]

---

## The overview page (`/admin`)

The first thing you see after signing in. It is a dashboard, not a place to
make changes.

[Screenshot: The admin overview, showing five stat tiles across the top and
a "Recent audit logs" card underneath.]

### The five stat tiles

| Tile              | What it counts                                                                |
| ----------------- | ----------------------------------------------------------------------------- |
| **Users**         | Total user accounts in the system (admins + editors + viewers + wallet users). |
| **Token rows**    | Should be `1`. If it's higher, something is off — ask a developer.             |
| **Allocations**   | How many **tokenomics categories** have rows in the database.                 |
| **Proposals**     | Governance proposals (the public governance flow is not yet live).            |
| **Security reports** | Unresolved reports submitted through the public form.                     |

None of these tiles are clickable. They are a quick health check.

### Recent audit log feed

Below the tiles, you see the **ten most recent actions** taken in the
admin panel, newest first. Each row shows:

- The **timestamp** in UTC (e.g. `2026-03-15T14:22:08.000Z`).
- The **action name** (e.g. `token.update`, `admin.login.success`).
- **Who** did it: their email if they were signed in, their IP if they
  weren't (e.g. a failed login), or `system` if no user was attached.

A blank feed means nobody has done anything yet. That's normal on a fresh
deployment. See [Audit log](#audit-log-adminlogs) for the full list.

---

## Token management (`/admin/token`)

This page edits the single row of token metadata that the rest of the
website reads. The token is the thing the project is named after, so
**be careful**. Get the values right, then double-check them.

[Screenshot: The token-metadata page, with a "Not deployed" yellow badge
top-right and a form with Name, Symbol, Decimals, Network, Chain ID,
Contract address, Is Deployed, and Description fields.]

### The fields and what they mean

| Field              | What it is                                                                                                  |
| ------------------ | ----------------------------------------------------------------------------------------------------------- |
| **Name**           | The full name, e.g. "CrystalFlakCoin".                                                                      |
| **Symbol**         | The ticker, e.g. "CFC". Usually 3–5 letters.                                                               |
| **Decimals**       | How divisible the token is. Most ERC-20 tokens use **18**. Don't change this once the contract is deployed — it would be wrong. |
| **Network**        | The human-readable chain name, e.g. "Ethereum Mainnet".                                                     |
| **Chain ID**       | The chain's numeric ID, e.g. `1` for mainnet, `11155111` for Sepolia. Must match the network.               |
| **Contract address** | The on-chain address of the token, e.g. `0x…`. Must be in **EIP-55 checksum** form. See below.           |
| **Is deployed**    | A checkbox. Off = "not yet deployed" placeholder. On = "we are telling the world this is real".           |
| **Description**    | A short paragraph explaining what the token is. Appears on the public `/token` page.                        |

### EIP-55 checksum validation

Ethereum addresses are written as 40 hex characters starting with `0x`. The
problem is that `0xabc…` and `0xABC…` and `0xAbC…` all describe the same
address, so it's easy to mistype one. The **EIP-55 checksum** standard
solves this by capitalising some letters based on a hash of the address
itself. The capitalisation pattern is unique, so if you mistype a single
character, the address becomes "invalid" and wallets will warn the user
before sending money.

**Always paste contract addresses in their checksummed form.** If you paste
one in all-lowercase or all-uppercase, the form will reject it and show
"Invalid contract address". To checksum an address, paste it into
Etherscan and copy it back out — Etherscan displays the checksummed form.

### When to flip "Mark as deployed"

The **`isDeployed`** checkbox is the single most consequential switch in
the admin panel. It controls whether the public site shows:

- A **"Not yet deployed"** placeholder (off), or
- The **real contract address, network, and explorer link** (on).

Only flip it when **all three** of the following are true:

1. The contract is **deployed** on the chain you selected. You can confirm
   this by pasting the address into Etherscan and seeing live transactions.
2. The contract's **source code is verified** on the block explorer
   (Etherscan shows a green checkmark next to the "Contract" tab).
3. You have **double-checked the address** character by character against
   the deployment transaction. Even one wrong character is enough to
   mislead users.

If any of those three are not true, leave the box **off**. The website
already handles the "not yet deployed" case gracefully and explains it
clearly to visitors — that is by design.

### The "not yet deployed" placeholder workflow

While the contract is still in development, you can (and should) fill in
**Name**, **Symbol**, **Decimals**, **Network**, and **Description** so
that the public pages aren't completely empty. Leave **Contract address**
blank and leave **Is deployed** unchecked. The site will render a clearly
labelled "Not yet deployed" call-out instead of a fake address. This is
**intentional and correct** — do not invent an address to "look real".

When the contract is finally deployed and verified, paste the address in,
flip the checkbox, and click **Save**. The audit log will record who made
the change and when.

[Screenshot: The same token-metadata page, but now with a green "Deployed"
badge top-right and the contract address field filled in.]

---

## Tokenomics management (`/admin/tokenomics`)

This page controls how the **total token supply** is divided between
buckets like "community", "ecosystem", "treasury", "liquidity", and
"development". The site reads from this table to render the
`/tokenomics` page.

[Screenshot: The tokenomics page, with several cards stacked, one per
category. Each card has a label, percentage, amount, vesting, cliff,
unlock date, wallet address, order, and notes field.]

### Why the percentages must sum to 100

If a category has a percentage set, the system requires **all** of the
percentages to add up to exactly **100** (±0.01 for floating-point
fuzziness). This is a deliberate guardrail: a tokenomics table that adds
up to, say, 87% is either wrong or unfinished, and the public would
notice immediately.

To say "we haven't decided this bucket yet", leave the percentage field
**empty** (not zero). Empty fields are ignored by the sum check and render
as "Not configured" on the public site.

### What each default category means

| Category        | Plain-English meaning                                                      |
| --------------- | -------------------------------------------------------------------------- |
| **community**   | Tokens given to the community — airdrops, rewards, giveaways, etc.         |
| **ecosystem**   | Tokens spent on partnerships, integrations, and growth initiatives.         |
| **treasury**    | Tokens held by the project for long-term operations and emergencies.        |
| **liquidity**   | Tokens paired with other assets in liquidity pools to enable trading.      |
| **development** | Tokens used to fund ongoing engineering, audits, and contributors.         |

You can change the **label** of any category to match your own naming, but
the underlying **category code** is what the database indexes by. Don't
change category codes after launch — the public site will lose the link.

### How vesting & wallet addresses are validated

For each category, you can fill in:

- **Vesting (months)** — over how many months the tokens unlock after the
  cliff.
- **Cliff (months)** — how long after launch before any tokens start
  unlocking. `0` means no cliff.
- **Unlock date** — the absolute date on which the cliff ends, if you
  prefer a calendar to a duration.
- **Wallet address** — the on-chain address that will hold the allocation.
  Must be in **EIP-55 checksum** form (see [Token management](#token-management-admintoken)
  for what that means). The form will reject malformed addresses.
- **Notes** — internal-only context. The public site does not show this
  field; it is for you and the developers.

The form does not enforce that the wallet is a multisig or that the
allocation is timelocked. **That is your responsibility.** Before saving
a wallet, confirm with a developer that:

- The address is the right one (a single wrong character can mean sending
  tokens to a black hole).
- The address is a multisig, not a single-key hot wallet, for any
  non-trivial allocation.
- The vesting contract is set up to enforce the schedule you entered here.

Click **Save all** when you're done. The whole table saves in one
transaction. Either all your changes land or none of them do.

---

## Daily prize management (`/admin/daily-prize`)

This is the most complex page in the admin panel. It controls the
**daily spin** game (a wheel users spin once per UTC day) and the
**periodic raffle** that raffle entries feed into.

Read the whole section before making any changes — the spin is a
**public commitment**: the probabilities you publish here are the
probabilities users will hold you to.

[Screenshot: Top of the daily-prize page, showing five stat tiles (Total
spins, Last 30 days, Unique wallets, Total points, Total raffles) and the
"Prize catalogue" card.]

### What's on the page

From top to bottom:

1. **Stat tiles** — total spins, spins in the last 30 days, unique wallets,
   total points awarded, total raffle entries awarded.
2. **Prize catalogue** — one card per prize. Edit, deactivate, or add.
3. **Raffle draw system** — the periodic on-chain draw (see below).
4. **Randomness source** — server, commit-reveal, or Chainlink VRF.
5. **Recent spins** — the last 25 spins, with server seeds, so an admin
   can manually verify outcomes.

### Editing an existing prize

For each prize, you can change:

| Field            | What it is                                                                                     |
| ---------------- | ---------------------------------------------------------------------------------------------- |
| **Label**        | What the user sees on the wheel (e.g. "+10 Community Points").                                 |
| **Description**  | One-line description under the prize.                                                          |
| **Disclosure**   | The **legalese** shown to the user about what this prize is and isn't. Keep it honest.        |
| **Category**     | One of: `points`, `raffle`, `badge`, `streak_freeze`, `none`.                                  |
| **Weight**       | The chance bucket, in **basis points** (1 = 0.01%). See below.                                 |
| **Points**       | How many community points to award (for `points` prizes).                                      |
| **Raffles**      | How many raffle entries to award (for `raffle` prizes).                                        |
| **Freezes streak** | Tick to mark this as a streak-preserving token (for `streak_freeze` prizes).                 |
| **Color**        | A Tailwind gradient pair, e.g. `from-violet-700/40 to-violet-500/20`. Visual only.            |
| **Order**        | Where the prize appears in the wheel (lower = earlier).                                        |
| **Active**       | Whether the prize is currently in the spin pool.                                               |

#### Weights are basis points

The `weight` field is in **basis points**: 100 basis points = 1.00%. A
weight of `4500` means 45% of all spins should land on that prize, **on
average**, as long as the total of all active weights adds up to 10,000.
Don't worry about hitting 10,000 exactly — the system scales by the
total. But if you set one prize to `5000` and another to `5000`, each
gets roughly half. If you set one to `4500` and the rest to `5500`
together, the first gets 45% and the others share the remaining 55%.

The page shows the **percentage of total weight** next to each prize so
you can sanity-check the odds you're publishing.

#### The "not yet deployed" rule still applies

A prize's `disclosure` is shown verbatim to the user. While the token
contract is not yet deployed, every disclosure should make clear that
**the prize is non-monetary**. The default catalogue ships with phrases
like "Non-monetary. Becomes convertible to token units only if and when a
token contract is published." **Do not** remove those caveats to make
the prizes sound more exciting. They are a legal and ethical floor.

### Adding a new prize

Click **Add prize** in the top-right of the catalogue card. A draft form
appears. Pick a stable, all-caps, snake-case `code` (e.g. `BRONZE_RAFFLE`).
The code becomes the primary key — pick it once, never rename it, because
past spins reference it.

When you click **Create**, the prize is saved. It becomes active
immediately and starts appearing on the wheel.

### Deactivating vs deleting

You **cannot** delete a prize. There is no "Delete" button — only
"Deactivate".

This is intentional. Spins from the past reference a prize `code`, and
keeping the row around (with `isActive = false`) preserves the audit
trail. Anyone reading the audit log years from now can still see what
prize a given wallet was awarded.

To "remove" a prize, click **Deactivate**. The card stays in the list,
with an "Inactive" badge, and is no longer part of the spin pool. You
can re-activate it by ticking **Active** and saving.

### Streak bonus tiers (Bronze / Silver / Gold / Founder)

The spin system awards a **streak bonus** at four thresholds. These are
**not editable from this page** — they are defined in code. If you need
to change a threshold or add a new tier, ask a developer.

| Tier     | Threshold | What the user gets                                                   |
| -------- | --------- | -------------------------------------------------------------------- |
| Bronze   | 3 days    | A persistent "Bronze Supporter" badge.                               |
| Silver   | 7 days    | The Bronze badge + 5 bonus raffle entries.                           |
| Gold     | 30 days   | The Silver badge + a reserved allocation in any future community distribution (subject to governance). |
| Founder  | 100 days  | The Gold badge + a permanent reserved allocation at token launch (subject to governance). |

A "streak freeze" prize (if active in the catalogue) lets a user keep
their streak alive if they miss one day. A streak that has been broken
for more than 1.5 days resets to zero.

### Raffle draw system

Raffle entries are awarded by the `raffle` prizes. They accumulate in
the database tagged with a `period` (e.g. `2026-Q1`). At the end of the
period, an admin runs a **draw** to pick the winners. The draw system
lives in the "Raffle draw system" card on the daily-prize page.

[Screenshot: The raffle-draw card, with a "Tiers" section above a
"Run a draw" form that has a period input, a "Dry-run" button, and a
"Run real draw" button.]

#### Configuring raffle tiers

Each tier describes a single prize bucket. The default tiers are
**non-monetary** and clearly labelled; change the label, description,
and disclosure to match the actual prize. Edit the **`numWinners`** to
control how many wallets win that tier. Click **Save**.

#### Running a draw — step by step

1. **Set the period.** Use the format `YYYY-Q#` (e.g. `2026-Q1`). The
   period is the key the system uses to find all eligible raffle
   entries. If you mistype the period, you'll draw from the wrong pool
   of entries — there's no undo.
2. **Check the entry count.** Under the input, the page shows how many
   raffle entries are in that period. If the count is `0`, the "Run
   real draw" button is disabled.
3. **Dry-run first.** Click the **Dry-run** button. The system runs the
   same RNG that a real draw would, but **does not save anything**. The
   result appears in a "Done" alert showing how many entries were in
   the pool, how many unique wallets, and which wallets would win which
   tier. **This is your only chance to sanity-check the draw before it
   becomes public.** If the dry-run result looks wrong, do not run a
   real draw — figure out what went wrong first.
4. **Run a real draw.** Click **Run real draw**. The system will pop a
   confirmation dialog ("This is irreversible"). Click OK only if you
   are sure.

A real draw:

- Generates a **new 32-byte server seed**.
- For each active tier, picks `numWinners` distinct wallets from the
  entry pool using a deterministic algorithm
  (SHA-256 of `seed + tierCode + index`).
- Persists the draw, the seed, the per-tier winner list, and a row
  per winner.
- Writes a line to the audit log including the seed.

#### Idempotency

Each period can be drawn **exactly once**. If you re-trigger a draw for a
period that has already been drawn, the system returns the **previous**
result — it does not generate new winners. This is by design: the moment
a draw is public, replacing the winner list would be fraud.

If you accidentally draw the wrong period, you cannot un-do it. The right
thing to do is:

1. Acknowledge the mistake in a new public announcement.
2. Run the correct period's draw normally.
3. Tell the affected users, in the announcement, what happened and what
   you are doing about it.

#### What if something goes wrong?

| Symptom                                                 | What to do                                                                                                |
| ------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| "No raffle entries for period 2026-Q1."                 | The entry count for that period is `0`. Either the period is mis-typed, or no user earned raffle prizes in that window. |
| "No active raffle tiers configured."                    | Add at least one tier in the "Tiers" section above and make sure its "Active" box is ticked.              |
| The draw ran, but the winners look wrong.               | **Do not** run it again — that won't help and may be a sign of tampering. Contact a developer immediately. The audit log has the seed and the input list. |
| The draw button is greyed out.                          | There are 0 entries in the entered period. Fix the period.                                                |
| A real draw was run by mistake.                         | The draw is persisted. See "If you accidentally draw the wrong period" above.                             |

[Screenshot: The dry-run result, with a green "Done" alert and a JSON
string of winners by tier.]

---

## Randomness source

The daily spin and the raffle draw both need a source of randomness. The
admin panel lets you switch between three, listed on the daily-prize
page in the "Randomness source" card.

[Screenshot: The randomness-source card, listing the three sources as
horizontal cards. "Server RNG" is marked "Active"; the other two are
marked "Stub" and have no "Activate" button.]

### When to switch

You almost certainly **do not** need to switch away from the default
"server" source unless one of the following is true:

- **A user has publicly questioned the fairness of a draw.** The server
  source records every seed, so a developer can re-derive the outcome
  and prove it was fair. If the question is repeated or the publicity
  is bad, that is the moment to consider a stronger source.
- **You are preparing for a high-stakes draw** (e.g. a launch-day
  giveaway). Chainlink VRF gives on-chain, third-party-verifiable
  randomness, which is harder to dispute.
- **Your legal team has asked for a non-custodial, on-chain source.**
  Again, VRF.

For the day-to-day daily spin, the server source is fine. The seed for
every spin is recorded in the `DailySpin` row and surfaced in the
"Recent spins" table at the bottom of the page.

### How to switch

If a source has an **Activate** button, click it and confirm. The
selection is recorded in the audit log. Changes take effect within ~5
seconds (the system caches the active source briefly for performance).

### The three sources

| Source             | Status  | What it does                                                                                                                                          |
| ------------------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Server RNG**     | Active  | The server generates a 32-byte random seed, combines it with the wallet and UTC date, and SHA-256-hashes the result. The seed is recorded in the audit log so anyone can verify. |
| **Commit-reveal**  | Stub    | A two-phase scheme: the server commits to a hash of the seed before the spin, then reveals the seed after. Better than server RNG, but requires a UI change. |
| **Chainlink VRF**  | Stub    | The server requests a verifiable random function from Chainlink's oracle. Highest assurance — third-party-verifiable on-chain. Requires a funded subscription and a deployed consumer contract. |

The two stub sources will throw "not yet implemented" if you try to
activate them. Switching back to server is always safe.

---

## Content management (`/admin/content` and `/admin/announcements`)

These two pages are **read-only** in the current admin panel. The page
itself says so: "Editorial interface is stubbed for this scaffold; pages
are CRUD via the database." Editing is done by a developer using
`prisma studio` (`npm run prisma:studio`) or a migration.

If you need a new documentation page or announcement, ask a developer
and provide:

- **Title** — what the page or banner should say.
- **Slug** — the URL path, lowercase letters and hyphens only
  (e.g. `getting-started`, `2026-q1-roadmap`).
- **Body** — the content, in Markdown.
- **Category** — for documentation: `getting-started`, `security`,
  `developers`, or `legal`. For announcements: `info`, `warning`, or
  `critical`.
- **Published?** — whether it should be live immediately or held as a
  draft.

[Screenshot: The documentation page, listing a few example pages with
their category badges and "Published" / "Draft" badges.]

> When the editorial UI is built, the same content will be editable in
> the browser. Until then, treat this as a "what's currently live"
> view, not an editor.

---

## Security reports (`/admin/security`)

Anyone can submit a security report through the public form. Reports
land here. Triage them promptly — a report you don't respond to is a
report the reporter will publish elsewhere.

[Screenshot: The security-reports page, listing a few cards. Each card
has a title, a red/amber/blue severity badge, a "status" badge, the
description, and a footer with the reporter's email and timestamp.]

### Status workflow

Reports start as `open`. The expected lifecycle is:

```
open → triaging → resolved (or wontfix)
```

- **open** — the report arrived, nobody has touched it yet.
- **triaging** — someone is actively investigating.
- **resolved** — the issue is fixed (or there's nothing to fix).
- **wontfix** — we evaluated it and decided not to act (e.g. it's
  out-of-scope or by-design).

In the current scaffold, transitioning between statuses is a
database-level change a developer makes. Mention in the
acknowledgement email which path you took.

### Severity and what to do

| Severity   | What it usually means                                                   | Expected response time |
| ---------- | ----------------------------------------------------------------------- | ---------------------- |
| `low`      | Minor issue, hard to exploit, or by-design behaviour.                   | Within a few days.     |
| `medium`   | Real issue with limited impact.                                         | Within 48 hours.       |
| `high`     | Real issue with significant impact (e.g. leaked session cookie).        | Within 24 hours.       |
| `critical` | Loss of funds, take-over, or active exploitation.                        | Within hours. Page a developer on call. |

### What you should never do

- **Never** post the reporter's private details anywhere public.
- **Never** ask the reporter for their seed phrase, private key, or
  any other secret. The form already says we will never ask, and the
  database is designed not to store them. Live up to that.
- **Never** dismiss a report without reading it. If you're not sure
  whether it's real, mark it `triaging` and loop in a developer.

---

## Audit log (`/admin/logs`)

The audit log is the **append-only, tamper-evident** list of every
significant action taken in the admin panel. It also records failed
logins and other security-relevant events. The audit log table is
indexed by `userId`, `action`, and `createdAt` so it stays fast as it
grows.

[Screenshot: The audit-log page, showing a long list of one-line entries:
timestamp, action name in a pill, resource, and the user/email/IP on the
right.]

### What gets logged

| Action                                | What it means                                                                  |
| ------------------------------------- | ------------------------------------------------------------------------------ |
| `admin.login.success`                 | A successful sign-in.                                                          |
| `admin.login.fail`                    | A failed sign-in attempt. The email domain is recorded, the address is not.   |
| `admin.logout`                        | A sign-out.                                                                    |
| `token.update`                        | A change to the token metadata row.                                            |
| `tokenomics.update`                   | A change to the tokenomics allocations.                                        |
| `admin.daily-prize.prize.upsert`      | A new prize created or an existing one updated.                                |
| `admin.daily-prize.prize.deactivate`  | A prize deactivated.                                                           |
| `admin.daily-prize.raffle-tier.upsert`| A raffle tier created or updated.                                              |
| `admin.daily-prize.raffle-draw`       | A **real** raffle draw. The server seed is in the metadata.                    |
| `admin.daily-prize.randomness.update` | The active randomness source changed.                                          |

> Dry-run draws are **not** logged, by design. They have no lasting
> effect.

### How to search

The current page shows the **most recent 200 entries**. If you need to
go back further, ask a developer to query the `AuditLog` table
directly (e.g. through `prisma studio`).

For a one-off check, you can use the URL search bar of your browser
(`Ctrl/Cmd + F`) to find a specific action or email inside the page.

### Retention policy

The audit log is **append-only by design** — there is no "delete" button
in the admin panel, and you should never connect to the database to
delete rows. Logs are kept indefinitely; the database schema does not
set a TTL. If you eventually need to truncate very old logs for storage
reasons, do it as a **bulk archive-and-truncate** operation led by a
developer, not by hand.

The audit log is one of the project's compliance and incident-response
assets. Treat it accordingly.

---

## Network management (`/admin/networks`)

This page lists every EVM-compatible blockchain the project knows about.
The list is what shows up in wallet selectors and what the random-source
and chain-utility code considers valid.

[Screenshot: The networks page, showing a small table with columns
"Chain ID", "Name", "Short", "Testnet", and "Enabled".]

### What you can do here today

The page is **read-only** in the current admin panel. To add or change
a network, ask a developer to update the `SupportedNetwork` table
(e.g. through `prisma studio` or a new entry in the seed file).

When you do add one, you need:

- **chainId** — the numeric ID (e.g. `1` for Ethereum mainnet, `137` for
  Polygon, `42161` for Arbitrum One).
- **name** — the full chain name (e.g. "Arbitrum One").
- **shortName** — a one-word version (e.g. "Arbitrum").
- **rpcUrl** — a public JSON-RPC endpoint. **Never** put a private or
  rate-limited key in here.
- **explorerUrl** — the block-explorer homepage (e.g.
  `https://arbiscan.io`).
- **isTestnet** — `true` for testnets, `false` otherwise. Testnets
  are visually distinct in the wallet selector.
- **enabled** — `false` to hide without deleting.

### Adding a new EVM chain (checklist)

1. **Confirm the chain is one we should support.** Not every EVM chain
   is worth supporting. Questions to ask: is there a real community
   reason to be there? Is the RPC reliable? Does it have a public
   block explorer we can link to?
2. **Add the row in `SupportedNetwork`.** Use `prisma studio` or a
   one-off migration. All fields above are required.
3. **Update the public env file.** Add the chain ID to
   `NEXT_PUBLIC_SUPPORTED_CHAIN_IDS` (comma-separated).
4. **Add an RPC URL** for the chain in the server-side env
   (e.g. `ARBITRUM_RPC_URL=https://arb1.arbitrum.io/rpc`). The
   server uses this for SIWE verification; the client uses the chain's
   public RPC for reads.
5. **Test a wallet connection** end-to-end. Make sure the network
   appears in the wallet selector, the explorer link works, and a
   test message can be signed via SIWE.
6. **Smoke-test the spin endpoint** if the chain is configured as a
   primary spin network. The spin should accept a wallet on the new
   chain and refuse a wallet on an unsupported chain.
7. **Record the change in the audit log** by leaving a note in the
   `metadata` field of an `admin.daily-prize.randomness.update` (or
   similar) action — there's no built-in "network added" log entry yet.

---

## Best practices

A short, opinionated list. Adopt all of these as habits.

### Change management

- **Plan changes in writing before you make them.** A two-line "I'm
  going to update the community allocation from 30% to 35% because…"
  message in your team chat is enough.
- **Two-person review for consequential changes.** Things like flipping
  `isDeployed`, running a real raffle draw, or changing a wallet
  address on a tokenomics row are all the kind of change that benefit
  from a second pair of eyes. The audit log records who clicked the
  button — the second person should read the planned change before
  it's saved.
- **Read what the page tells you.** The forms are full of hints
  ("Weights are basis points", "Total weight: 10,000"). Read them.
  They are the result of past mistakes.
- **If a value looks weird, don't save it.** A 2,000% allocation
  probably means someone added a stray zero. Stop and check.

### Never share credentials

- **Never share your admin password** — not with another admin, not
  with a developer, not with "someone from the partner team who needs
  to make a quick edit". Each person gets their own account.
- **Never paste your password into Slack, email, or a shared
  document.** Passwords belong only in a password manager and only
  in the password field of the login form.
- **Never** accept an "I'll just use your account for a sec" request.
  The audit log will say **you** made the change.
- **Treat the seed phrase / private key of the deployment wallet
  like plutonium.** The admin panel does not ask for it, and neither
  should anyone. If a "developer" asks you for it, escalate to
  someone else on the team immediately. **This is the most
  important sentence in this guide.**

### Never edit the database directly

The admin panel is the **only** supported way to change content. The
schema, validations, EIP-55 checksum, percentage-sum check, and audit
log all exist to protect against mistakes. Bypassing them by running
SQL is the easiest way to:

- Get an invalid address into the system that the public UI will
  render in plain text.
- Get a tokenomics table that adds up to 87% published to the
  website.
- Lose the audit trail for a change that later needs to be
  investigated.

If a developer needs to make a one-off fix directly, that's their call
(they should still write a note in the audit log when they do), but it
should be exceptional. As an admin, your rule is: **go through the
panel**.

### Backups and recovery

- **Database backups** are the developer's responsibility, not yours.
  Ask a developer to confirm there are automated daily Postgres
  backups and a tested restore procedure. You should not need to know
  the details, but you should know **who** to ask.
- **Lost session?** Sign out and sign back in. The session cookie
  expires after `SESSION_TTL_SECONDS` (default: 24 hours) anyway.
- **Suspected compromise?** See [If something goes wrong](#if-something-goes-wrong).

### Stay inside your role

There are three roles in the system:

- **ADMIN** — full access. That's you.
- **EDITOR** — can edit documentation and announcements, nothing else.
- **VIEWER** — read-only across the public-facing data.

If someone needs less than full access, ask a developer to create them
an `EDITOR` or `VIEWER` account. Don't share the admin account.

---

## If something goes wrong

A short decision tree. When in doubt, **stop and ask**.

| Symptom                                                                | First action                                                                                                       |
| ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| I can't sign in.                                                       | Check the lockout and password rules in [Signing in](#signing-in).                                                 |
| I made a change I regret and it's not saved yet.                       | Close the page without clicking Save. Unsaved form state is lost.                                                  |
| I saved a wrong change (e.g. wrong contract address).                  | Edit it back to the right value and save. Every save is logged.                                                    |
| I ran a real raffle draw by mistake.                                   | See "Raffle draw system" → "What if something goes wrong". The draw cannot be undone.                               |
| I deactivated a prize by mistake.                                      | Tick **Active** and save.                                                                                          |
| I see a row I don't recognize in the audit log.                        | Ask the person named in the log entry what they did. If you don't know who they are, treat as a security incident. |
| I get a 5xx error from the admin panel.                                | Retry. If it persists, ask a developer — the database or app server may be down.                                   |
| I think an attacker has my password.                                   | **Rotate the session secret (`SESSION_PASSWORD`) and any compromised admin passwords immediately.** Page a developer. |
| A user is publicly claiming the draw was rigged.                       | Ask a developer to verify the draw from the recorded server seed. The audit log has everything needed.             |
| Something is on fire (literal or figurative).                          | Page your on-call developer.                                                                                       |

---

## Glossary

A small dictionary of the terms this guide uses.

- **Admin panel** — the password-protected section of the website at
  `/admin`. Where you do all of the things in this guide.
- **Allocation** — one row in the tokenomics table. A category, a
  percentage of the total supply, and the wallet that will hold it.
- **Audit log** — the append-only list of admin actions. Lives at
  `/admin/logs`.
- **Basis points** — a unit of percentage. 1 basis point = 0.01%. 100
  basis points = 1%. The spin weights use basis points so that
  percentages are exact integers.
- **Bootstrap admin** — the very first admin account, created by the
  seed script if the right env variables are set.
- **Chain ID** — a unique numeric identifier for a blockchain. Ethereum
  mainnet is `1`, Sepolia testnet is `11155111`. The chain ID of a
  transaction is part of how wallets prevent replay attacks across
  chains.
- **Cliff** — a delay (in months) before vesting starts. A `6` month
  cliff means "no tokens unlock for 6 months; after that, vesting
  begins".
- **CSRF** — Cross-Site Request Forgery. A class of attack where a
  malicious site tricks your browser into submitting a form to a
  site you're already signed in to. The admin panel uses double-submit
  cookies to prevent this. As an admin you don't need to do
  anything — the protection is automatic.
- **Decimals** — the number of decimal places a token uses. Most
  ERC-20s use `18`. A token with `18` decimals has `1` whole token
  represented as `1000000000000000000` in its smallest unit.
- **EIP-55 checksum** — a capitalisation pattern in an Ethereum
  address that lets typos be detected. See
  [Token management](#token-management-admintoken).
- **Etherscan** — the Ethereum block explorer. Used to verify contract
  deployments and look up transactions. https://etherscan.io
- **ERC-20** — the most common standard for fungible tokens on
  EVM-compatible chains. The CrystalFlakCoin token is (or will be) an
  ERC-20.
- **KMS** — Key Management Service. A managed system for storing
  encryption keys. Used to encrypt security-report details at rest.
- **MFA** — Multi-Factor Authentication. Sign-in requires a password
  *and* a one-time code from a separate device. Roadmap item.
- **Period** — the time window a raffle covers. The default format is
  `YYYY-Q#` (e.g. `2026-Q1`).
- **Prize catalogue** — the in-database list of prizes the daily spin
  can award. Falls back to the in-code defaults if the table is
  empty.
- **Raffle** — a periodic draw that raffle entries feed into. See
  [Raffle draw system](#raffle-draw-system).
- **Raffle entry** — a single ticket in a raffle, earned by winning a
  `raffle` prize in the daily spin. Doubled entries come from
  7+ day streaks.
- **Rate limit** — a cap on how many requests a given client (per IP)
  can make in a given window. The login form is rate-limited to
  10 attempts per 5 minutes.
- **Server seed** — a random 32-byte string the server generates for
  each spin or draw. Combined with the wallet and date to produce
  the outcome. Stored in the audit log so the outcome can be
  re-derived and verified.
- **SIWE** — Sign-In With Ethereum. A standard message format that
  lets a user prove they control a wallet without sending a private
  key.
- **Spin / Daily spin** — the once-per-UTC-day wheel users can spin
  to win a prize.
- **Streak** — the number of consecutive UTC days a wallet has spun.
  Resets if the user misses more than 1.5 days.
- **Token** — in the context of this guide, a digital asset
  implemented as a smart contract on an EVM chain. In code, sometimes
  refers to the bearer of an authenticated session — that's a
  different "token" (the session cookie) and is unrelated.
- **Vesting** — the schedule over which an allocation of tokens
  unlocks. Measured in months in this admin panel.
- **VRF** — Verifiable Random Function. A third-party service (we
  mention Chainlink) that provides on-chain verifiable randomness.

---

*If you read this guide and something is missing, wrong, or unclear,
file a documentation issue against the project. The team lead should
be able to do every job in this guide without ever needing to read
code.*
