// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title ICrystalFlakCoin
 * @notice External interface for the CrystalFlakCoin (CFC) ERC-20 token.
 *         Consumers (frontends, indexers, exchanges) should integrate against
 *         this interface rather than the concrete contract.
 */
interface ICrystalFlakCoin {
    /// @notice The fixed maximum supply of the token.
    function MAX_SUPPLY() external view returns (uint256);

    /// @notice The maximum supply (function form, mirrors the constant).
    function maxSupply() external view returns (uint256);

    /// @notice The current circulating supply (total minus burned).
    function circulatingSupply() external view returns (uint256);

    /// @notice Returns the contract owner (zero address if renounced).
    function owner() external view returns (address);

    /// @notice Renounce ownership, making the contract fully immutable.
    function renounce() external;

    /// @notice Burn the caller's own tokens.
    function burn(uint256 amount) external;

    /// @notice Burn tokens from another account (with allowance).
    function burnFrom(address account, uint256 amount) external;

    /// @notice EIP-2612 permit for gasless approvals.
    function permit(
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external;

    /// @notice EIP-712 domain separator.
    function DOMAIN_SEPARATOR() external view returns (bytes32);

    // Standard ERC-20 events
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    // Custom event
    event OwnershipRenounced(address indexed previousOwner);
}
