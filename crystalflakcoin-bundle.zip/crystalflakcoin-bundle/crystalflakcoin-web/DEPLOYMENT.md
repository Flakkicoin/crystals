# CrystalFlakCoin (CFC) — Production Deployment Guide

This document explains, step by step, how to take the **CrystalFlakCoin (CFC)** web
platform from a clean clone to a publicly served, production-hardened deployment.

> **What this guide is not.** It is not a guide to deploying the on-chain CFC
> token contract itself (that lives in a separate repository) and it is not legal,
> financial, or tax advice. The website is a **read-mostly** product that reads
> public-chain state, with a small authenticated admin surface for content.

> **Honesty by design.** Some of the values in `.env.example` contain `CHANGE_ME`.
> The application is built so that empty/`CHANGE_ME` values cause the UI to render
> a "Not yet deployed" or "To be announced" placeholder rather than a fabricated
> value. **You do not have to fill every variable to ship a working site.**

---

## Table of contents

1. [Pre-flight checklist](#1-pre-flight-checklist)
2. [Three deployment targets](#2-three-deployment-targets)
   - [2.1 Vercel (managed Next.js)](#21-vercel-managed-nextjs)
   - [2.2 Render (managed with Postgres)](#22-render-managed-with-postgres)
   - [2.3 Fly.io (with Docker)](#23-flyio-with-docker)
3. [Database migration & seed](#3-database-migration--seed)
4. [Post-deploy verification](#4-post-deploy-verification)
5. [Custom domain & SSL](#5-custom-domain--ssl)
6. [Monitoring](#6-monitoring)
7. [Backup & disaster recovery](#7-backup--disaster-recovery)
8. [Rollback procedure](#8-rollback-procedure)
9. [Cost estimates](#9-cost-estimates)
10. [First 30 minutes after launch](#10-first-30-minutes-after-launch)

---

## 1. Pre-flight checklist

Work through this list **before** you open the first deploy UI. Every item either
blocks the build (❗) or blocks a feature (🟡). Optional polish items are 🟢.

### 1.1 Local prerequisites

- **Node.js ≥ 18.18** (the `package.json` `engines` field requires it; Node 20 is
  what the `Dockerfile` pins via `NODE_VERSION=20-alpine`).
- **npm 10+** (ships with Node 20).
- **Postgres 14+** locally *or* a managed Postgres URL.
- **Git** with push access to the deploy target.
- **Docker** (only for the Fly.io / generic-Docker target).

Generate the session secret once and copy it somewhere safe:

```bash
openssl rand -base64 32
# e.g. 188lvhW6tQJjm99pksoW8li+uwGWHmfcZ/XNasxv8j4fgaX3cC0NOYdDnGG0qbUA
```

> **Why 32+ bytes?** `src/lib/env.ts` validates `SESSION_PASSWORD` with
> `z.string().min(32)` and `iron-session` requires at least 32 chars. If you set
> a shorter value in production, the app **refuses to start**.

### 1.2 Environment variables — required vs optional

The authoritative list is `.env.example`; the validator is `src/lib/env.ts`.
Below is the practical breakdown.

#### ❗ Required (app will refuse to start in production without them)

| Variable | Example | Notes |
|---|---|---|
| `NODE_ENV` | `production` | Set by the platform; never set this to `development` on a public deploy. |
| `NEXT_PUBLIC_APP_URL` | `https://crystalflakcoin.example` | The canonical absolute URL. Used by sitemap, robots, and absolute links. |
| `DATABASE_URL` | `postgresql://user:pass@host:5432/crystalflakcoin?sslmode=require` | Postgres connection string. Use `?sslmode=require` against any managed provider. |
| `DIRECT_DATABASE_URL` | *(same as `DATABASE_URL` unless your provider requires a separate non-pooling URL)* | Prisma reads this for migrations on platforms that have a pooler (e.g. Supabase, Neon). |
| `SESSION_PASSWORD` | `188lvhW6tQJjm99pksoW8li+uwGWHmfcZ/XNasxv8j4fgaX3cC0NOYdDnGG0qbUA` | **32+ random bytes, base64.** Generate with `openssl rand -base64 32`. |

#### 🟡 Strongly recommended (set these or the corresponding feature is degraded)

| Variable | Example | Why |
|---|---|---|
| `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | from <https://cloud.walletconnect.com> | Without this, the wallet-connect modal is in "degraded" mode and may rate-limit users. **Sign up is manual** — you need a WalletConnect Cloud account. |
| `SESSION_COOKIE_NAME` | `cfc_session` | Defaults are fine; override only if you run multiple environments on the same domain. |
| `NEXT_PUBLIC_SUPPORTED_CHAIN_IDS` | `1,11155111` | Comma-separated. Defaults are Ethereum + Sepolia. Add or remove once you decide which chains to support. |
| `ETHEREUM_RPC_URL` | `https://eth.llamarpc.com` or your Alchemy/Infura URL | Server-side RPC for SIWE verification (`src/lib/auth.ts`). Defaults to a public node. |
| `SEPOLIA_RPC_URL` | `https://ethereum-sepolia-rpc.publicnode.com` | Testnet RPC for SIWE on Sepolia. |
| `NEXT_PUBLIC_BLOCK_EXPLORER_URL` | `https://etherscan.io` | Used in the UI for "view on explorer" links. |
| `NEXT_PUBLIC_SUPPORT_EMAIL` | `support@your-domain` | Shown on `/contact`. |
| `NEXT_PUBLIC_SECURITY_EMAIL` | `security@your-domain` | Shown on `/contact` and `/legal`. **Use a real inbox.** |
| `NEXT_PUBLIC_GITHUB_URL` | `https://github.com/your-org/crystalflakcoin` | Shown in the footer. |

#### 🟢 Optional polish (set when you're ready, app boots without them)

| Variable | Example | Why |
|---|---|---|
| `ADMIN_BOOTSTRAP_EMAIL` | `you@your-domain` | Only consumed by `npm run db:seed` to create the first admin. If unset, you must create the first admin manually via `prisma studio` or a SQL insert. |
| `ADMIN_BOOTSTRAP_PASSWORD` | *random 24+ chars* | Same. **Rotate on first login.** |
| `ETHERSCAN_API_KEY` | from <https://etherscan.io/apis> | Higher rate limits for verified-tx history. Manual signup; free tier exists. |
| `NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS` | `0x…` (EIP-55 checksum) | Leave **empty** until the contract is deployed and verified. The UI will render a "Not yet deployed" badge. |
| `NEXT_PUBLIC_TOKEN_NETWORK` | `Ethereum Mainnet` | Pair with the address above. |
| `RATE_LIMIT_PROVIDER` + `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN` | `upstash` + Upstash creds | Use a managed Upstash Redis if you want rate limits shared across multiple Next.js instances. Single-instance deploys are fine with `memory` (the default). |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASSWORD` / `SMTP_FROM` | Your SMTP relay | Required to actually deliver the contact form and security-report emails. **Not required to deploy** — the form will still record reports to the DB. |
| `NEXT_PUBLIC_ENABLE_SWAP` / `…_STAKE` / `…_GOVERNANCE` | `false` | Feature flags. Default to `false`. Flip to `true` only when the corresponding backend (contracts, contracts, contracts) is real and verified. |
| `NEXT_PUBLIC_TWITTER_URL` / `…_DISCORD_URL` / `…_TELEGRAM_URL` / `NEXT_PUBLIC_DOCS_URL` / `NEXT_PUBLIC_AUDIT_URL` | real URLs | Social/links. Leave empty to hide the icon. |
| `SESSION_TTL_SECONDS` | `86400` | Default 24h. |
| `PORT` | `3000` | Default. Platforms set this for you. |

### 1.3 Manual account signups you almost certainly need

These are **not** part of this repo and require you to create accounts by hand:

- **WalletConnect Cloud** — <https://cloud.walletconnect.com> → create a project →
  copy the Project ID into `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`. Free.
- **Etherscan API key** — <https://etherscan.io/apis> → sign up → create a free
  API key → paste into `ETHERSCAN_API_KEY`.
- **SMTP provider** — anything that gives you STARTTLS on port 587 works
  (Resend, Postmark, Amazon SES, Mailgun, your own Postfix). For low volume,
  Resend/Postmark free tiers are fine.
- **(Optional) Upstash Redis** — <https://upstash.com> → create a global REST
  token → put the URL + token into the env vars. Only needed for multi-instance
  rate limiting.
- **Custom domain registrar access** — so you can add the DNS records in §5.
- **(Optional) Uptime monitor** — <https://healthchecks.io> (free tier is fine),
  Better Stack, or your platform's built-in monitor.

### 1.4 Build-time sanity

The repo runs two gates on every build:

1. `prebuild` → `node scripts/legacy-brand-scan.mjs` (fails if a forbidden
   legacy brand term or misleading financial claim is present in source).
2. `npm run build` → `prisma generate && next build` (uses the `standalone`
   output in `next.config.mjs`).

Both must pass locally before you push:

```bash
npm ci
npm run typecheck
npm run lint
npm run test           # unit + integration
npm run brand:scan     # legacy-brand scanner
npm run build          # prisma generate + brand scan + next build
```

If `npm run build` succeeds locally, you are ready to deploy.

---

## 2. Three deployment targets

The repo already ships everything each target needs:

- `Dockerfile` — multi-stage, non-root user, healthcheck, standalone output
  (`Dockerfile` lines 23–39).
- `docker-compose.yml` — local Postgres + app for fully self-hosted dev.
- `next.config.mjs` — `output: 'standalone'` so Vercel can use a single bundle.
- `package.json` — `prisma:deploy` script (`prisma migrate deploy`).

Choose **one** of the three options below. They are alternatives, not a chain.

### 2.1 Vercel (managed Next.js)

**Best for:** fastest time-to-public, zero ops, automatic preview deploys on PRs.
**Trade-off:** managed Postgres is *not* included; you bring your own (Neon,
Supabase, or Render Postgres are common pairings).

#### Steps

1. **Create a Vercel account** at <https://vercel.com> and connect your Git
   provider (GitHub/GitLab/Bitbucket).

2. **Import the repository.** New Project → pick `crystalflakcoin-web`. Vercel
   auto-detects Next.js and proposes these defaults:
   - Build command: `npm run build`
   - Output: leave empty (Next.js default)
   - Install: `npm ci`
   - Root directory: `./`

3. **Add a managed Postgres database.** The cheapest path is **Neon**:
   - <https://neon.tech> → create project → pick the region nearest your
     visitors → copy the **pooled** connection string.
   - In Neon, branch the database for preview deploys if you want each PR
     to get its own DB.
   - Copy the **direct (non-pooled)** connection string too. On Neon the
     "direct" string ends in `-pooler` *off* (you can disable pooling in the
     connection details). Vercel needs both: `DATABASE_URL` (pooled) and
     `DIRECT_DATABASE_URL` (direct) — Prisma's `migrate deploy` must use a
     direct connection.

4. **Configure environment variables** in the Vercel project settings
   (`Settings → Environment Variables`). Add **every** variable from §1.2
   using the **Production**, **Preview**, and/or **Development** scopes.
   - For preview deploys, you can keep `ADMIN_BOOTSTRAP_*` blank — the seed
     will skip admin creation on those.
   - Vercel automatically sets `NODE_ENV=production` and `PORT`; do not
     override them.

5. **First deployment** (the critical one — this is when migrations run):
   - Push to `main`. Vercel triggers a build.
   - The build runs `npm run build`, which calls `prisma generate`. **It does
     not run migrations.** See step 6.

6. **Run migrations.** Vercel supports a "post-deploy" command via a Deploy
   Hook or, more cleanly, via a one-off job. Two clean approaches:

   **Option A (recommended): Vercel "Build Command" runs `prisma migrate deploy` first.**
   Set the Build Command to:
   ```bash
   npx prisma migrate deploy && npm run build
   ```
   Pros: simple, runs on every deploy. Cons: migrations run on **Preview**
   deploys too, which is usually fine if each preview has its own DB.

   **Option B: run migrations from your laptop against the production DB.**
   ```bash
   # Locally, with the production DATABASE_URL in your shell
   export DATABASE_URL='postgresql://...'
   npx prisma migrate deploy
   ```
   Then trigger a Vercel redeploy (or push an empty commit).

7. **Seed (optional but recommended once).** From your laptop:
   ```bash
   export DATABASE_URL='postgresql://...'
   export ADMIN_BOOTSTRAP_EMAIL='you@your-domain'
   export ADMIN_BOOTSTRAP_PASSWORD='<strong random>'
   npm run db:seed
   ```
   This creates the default `ADMIN`/`EDITOR`/`VIEWER` roles, the two
   `SupportedNetwork` rows (Ethereum + Sepolia), the placeholder
   `TokenMetadata` row, the default `RandomnessConfig`, and the bootstrap
   admin user. **Sign in immediately and change the password.**

8. **Verify.** Jump to §4.

9. **(Optional) Add a custom domain.** See §5.

#### Vercel-specific gotchas

- `next.config.mjs` already declares `output: 'standalone'`. Vercel **ignores**
  this setting and uses its own serverless build; the flag is there for Docker.
- `iron-session` (used for admin login) works on Vercel but requires the cookie
  to be set with `secure: true`, which `src/lib/auth.ts` already does when
  `NODE_ENV === 'production'`. Make sure your preview URL is HTTPS too (Vercel
  handles this for `*.vercel.app` automatically).
- `argon2` (used for password hashing) **does compile under Vercel** as of the
  version pinned in `package.json` (0.41.x) — no need for a special build.
- The `Output: 'standalone'` setting will cause `next build` to emit
  `.next/standalone/` — harmless on Vercel, used by Docker.

---

### 2.2 Render (managed with Postgres)

**Best for:** you want a single dashboard for the web service **and** the
Postgres database. Render's "Blueprint" workflow can stand up both from a
`render.yaml` in the repo.
**Trade-off:** cold starts on the free tier, build times are slower than Vercel.

#### Steps

1. **Create a Render account** at <https://render.com>.

2. **(Option A) Blueprint deploy from `render.yaml`.** Create a
   `render.yaml` in the repo root (commit it; one-time cost):
   ```yaml
   services:
     - type: web
       name: crystalflakcoin-web
       runtime: node
       plan: starter          # or 'standard' for production
       region: oregon          # pick your region
       buildCommand: npm ci && npx prisma generate && npm run build
       startCommand: npx prisma migrate deploy && npm start
       healthCheckPath: /api/health
       envVars:
         - key: NODE_ENV
           value: production
         - key: DATABASE_URL
           fromDatabase:
             name: crystalflakcoin-db
             property: connectionString
         - key: DIRECT_DATABASE_URL
           fromDatabase:
             name: crystalflakcoin-db
             property: connectionString
         # Add the rest of §1.2 here, or via the dashboard.
         - key: SESSION_PASSWORD
           generateValue: true     # Render will set a random one
   databases:
     - name: crystalflakcoin-db
       plan: starter             # 256 MB / $7/mo
       postgresMajorVersion: "16"
   ```
   Commit, push, then in Render: **New → Blueprint** → select the repo →
   Apply. Render provisions the DB, links `DATABASE_URL`, builds, and runs
   `prisma migrate deploy && npm start` on every push.

   **(Option B) Manual setup.** In Render:
   - **New → PostgreSQL** → name `crystalflakcoin-db` → choose plan →
     create. Copy the **Internal** connection string (use it from your web
     service) and the **External** one (for laptop migrations).
   - **New → Web Service** → connect the repo → environment `Node` →
     build `npm ci && npx prisma generate && npm run build` →
     start `npx prisma migrate deploy && npm start` → add the env vars from
     §1.2.

3. **Add a healthcheck.** In the web service settings, set
   **Health Check Path** to `/api/health`. Render will mark the deploy
   successful only after this returns 200.

4. **Seed the database** (once). From your laptop:
   ```bash
   export DATABASE_URL='<Render EXTERNAL database URL>'
   export ADMIN_BOOTSTRAP_EMAIL='you@your-domain'
   export ADMIN_BOOTSTRAP_PASSWORD='<strong random>'
   npm run db:seed
   ```

5. **Verify.** See §4.

6. **(Optional) Custom domain.** See §5.

#### Render-specific gotchas

- Render's free web plan **spins down after 15 min of no traffic** and
  cold-starts on the next request. Don't use it for production; pick
  `starter` ($7/mo) or higher.
- The `startCommand` runs in the web service container, *not* in a separate
  one-off job. If a migration fails, the previous version keeps running
  (because `npm start` never executes). Watch the deploy logs.
- Render's Postgres `starter` plan is 256 MB — fine for thousands of
  daily spins. Upgrade to `basic` ($20/mo, 1 GB) when you start storing
  lots of audit-log rows.
- The `standalone` Next.js build is **not** used by Render (it runs
  `npm start` in the regular Node runtime). This is fine — just slightly
  larger image.

---

### 2.3 Fly.io (with Docker)

**Best for:** multi-region, low cost at small scale, you want the bundled
`Dockerfile` to do the work. **Trade-off:** you own the runtime (logs, scale,
restarts).

#### Steps

1. **Install the Fly CLI** and sign in:
   ```bash
   curl -L https://fly.io/install.sh | sh
   fly auth signup        # or: fly auth login
   ```

2. **Launch from the repo root:**
   ```bash
   fly launch --no-deploy
   ```
   - It detects the `Dockerfile` and proposes an app name and region.
   - Decline the "create Postgres now?" prompt — we'll use Fly Postgres
     separately so we can size it correctly.
   - It writes a `fly.toml`; review it. The relevant bits should look like:
     ```toml
     app = "crystalflakcoin-web"
     primary_region = "iad"

     [build]
       # uses the existing Dockerfile

     [env]
       PORT = "3000"
       NODE_ENV = "production"

     [[services]]
       internal_port = 3000
       protocol = "tcp"
       [[services.ports]]
         port = 80
         handlers = ["http"]
         force_https = true
       [[services.ports]]
         port = 443
         handlers = ["tls", "http"]
       [services.concurrency]
         type = "connections"
         hard_limit = 250
         soft_limit = 200

       [[services.tcp_checks]]
         grace_period = "10s"
         interval = "30s"
         timeout = "5s"

       [[services.http_checks]]
         interval = "30s"
         timeout = "5s"
         grace_period = "20s"
         method = "get"
         path = "/api/health"
     ```

3. **Provision Postgres on Fly:**
   ```bash
   fly postgres create --name crystalflakcoin-db --region iad --vm-size shared-cpu-1x --volume-size 10
   fly postgres attach crystalflakcoin-db --app crystalflakcoin-web
   ```
   The `attach` step sets `DATABASE_URL` as a Fly app secret. Add
   `DIRECT_DATABASE_URL` to match (Fly's attach only sets one):
   ```bash
   fly secrets set DIRECT_DATABASE_URL='<same connection string>'
   ```

4. **Set every other secret:**
   ```bash
   fly secrets set \
     SESSION_PASSWORD='<openssl rand -base64 32>' \
     NEXT_PUBLIC_APP_URL='https://crystalflakcoin-web.fly.dev' \
     NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID='<from WalletConnect Cloud>' \
     NEXT_PUBLIC_SUPPORT_EMAIL='support@your-domain' \
     NEXT_PUBLIC_SECURITY_EMAIL='security@your-domain' \
     NEXT_PUBLIC_GITHUB_URL='https://github.com/your-org/crystalflakcoin' \
     ETHERSCAN_API_KEY='<from etherscan.io>' \
     SMTP_HOST='smtp.resend.com' \
     SMTP_PORT='587' \
     SMTP_USER='resend' \
     SMTP_PASSWORD='<resend key>' \
     SMTP_FROM='"CrystalFlakCoin Security <security@your-domain>"'
   # `fly secrets` is for server-side vars; `fly env` is for NEXT_PUBLIC_*.
   fly env set \
     NEXT_PUBLIC_APP_URL='https://crystalflakcoin-web.fly.dev' \
     NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID='<id>' \
     NEXT_PUBLIC_SUPPORTED_CHAIN_IDS='1,11155111' \
     NEXT_PUBLIC_BLOCK_EXPLORER_URL='https://etherscan.io' \
     NEXT_PUBLIC_TOKEN_SYMBOL='CFC' \
     NEXT_PUBLIC_TOKEN_NAME='CrystalFlakCoin' \
     NEXT_PUBLIC_SUPPORT_EMAIL='support@your-domain' \
     NEXT_PUBLIC_SECURITY_EMAIL='security@your-domain' \
     NEXT_PUBLIC_ENABLE_SWAP='false' \
     NEXT_PUBLIC_ENABLE_STAKE='false' \
     NEXT_PUBLIC_ENABLE_GOVERNANCE='false'
   ```

   > **Note.** Fly treats `NEXT_PUBLIC_*` as build-time vars only when set
   > **before** the first build. If you add them later, run `fly deploy`
   > again to re-trigger a build that bakes them into the static bundle.

5. **First deploy (this runs migrations).** The `Dockerfile` runs the brand
   scanner and the build but not the migrations. Use a release command in
   `fly.toml`:
   ```toml
   [deploy]
     release_command = "npx prisma migrate deploy && node prisma/seed.js || true"
   ```
   (Replace `seed.js` with `npx tsx prisma/seed.ts` if you prefer the TS
   source — but that requires `tsx` in the runtime image, so pre-compile
   or do the seed from your laptop as in step 6.)
   Then:
   ```bash
   fly deploy
   ```
   Fly will: build the Docker image → run the release command (migrations) →
   roll the new machine in. If the release command exits non-zero, the
   deploy is rolled back automatically.

6. **Seed from your laptop (recommended):**
   ```bash
   # Get the connection string
   fly postgres connect -a crystalflakcoin-db
   # Or:
   fly secrets list --app crystalflakcoin-web   # DATABASE_URL is set
   # Then, on your laptop:
   export DATABASE_URL='<the Fly DATABASE_URL>'
   export ADMIN_BOOTSTRAP_EMAIL='you@your-domain'
   export ADMIN_BOOTSTRAP_PASSWORD='<strong random>'
   npm run db:seed
   ```

7. **Verify.** See §4.

8. **(Optional) Custom domain.** See §5.

#### Fly.io-specific gotchas

- Fly sets `NODE_ENV` to `production` automatically. Don't override it.
- The `Dockerfile` already runs as a non-root user (`nextjs`, UID 1001) and
  declares a `HEALTHCHECK` against `/api/health`. Fly's `http_checks` is
  the platform-level equivalent and is what triggers auto-restart.
- The standalone build emits `.next/standalone/server.js`, which is what
  the `CMD` runs. The image is ~150 MB.
- `fly scale count 2` to run two machines for HA. **But** in-memory rate
  limiting and iron-session sessions will not be shared — switch
  `RATE_LIMIT_PROVIDER` to `upstash` and put iron-session behind a
  shared session store if you scale out.

---

## 3. Database migration & seed

### 3.1 The migrations directory

The repo does **not** ship a `prisma/migrations/` directory (it was intentionally
not committed; you generate the first one locally). The first time you run a
migration, Prisma creates it.

### 3.2 Generate the first migration (local)

```bash
export DATABASE_URL='postgresql://cfc:cfc@localhost:5432/crystalflakcoin'
npx prisma migrate dev --name init
```

This creates `prisma/migrations/<timestamp>_init/migration.sql` and applies it
to the dev database. **Commit this directory** — production will read it.

> **If the schema has been changed since the first migration**, generate a new
> one with `npx prisma migrate dev --name <descriptive-slug>` and commit the
> new folder.

### 3.3 Apply migrations in production

Run **once per deploy** (or once total if the schema is stable):

```bash
npx prisma migrate deploy
```

- **Vercel** — add it to the Build Command (see §2.1 step 6) or run from
  your laptop with the production `DATABASE_URL`.
- **Render** — already in the `startCommand` (see §2.2).
- **Fly.io** — in the `release_command` (see §2.3).

`migrate deploy` is **idempotent** — it only applies migrations that haven't
been applied yet. It is safe to run on every deploy.

### 3.4 Seed initial data

```bash
ADMIN_BOOTSTRAP_EMAIL='you@your-domain' \
ADMIN_BOOTSTRAP_PASSWORD='<random 24+ chars>' \
  npm run db:seed
```

What this creates (`prisma/seed.ts`):

- 3 `Role` rows: `ADMIN`, `EDITOR`, `VIEWER` with their permission arrays.
- 1 `TokenMetadata` row clearly marked `isDeployed: false` — the admin must
  set the real contract address through `/admin/token` once the contract is
  deployed and verified.
- 2 `SupportedNetwork` rows: Ethereum Mainnet (chain 1) and Sepolia
  (chain 11155111). Add more from the admin panel.
- 1 `RandomnessConfig` row (`source: 'server'`).
- 1 `User` row with role `ADMIN` (only if the bootstrap env vars are set
  and don't contain `CHANGE_ME`).

It does **not** create fake tokenomics numbers, fake contract addresses,
or fake audits. Those have to be entered through the admin panel by a human.

> **Rotate the bootstrap password immediately.** Argon2id is used, so the
> hash is strong, but the bootstrap password was visible in your shell
> history and in your deploy secrets. Change it in `/admin` → user settings.

### 3.5 Idempotency

- `prisma migrate deploy` — safe to re-run.
- `prisma db seed` — uses `upsert` for roles and networks (safe to re-run).
  The bootstrap admin is created only if no admin exists yet. Re-running
  the seed against a populated DB is a no-op.

---

## 4. Post-deploy verification

Run these checks in order. Stop at the first failure and roll back (§8).

### 4.1 Health check (the platform-level one)

The platform healthcheck (Render / Fly / your uptime monitor) should hit
`/api/health` every 30s. The endpoint returns:

```json
{
  "status": "ok",
  "db": true,
  "uptime": 142.34,
  "responseTimeMs": 7,
  "timestamp": "2025-01-15T12:34:56.789Z"
}
```

If `db: false`, **the app cannot reach Postgres** — check the connection
string, network rules (e.g. Render Postgres "internal" URL only works
from Render web services in the same region/account), and SSL mode.

From your laptop:

```bash
curl -sS https://crystalflakcoin.example/api/health | jq
```

### 4.2 Build-time brand scan

This already ran as `prebuild`. To re-verify on a running deployment,
run it against a clone:

```bash
node scripts/legacy-brand-scan.mjs
# [brand-scan] OK — scanned 423 files in 87ms. No forbidden terms found.
```

If you see a `FAIL` line, **do not ship that build**. A new contributor
likely introduced a forbidden term — reject the PR.

### 4.3 Brand audit on the live site

Curl the public pages and grep for the forbidden terms (e.g. "guaranteed
profit", "iCoinPro", "risk-free"). This is not strictly necessary because
the scanner is in the build, but it catches a CMS-style update bypassing CI:

```bash
for page in / /about /token /tokenomics /stake /swap /governance /faq; do
  curl -sS "https://crystalflakcoin.example$page" \
    | grep -iE 'guaranteed profit|risk-free|iCoinPro|Legacy Bonus|passive income' \
    && echo "FORBIDDEN on $page" || echo "ok: $page"
done
```

### 4.4 Smoke test the daily spin

The daily-prize spin endpoint is the one user-facing write path. Test it
end-to-end with a fresh wallet address (a real wallet you control — never
use a private-key-generating tool in CI).

```bash
# 1. Get status
curl -sS https://crystalflakcoin.example/api/daily-prize/status \
  -H 'x-cfc-wallet: 0x0000000000000000000000000000000000000001' \
  -H 'x-cfc-chain: 1' | jq

# 2. Get a nonce
curl -sS https://crystalflakcoin.example/api/daily-prize/nonce \
  -H 'x-cfc-wallet: 0x0000000000000000000000000000000000000001' \
  -H 'x-cfc-chain: 1' | jq

# 3. Spin (replace $NONCE with the value from step 2)
curl -sS -X POST https://crystalflakcoin.example/api/daily-prize/spin \
  -H 'Content-Type: application/json' \
  -H 'x-cfc-wallet: 0x0000000000000000000000000000000000000001' \
  -H 'x-cfc-chain: 1' \
  -H "x-cfc-nonce: $NONCE" | jq
```

Expected response shape (truncated):

```json
{
  "ok": true,
  "authMethod": "nonce",
  "randomness": { "source": "server", "seed": "…", "proof": "…" },
  "prize": { "code": "…", "label": "…", "points": 5, "raffles": 0 },
  "streak": { "current": 1, "longest": 1, "wasReset": false },
  "nextSpinAt": "2025-01-16T00:00:00.000Z"
}
```

If you see `429` saying you already claimed today, you have just confirmed
the cooldown is working. Wait until UTC midnight and try again.

### 4.5 Admin sign-in

1. Visit `https://crystalflakcoin.example/admin/login`.
2. Sign in with `ADMIN_BOOTSTRAP_EMAIL` / `ADMIN_BOOTSTRAP_PASSWORD`.
3. Immediately change the password.
4. Visit `/admin` and confirm the five stat cards render (Users, Token rows,
   Allocations, Proposals, Security reports) and that the "Recent audit logs"
   list contains at least your `admin.login` row.

### 4.6 Security headers

```bash
curl -sSI https://crystalflakcoin.example/ | grep -iE \
  'strict-transport|content-security|x-frame|x-content-type|referrer-policy|permissions-policy'
```

All six should be present, set by `next.config.mjs`.

### 4.7 robots.txt and sitemap

```bash
curl -sS https://crystalflakcoin.example/robots.txt
curl -sS https://crystalflakcoin.example/sitemap.xml | head
```

`robots.txt` must disallow `/admin` and `/api`. The sitemap must list the
public routes with `NEXT_PUBLIC_APP_URL` as the base.

---

## 5. Custom domain & SSL

The platforms handle certificate provisioning automatically once DNS is
correct. You only need to set up DNS — the platform does the rest.

### 5.1 DNS records

For the **apex** `crystalflakcoin.example`:

| Type | Host | Value |
|---|---|---|
| `ALIAS` / `CNAME` (if your registrar supports it) or `A` | `@` | platform's load-balancer address (see below) |
| `TXT` | `@` | platform-specific verification record (e.g. Vercel's `vc-domain-verify=…`) |

For the **`www.`** subdomain:

| Type | Host | Value |
|---|---|---|
| `CNAME` | `www` | `<platform-provided>.vercel-dns.com` (or equivalent) |

For each platform:

- **Vercel** — Project → Settings → Domains → add `crystalflakcoin.example`
  → Vercel tells you the exact A record or CNAME target. They also issue
  the Let's Encrypt cert automatically.
- **Render** — Web Service → Settings → Custom Domain → add domain → Render
  shows the CNAME target (`<app>.onrender.com`). The cert is issued by
  Render automatically (Let's Encrypt).
- **Fly.io** — `fly certs create crystalflakcoin.example` → fly prints the
  DNS A records you need to add → cert is issued by Let's Encrypt via Fly.

### 5.2 WWW → apex (or vice versa)

Pick one canonical URL and redirect the other. Vercel and Render both let you
add both and pick a primary. For Fly, do it in the app:

```ts
// next.config.mjs redirect block (example)
async redirects() {
  return [{ source: '/(.*)', destination: 'https://crystalflakcoin.example/$1',
            permanent: true, has: [{ type: 'host', value: 'www.crystalflakcoin.example' }] }];
}
```

### 5.3 HSTS

`next.config.mjs` already sets
`Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`
on every response. Once you are confident you will not need plain HTTP for
subdomains, submit to <https://hstspreload.org>.

### 5.4 DNS propagation

TTL is typically 5–30 minutes. Use `dig crystalflakcoin.example +short` or
<https://dnschecker.org> to confirm the record is live before testing SSL.

---

## 6. Monitoring

### 6.1 Uptime monitoring (must-have)

Point **two** independent uptime monitors at `https://crystalflakcoin.example/api/health`.
The reason for two: a single monitor can have its own outage and cause
alert fatigue.

Recommended free / cheap services:

- **Healthchecks.io** — <https://healthchecks.io> — schedule-based pings,
  alerting via email/Slack. **Doesn't ping your site**; instead, set up
  Healthchecks as the recipient of an external monitor's failure webhook.
- **Better Uptime** — <https://betteruptime.com> — does real HTTP checks,
  free tier covers 1 monitor at 3-min interval.
- **UptimeRobot** — <https://uptimerobot.com> — 50 monitors free at 5-min
  interval.
- **Vercel / Render / Fly built-in** — every platform has a basic monitor
  that flips the deployment status to "unhealthy" when `/api/health` fails.

Recommended config: check every 60s, alert after **2 consecutive failures**
(avoids one-off blips), 10s timeout, expect `200` with body containing
`"db":true`.

### 6.2 Log aggregation

- **Vercel** — built-in. Logs → Production. Search by request path,
  status, or `x-vercel-id`. Retention: 1h on Hobby, 30 days on Pro, 90 days
  on Enterprise.
- **Render** — built-in. Logs → Service. Free retention ~1 week; paid
  plans extend. You can stream to a log drain (Papertrail, Datadog).
- **Fly.io** — `fly logs` CLI or the dashboard. Free tier: 1h retention.
  For longer retention, attach a [log shipper](https://fly.io/docs/monitoring/log-shippers/):
  - **Axiom** (cheap, generous free tier) — recommended.
  - **Datadog** — if you already use it.
  - **Papertrail** — classic, simple, free tier is 100 MB/month.

### 6.3 Error tracking (recommended)

The app uses `console.error` for audit failures and other unhandled paths,
not a structured logger. Adding **Sentry** is the highest-leverage
observability win:

1. `npm install @sentry/nextjs` (uncommitted; add to `package.json`).
2. `npx @sentry/wizard@latest -i nextjs` → creates `sentry.client.config.ts`,
   `sentry.server.config.ts`, and the instrumentation hook.
3. Add `SENTRY_DSN` to your env vars.
4. Add `SENTRY_DSN` to `runtime.txt`-equivalent on the platform.

If you skip Sentry, at least pipe logs to a single place so a 3am page can
be investigated without SSH.

### 6.4 What to alert on

- **HTTP 5xx on `/api/health` or `/` for > 1 minute.**
- **Health endpoint reports `db: false`.**
- **Postgres CPU > 80% for > 10 minutes** (Render/Fly/Neon dashboards).
- **Audit-log row count suddenly drops to 0** (would mean the app can't
  write — but the app degrades gracefully, so check the log for
  `[audit] failed to write audit log`).
- **More than 10 `rate-limit` 429s per minute on `/api/daily-prize/spin`**
  from a single IP (someone is scripting the spin).

---

## 7. Backup & disaster recovery

### 7.1 What to back up

| Asset | Where it lives | How to back up | RPO target | RTO target |
|---|---|---|---|---|
| Postgres data | Managed DB | Managed provider's automated backup | 1 hour | 1 hour |
| Postgres logical dump | Local / S3 | `pg_dump` (see below) | 24 hours | 1 hour |
| Audit log | `AuditLog` table in Postgres | Same as Postgres data | same | same |
| Source code | Git | The repo itself | 0 (every commit is a backup) | minutes |
| `.env` secrets | Platform secret manager | Export manually once, store in 1Password / Vault | 0 (managed by platform) | minutes |
| Brand scanner forbidden list | `src/lib/brand.ts` | Git | 0 | minutes |
| Migration files | `prisma/migrations/` | Git | 0 | minutes |
| Iron-session cookie key | `SESSION_PASSWORD` env var | Same as `.env` | 0 | minutes |
| SMTP credentials | env var | Same as `.env` | 0 | minutes |

> **The audit log is a database table (`AuditLog` in `prisma/schema.prisma`),**
> not a file. Backing up the database backs up the audit log. If you need
> a separate, append-only export for compliance, set up a daily
> `cron` job that streams new `AuditLog` rows to S3 / a write-once bucket.

### 7.2 Automated managed backups (what your provider gives you)

- **Render Postgres** — daily snapshot, 7-day retention on paid plans.
  You can restore to a new DB from any snapshot in the dashboard.
- **Fly Postgres** — daily snapshot for paid plans. `fly postgres backup
  create` / `restore`.
- **Neon** — point-in-time recovery (PITR) up to 7 days on the free tier,
  30 days on paid tiers. Branch from a timestamp.
- **Supabase** — daily backups, PITR available on Pro plan.

### 7.3 Logical backups (belt-and-braces)

Run `pg_dump` from a cron job (Render Cron Job, GitHub Actions schedule,
or a tiny Fly machine):

```bash
# Daily dump to a private S3 bucket (use IAM role, not keys)
pg_dump "$DATABASE_URL" --format=custom --no-owner --no-privileges \
  | aws s3 cp - s3://cfc-backups/daily/$(date -u +%Y%m%dT%H%M%SZ).dump

# Weekly full + daily incrementals is overkill for this app's size.
# Daily is enough.
```

Restore (only in a real disaster):

```bash
# Create a fresh empty DB on your provider, then:
pg_restore --clean --no-owner --no-privileges \
  --dbname="$DATABASE_URL" /path/to/backup.dump
```

Then re-run `npx prisma migrate deploy` (idempotent — it will see all
migrations as already applied if the backup was taken after they ran) and
`npm run db:seed` is **not** needed (the dump already contains the seed
rows; re-running would just upsert no-ops).

### 7.4 Audit-log-only export (optional, for compliance)

If you ever need a separate audit-log copy, run this once a day:

```sql
COPY (SELECT * FROM "AuditLog"
      WHERE "createdAt" > now() - interval '1 day'
      ORDER BY "createdAt" ASC)
TO PROGRAM 'gzip > /var/log/cfc-audit-$(date -u +%Y%m%d).sql.gz';
```

(You will need to run this as a Postgres superuser inside a secure job.)

### 7.5 Restoring after a database is wiped

1. Provision a new database on your provider.
2. Get the new `DATABASE_URL`.
3. From your laptop: `npx prisma migrate deploy` against the new DB
   (this re-applies the schema).
4. `pg_restore` the latest good `pg_dump` (see §7.3).
5. Update the platform's `DATABASE_URL` secret.
6. Redeploy.
7. Run §4.1 (`/api/health`) and §4.4 (smoke spin) to confirm.

---

## 8. Rollback procedure

### 8.1 Vercel

Vercel keeps every successful deploy. Rollback is one click:

- Deployments → click a previous successful deployment → "Promote to
  Production".

The platform re-points the edge to the previous build in < 30 seconds.
**Database migrations are not rolled back** — only application code.

### 8.2 Render

Render has a "Rollback" button on every deploy. **Or** trigger a redeploy
of the previous git SHA:

- Manual Deploy → enter the previous commit SHA → Deploy.

Render redeploys the old image in a few minutes.

### 8.3 Fly.io

Fly keeps the previous machine running during a release until the new one
passes its healthcheck. If the new release fails, it auto-rolls back. To
force a rollback:

```bash
# List recent releases
fly releases --app crystalflakcoin-web

# Roll back to a specific version
fly releases rollback --app crystalflakcoin-web v<previous-version-number>
```

### 8.4 If the bug is in a database migration

The repo never runs destructive migrations (no `DROP COLUMN`, no `DROP TABLE`)
in a forward direction. But if a future migration breaks the app:

1. Roll back the application code first (§8.1 / §8.2 / §8.3).
2. The app should come up — Prisma's `prisma migrate deploy` does not
   auto-undo.
3. If the bad migration is making the app start fail, comment out the
   `prisma migrate deploy` in the start command temporarily, roll forward
   a new migration that adds the column back, then restore the
   start command.
4. **Never edit a migration that has been applied in production.** Write
   a new one.

### 8.5 If the breach is "the deploy leaked a secret"

1. **Rotate the secret immediately** (do this before investigating).
2. Update the platform's secret store.
3. Redeploy — the new build will read the new value.
4. Audit the `AuditLog` for the time window the secret was exposed.
5. If the secret was a `SESSION_PASSWORD`, **all existing sessions are
   invalid** — every user has to sign in again. This is intentional.

### 8.6 Communicating a rollback

If the site is user-facing and the rollback takes more than 5 minutes:

- Post a status note on your public status page (or your X/Twitter).
- Update the in-app announcement (admin → announcements → severity: warning).

---

## 9. Cost estimates

> **Pricing disclaimer.** All numbers below are rough monthly **USD** ranges
> for **low-traffic** production (≈10k–100k pageviews/month, < 10k
> daily-prize spins/month, single-region). Your bill will change with
> traffic, region, and the platform's pricing changes — verify each
> provider's current pricing page before committing.

### 9.1 Vercel (Pro) + Neon Postgres

| Component | Tier | Rough monthly |
|---|---|---|
| Vercel Pro | 1 seat, 1 TB bandwidth included | $20 |
| Vercel overages | Function invocations, image opt, edge | $0–$30 |
| Neon Launch | 0.5 GB storage, 191 compute hours | Free (then $19 Launch) |
| Domain registration | .com | $12/year ≈ $1 |
| Email (Resend) | 3k emails/month | Free |
| Uptime monitor | Better Uptime free / UptimeRobot free | $0 |
| **Total (rough)** | | **$25–$70** |

### 9.2 Render Web Service + Render Postgres

| Component | Tier | Rough monthly |
|---|---|---|
| Render Web Service | Starter (512 MB, 0.5 CPU) | $7 |
| Render Web Service | Standard (2 GB, 1 CPU) — for higher traffic | $25 |
| Render Postgres | Starter 256 MB | $7 |
| Render Postgres | Basic 1 GB | $20 |
| Render overages | Bandwidth, build minutes | $0–$10 |
| Domain registration | .com | $1 |
| Email | Resend / Postmark | $0–$15 |
| **Total (rough)** | | **$15–$50** |

### 9.3 Fly.io (Docker) + Fly Postgres

| Component | Tier | Rough monthly |
|---|---|---|
| Fly shared-cpu-1x machine | 1 vCPU shared, 256 MB | ~$1.94 (~$5 with volume + IPv6) |
| Fly shared-cpu-1x machine | 2 vCPU shared, 1 GB (recommended prod) | ~$10–$15 |
| Fly Postgres | single node, 1 GB | ~$5–$10 |
| Fly volume | 10 GB | $1.50 |
| Outbound bandwidth | 100 GB included, then $0.02/GB | $0–$5 |
| Domain | .com | $1 |
| Email | Resend | $0–$15 |
| **Total (rough)** | | **$20–$50** |

### 9.4 Self-hosted (your own VPS)

| Component | Tier | Rough monthly |
|---|---|---|
| Hetzner / DigitalOcean / Vultr VPS | 2 vCPU, 4 GB, 80 GB SSD | $12–$24 |
| Managed Postgres (optional) | Or use the VPS for it | (free, +backup cost) |
| Backups (object storage) | Backblaze B2, 10 GB | $1 |
| DNS | Cloudflare free | $0 |
| Email | Resend / Postmark | $0–$15 |
| **Total (rough)** | | **$15–$40** |

> The self-hosted option is the cheapest but you own: TLS renewal, OS
> patching, log shipping, Postgres backups, monitoring, and the on-call
> pager. For a one-person team, Render or Fly is usually a better
> time-vs-money trade.

### 9.5 Where the bill grows

- **Bandwidth** (image-heavy pages, lots of visitors).
- **Function invocations** on Vercel for SSR (the daily-prize endpoint is
  dynamic; high spin volume increases the count).
- **Postgres storage** — audit log growth. A row is < 1 KB, so 1M rows ≈
  100 MB. Plan to archive or partition the `AuditLog` table once it
  exceeds ~ 5M rows.
- **Log retention** if you attach Axiom / Datadog.

---

## 10. First 30 minutes after launch

A focused checklist. Tick these off in order.

### 0:00–0:05 — health and DB

- [ ] `curl -sS https://your-domain/api/health | jq` → `status: "ok"`,
  `db: true`, `responseTimeMs < 100`.
- [ ] DNS resolves globally (`dig +short` from a few public resolvers).
- [ ] HTTPS works (no mixed-content warnings in the browser console).
- [ ] All six security headers present (see §4.6).

### 0:05–0:10 — admin

- [ ] Sign in to `/admin/login` with the bootstrap credentials.
- [ ] **Change the bootstrap password** to a 24+ char random value. Store
  in your password manager.
- [ ] Create a second admin user (a real one) and disable the bootstrap
  account, or just delete it.
- [ ] Visit `/admin` — confirm the 5 stat cards render and the recent
  audit logs include your login.

### 0:10–0:15 — content & placeholders

- [ ] `/token` — confirm the "Not yet deployed" badge shows (because
  `NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS` is empty). **This is correct.**
- [ ] `/tokenomics` — confirm the table is empty / shows "TBA" rather
  than fake numbers. **This is correct.**
- [ ] If the contract is genuinely live, fill it in via `/admin/token`
  and `/admin/tokenomics` and double-check the EIP-55 checksum.
- [ ] Update `NEXT_PUBLIC_SUPPORT_EMAIL` and `NEXT_PUBLIC_SECURITY_EMAIL`
  to real inboxes (rebuild required because they're `NEXT_PUBLIC_*`).

### 0:15–0:20 — public content sanity

- [ ] `/sitemap.xml` lists all 11 public routes.
- [ ] `/robots.txt` disallows `/admin` and `/api`.
- [ ] Open `/`, `/about`, `/faq`, `/legal` in a private window — check
  for typos, broken images, console errors.
- [ ] Run the brand scan remotely: `for page in / /about /token /stake
  /swap /governance /faq; do curl -sS "$URL$page" | grep -iE 'guaranteed
  profit|risk-free|iCoinPro|Legacy Bonus'; done` → must return nothing.

### 0:20–0:25 — daily spin smoke

- [ ] §4.4 end-to-end with a fresh wallet.
- [ ] Confirm the response includes `prize.code`, `prize.label`, a
  `randomness.seed`, and a `randomness.proof`.
- [ ] Confirm `nextSpinAt` is the next UTC midnight.
- [ ] Re-run the same wallet — confirm 429 ("already claimed today").
- [ ] Visit `/admin/logs` — confirm a `daily-prize.spin` row was written.

### 0:25–0:30 — monitoring & alerts

- [ ] Confirm the platform's healthcheck is green (Vercel/Render/Fly
  deployment status, plus your external uptime monitor).
- [ ] Subscribe your on-call channel (Slack / PagerDuty / email) to:
  - HTTP 5xx on `/api/health` for > 1 min
  - `db: false` for > 30s
  - Postgres CPU > 80% for > 10 min
- [ ] Trigger a test alert by temporarily breaking `/api/health` (e.g.
  point `DATABASE_URL` at an unreachable host, redeploy, verify the
  alert fires within 2 minutes, then restore).
- [ ] Confirm a recent deploy artifact (image SHA, git SHA) is recorded
  somewhere you can find it at 3am (screenshot, ticket, or
  `fly releases list` / Render dashboard bookmark).

### Done

If all 30-minute items are green, you are live. Bookmark this guide, save
the secrets in your team's password manager, and go enjoy the rest of your
day.

---

*If something in this guide disagrees with what you see in the codebase,
the **code is the source of truth** — open a PR correcting the guide. The
files to look at first: `package.json`, `Dockerfile`, `docker-compose.yml`,
`.env.example`, `src/lib/env.ts`, `prisma/schema.prisma`, `next.config.mjs`,
and `scripts/legacy-brand-scan.mjs`.*
