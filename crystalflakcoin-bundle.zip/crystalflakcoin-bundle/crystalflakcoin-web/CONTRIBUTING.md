# Contributing to CrystalFlakCoin (CFC) — Web Platform

Thanks for stopping by. This document explains how the project works today,
where we could genuinely use help, and how to get a change in front of us.

This is a small, pre-launch codebase run by a small team. Please read this
whole page before opening a Pull Request — it'll save everyone time, including
yours.

---

## Where we are

A few things to be upfront about:

- **The CFC token is not deployed yet.** Any on-chain value (price, supply,
  holders, contract address) shown in the UI is either read from a configured
  source or labeled "Not yet deployed" / "To be announced". The build enforces
  this with a brand/claim scanner — see `scripts/legacy-brand-scan.mjs`.
- **The platform is pre-token and pre-marketing.** We are not running growth
  campaigns, paid acquisition, or referral programs. We are not promising
  returns, yield, or any kind of compensation plan. `README.md` and
  `SECURITY.md` reflect that.
- **The license is "to be announced".** Until it is set, treat the code as
  source-available under the rights of the copyright holder. Third-party
  packages keep their own licenses (see `package.json`).
- **The admin panel is real and gated.** It's used by the maintainers to edit
  token metadata, tokenomics, and content. Default role grants are
  `ADMIN` / `EDITOR` / `VIEWER` — see `src/lib/auth.ts`.

In other words: the product exists; the token does not yet, and we are not
rushing to invent claims about it.

---

## What we need help with

These are the things that will actually move the project forward right now:

- **Bug reports.** Especially reproducible ones. Include the route, browser
  (if applicable), the exact request/response you saw, and what you expected.
  If a security issue is involved, **do not file a public Issue** — follow
  `SECURITY.md` instead.
- **Documentation improvements.** Typos, missing steps, unclear warnings, and
  extra examples in `README.md`, `DEPLOYMENT.md`, `ADMIN_GUIDE.md`, and the
  in-app FAQ (`/faq`) are all welcome. Risk disclosures are particularly
  important to get right.
- **Security audits and hardening suggestions.** We are explicitly inviting
  responsible review. See `SECURITY.md` for scope, response SLAs, and how to
  report. Out-of-scope testing against deployed infrastructure is **not**
  authorized.
- **Accessibility.** The UI is built on shadcn/ui + Radix primitives, but that
  is a starting point, not a finish line. Keyboard navigation, screen reader
  labels, focus order, and reduced-motion behavior are all areas we want help
  auditing and fixing.
- **Tests.** We have Jest + Playwright coverage but plenty of gaps. Adding
  tests for `src/lib/`, the public API surface in `src/app/api/`, and e2e
  flows around the daily-prize pages is high-value.
- **Prisma schema and migrations.** The 17 models in `prisma/schema.prisma`
  are versioned; well-scoped additions with a `prisma migrate dev --name ...`
  artifact and seed updates in `prisma/seed.ts` are welcome.

---

## What we don't need right now

To save everyone's time, here is the short list of contributions we are
**not** looking for at this stage:

- Marketing copy, taglines, or "positioning" rewrites.
- Fabricated metrics, "TVL", "holders", or "price" placeholders that look real.
  The build will reject them; please don't try.
- Growth-hacking integrations (referral scripts, UTM manipulation,
  cookie-stuffing, email-list plugins, etc.).
- Claims about returns, odds, win rates, ranking, or comparisons to other
  projects. The legacy-brand scanner enforces this — see
  `scripts/legacy-brand-scan.mjs`.
- "Quick-win" paid features or "Pro" tiers.

If a PR mostly contains the above, it will be closed. We'd rather you spend
your time on something we will actually merge.

---

## Code of conduct

We follow the principles of the [Contributor Covenant](https://www.contributor-covenant.org/):
be respectful, assume good faith, and do not harass. A full `CODE_OF_CONDUCT.md`
is on the to-do list; in the meantime, the same expectations apply to Issues,
Pull Requests, Discussions, and any other project space.

Maintainers may remove contributions or block accounts that violate these
expectations.

---

## How to submit issues

We use GitHub Issues for everything that is not a security disclosure.

- Search open and closed Issues before opening a new one.
- Use a descriptive title. "Spin wheel broken" is worse than
  "Daily-prize spin returns 500 on cooldown path when nonce is stale".
- Include reproduction steps, expected vs. actual behavior, and the relevant
  route (`/daily-prize`, `/admin/token`, etc.).
- For UI bugs, a screenshot or short screen recording is very helpful.
- For security issues, **do not** open a public Issue. Follow `SECURITY.md`.

There is no Issues URL hard-coded in this file because the canonical
repository URL has not been published yet; substitute your fork's URL when
forks start landing.

---

## How to submit Pull Requests

The mechanics:

1. **Branch from `main`.** Do not commit directly to `main`.
2. **One logical change per PR.** A bug fix and a refactor should be two PRs.
3. **All PRs run through the same gate:**
   - `npm run typecheck`
   - `npm run lint`
   - `npm test` (Jest)
   - `npm run test:e2e` (Playwright) for any user-facing change
   - `npm run brand:scan` — must pass; this is the same script the CI runs
   - `npm run build` — must complete cleanly
   The CI workflow in `.github/workflows/ci.yml` enforces all of the above.
4. **One approval is required** from a maintainer before merge. Approval means
   the change is correct, the tests are sufficient, and the brand scanner is
   clean.
5. **No direct commits to `main`.** Use a branch and a PR, even for small fixes.

A good PR description includes: what changed and why, how it was tested
(commands run, screenshots, sample API responses), and any follow-ups that are
out of scope for this PR.

If a PR touches security-sensitive code (auth, CSRF, rate limiting, the
admin surface, or security headers), tag a maintainer for an extra review
and reference `SECURITY.md`.

---

## Local development setup

See `README.md` for the full walkthrough. The short version:

```bash
cp .env.example .env
# Edit .env: set DATABASE_URL, SESSION_PASSWORD, and any NEXT_PUBLIC_* values.
npm install
npx prisma migrate dev --name init
npm run db:seed     # optional: seeds default roles, networks, and a token row
npm run dev         # → http://localhost:3000
```

Or with Docker:

```bash
cp .env.example .env
docker compose up --build
```

Tests:

```bash
npm test            # Jest unit + integration
npm run test:e2e    # Playwright (requires a running dev server)
npm run brand:scan  # standalone legacy-brand scan
```

`SECURITY.md` and `DEPLOYMENT.md` are worth skimming even if you're not
deploying — they explain the threat model and the assumptions the code makes.

---

## Style guide

- **TypeScript strict mode is on.** `tsconfig.json` enables `strict`; do not
  weaken it. If you find yourself reaching for `any`, use `unknown` and narrow
  with Zod or a type guard. `// eslint-disable-next-line @typescript-eslint/no-explicit-any`
  is **not** a default tool.
- **Validation goes through Zod.** Every API route in `src/app/api/` parses
  input with a Zod schema in `src/lib/validation.ts`. Do not roll your own
  validators.
- **File structure** — keep the existing layout:
  - `src/app/` — pages and API routes (App Router).
  - `src/components/` — UI primitives and feature components.
  - `src/lib/` — environment, prisma client, wagmi config, auth, validation,
    audit logging, rate limiting, CSRF, brand checks, chain utilities, and
    the daily-prize / raffle-draw domain logic.
  - `tests/` — `unit/`, `integration/`, and `e2e/`.
- **Imports** use the `@/` alias mapped to `src/`.
- **Styling** is Tailwind + shadcn/ui. Prefer the existing tokens (the "ice"
  / "crystal" variants) over one-off colors.
- **Server vs. client components** — default to server components. Mark a
  component `"use client"` only when it actually needs interactivity,
  browser APIs, or hooks.
- **Error handling** — API routes return structured JSON with a stable shape
  (`{ ok: false, error: { code, message } }`). Do not `throw` raw errors to
  the client.
- **Commit messages** — short imperative subject ("Fix spin cooldown race"),
  optional body explaining *why*. Reference the Issue or PR number if there
  is one.
- **Comments** explain *why*, not *what*. If a comment restates the code, drop
  it.

---

## Security disclosure policy

Please do not open public Issues for security findings. Follow `SECURITY.md`,
which describes:

- Supported versions
- How and where to report
- Response and disclosure SLAs
- Scope
- Acknowledgements / Hall of Fame

Reports sent through the right channel get a faster and more useful response
than public ones.

---

## Recognition

We do not maintain a separate `CREDITS.md` yet. For now, contributors are
credited in two places:

- The commit history (which is the source of truth).
- The `Unreleased` / release sections of `CHANGELOG.md` once a release is
  tagged.

If you would like a different form of attribution (handle, real name,
opt-out), mention it in your PR and we'll record it.

---

## A note on honesty

This project is opinionated about not saying things it can't back up. The
brand scanner exists because the maintainers have been around long enough to
know what happens when a project starts inventing numbers. If you're
contributing, please hold that line with us. It is one of the few things
that actually differentiates an honest project from a loud one.

Thanks for reading this far. Even if you don't end up opening a PR, the fact
that you read the README, the security policy, and the contributing guide
before sending a message is already more preparation than most.
