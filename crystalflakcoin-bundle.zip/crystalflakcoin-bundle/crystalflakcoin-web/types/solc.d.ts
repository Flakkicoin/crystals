declare module 'solc' {
  type ImportResolver = (path: string) => { contents?: string; error?: string };

  interface SolcModule {
    compile(input: string, options?: { import?: ImportResolver }): string;
    version(): string;
  }

  const solc: SolcModule;
  export default solc;
}
