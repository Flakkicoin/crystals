/**
 * Hardhat configuration for CrystalFlakCoin (CFC) smart contract.
 *
 * Used for:
 *  - Compiling the Solidity contract
 *  - Running local tests (npm run hardhat:test)
 *  - Deploying to testnets and L2 mainnets (npm run hardhat:deploy:sepolia)
 *  - Verifying on Sourcify and Etherscan (npm run hardhat:verify)
 *
 * For deployment, you need a funded deployer wallet. See DEPLOY_TOKEN_FREE.md.
 */
import { HardhatUserConfig } from 'hardhat/config';
import '@nomicfoundation/hardhat-toolbox';
import * as dotenv from 'dotenv';

dotenv.config();

function envRequired(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

const DEPLOYER_PRIVATE_KEY = process.env.DEPLOYER_PRIVATE_KEY || '0x' + '00'.repeat(32);
const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY || '';

const config: HardhatUserConfig = {
  solidity: {
    version: '0.8.28',
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
      viaIR: false,
    },
  },
  networks: {
    // Local in-memory network for tests
    hardhat: {
      chainId: 31337,
    },

    // Ethereum Sepolia (free testnet ETH from faucets)
    sepolia: {
      url: process.env.SEPOLIA_RPC_URL || 'https://rpc.sepolia.org',
      chainId: 11155111,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },

    // Base Sepolia (free testnet ETH)
    baseSepolia: {
      url: process.env.BASE_SEPOLIA_RPC_URL || 'https://sepolia.base.org',
      chainId: 84532,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },

    // Optimism Sepolia (free testnet ETH)
    opSepolia: {
      url: process.env.OP_SEPOLIA_RPC_URL || 'https://sepolia.optimism.io',
      chainId: 11155420,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },

    // Arbitrum Sepolia (free testnet ETH)
    arbSepolia: {
      url: process.env.ARB_SEPOLIA_RPC_URL || 'https://sepolia-rollup.arbitrum.io/rpc',
      chainId: 421614,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },

    // Mainnet L2s (cheap: ~$0.05-0.50 to deploy)
    base: {
      url: process.env.BASE_RPC_URL || 'https://mainnet.base.org',
      chainId: 8453,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },
    optimism: {
      url: process.env.OP_RPC_URL || 'https://mainnet.optimism.io',
      chainId: 10,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },
    arbitrum: {
      url: process.env.ARB_RPC_URL || 'https://arb1.arbitrum.io/rpc',
      chainId: 42161,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },
    polygon: {
      url: process.env.POLYGON_RPC_URL || 'https://polygon-rpc.com',
      chainId: 137,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },
    bsc: {
      url: process.env.BSC_RPC_URL || 'https://bsc-dataseed.binance.org',
      chainId: 56,
      accounts: [DEPLOYER_PRIVATE_KEY],
    },
  },
  etherscan: {
    apiKey: {
      mainnet: ETHERSCAN_API_KEY,
      sepolia: ETHERSCAN_API_KEY,
      base: ETHERSCAN_API_KEY,
      optimisticEthereum: ETHERSCAN_API_KEY,
      arbitrumOne: ETHERSCAN_API_KEY,
      polygon: ETHERSCAN_API_KEY,
      bsc: ETHERSCAN_API_KEY,
      baseSepolia: ETHERSCAN_API_KEY,
      optimisticSepolia: ETHERSCAN_API_KEY,
      arbitrumSepolia: ETHERSCAN_API_KEY,
    },
    customChains: [],
  },
  sourcify: {
    enabled: true,
  },
  paths: {
    sources: './contracts',
    tests: './test',
    cache: './cache',
    artifacts: './artifacts',
  },
  mocha: {
    timeout: 60000,
  },
};

export default config;

// Make envRequired available for scripts (in case they need to re-validate).
export { envRequired };
