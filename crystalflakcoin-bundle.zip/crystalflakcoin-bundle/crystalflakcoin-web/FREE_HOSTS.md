# CrystalFlakCoin — Free Host Comparison

A short, opinion-free comparison of the three free-tier hosts that work
with this Next.js 14 project. For the step-by-step walkthrough, see
[`DEPLOY_FREE.md`](./DEPLOY_FREE.md). For production-grade deployment
(monitoring, backups, custom domains, paid tiers), see
[`DEPLOYMENT.md`](./DEPLOYMENT.md).

---

## At a glance

| | **Vercel** | **Netlify** | **Cloudflare Pages** |
| --- | --- | --- | --- |
| **Config file in this repo** | [`vercel.json`](./vercel.json) | [`netlify.toml`](./netlify.toml) | [`wrangler.toml`](./wrangler.toml) |
| **Next.js 14 App Router support** | Native (made by the same team as Next.js) | Via `@netlify/plugin-nextjs` (official) | Via `@cloudflare/next-on-pages` adapter (opt-in) |
| **Build command** | `prisma generate && npm run build` (pinned in `vercel.json`) | `npm run build` (pinned in `netlify.toml`) | `npm run build` (static) or `npx @cloudflare/next-on-pages@1` (full SSR) |
| **Node runtime** | 20.x (auto, configurable) | 20 LTS (pinned in `netlify.toml`) | 20 via `nodejs_compat` (pinned in `wrangler.toml`) |
| **Region** | `iad1` default (pinned in `vercel.json`); many others on paid tier | Edge (no regional pinning; runs on AWS Lambda) | Edge (Cloudflare's global network) |
| **Database included** | No — pair with Neon or Supabase free tier | No — pair with Neon or Supabase free tier | No — pair with Neon or Supabase free tier |
| **Custom domain SSL** | Free, automatic | Free, automatic | Free, automatic |
| **Deploy on push** | Yes | Yes | Yes |
| **Preview deploys per PR** | Yes, unlimited on free tier | Yes, on free tier | Yes, on free tier |
| **Build minutes / month** | 100 (Hobby) | 300 | 500 builds |
| **Bandwidth / month** | 100 GB | 100 GB | Unlimited |
| **Serverless function requests** | 1M invocations (Hobby) | 125k invocations | 100k / day (Workers) |
| **Function timeout** | 10 s (Hobby); overridden to 30 s for `src/app/api/**` in `vercel.json` | 10 s default; 26 s on paid plans | 30 s on Pages Functions |
| **Cron jobs** | Supported (`crons` in `vercel.json`) | Supported (Netlify Scheduled Functions, paid) | Supported (Cron Triggers, paid) |
| **Image optimization** | Built-in (`next/image`) | Built-in (via the Next.js plugin) | Via the next-on-pages adapter or Cloudflare Images |
| **Edge runtime** | Yes (`runtime: 'edge'`) | Yes (Edge Functions, paid) | Yes (Workers + Pages) |

---

## Pros and cons

### Vercel

**Pros**
- Native Next.js support — zero adapter, zero plugin, zero surprises.
- The `vercel.json` in this repo already pins the build command
  (`prisma generate && npm run build`), install command (`npm ci`),
  region (`iad1`), and a 30 s timeout for `src/app/api/**`.
- Preview deploys, PR comments, and rollback are first-class.
- Free tier is sufficient for a read-mostly marketing site.

**Cons**
- The free tier is the most generous in some dimensions (build minutes,
  function invocations) but the most restrictive in others (egress cap
  of 100 GB).
- The default 10 s serverless function timeout on the free tier is short
  for any DB-backed endpoint; this repo overrides it to 30 s in
  `vercel.json`, but the underlying serverless cap still applies.
- No bundled database. Neon or Supabase free tier is the standard
  companion (see `DEPLOY_FREE.md` §1.2).

### Netlify

**Pros**
- Official `@netlify/plugin-nextjs` plugin is mature and handles the
  App Router, ISR, image optimization, and Functions automatically.
- The `netlify.toml` in this repo pins `NODE_VERSION = "20"`, the build
  command, the publish directory, the plugin, and the security headers
  in one file.
- Form handling, identity, and edge functions are first-class if you
  ever outgrow this guide.
- The free tier is the most generous in build minutes (300 / month).

**Cons**
- The 125k function invocations / month free-tier cap is the tightest
  of the three. The marketing site will not come close; the daily-prize
  and admin paths will, if they get traffic.
- The plugin occasionally lags a Next.js minor release; check the
  compatibility matrix in
  <https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/>
  if you upgrade Next.
- No bundled database either.

### Cloudflare Pages

**Pros**
- Unlimited egress on the free tier — the differentiator if you expect
  to serve large static assets.
- Runs on Cloudflare's global edge network (300+ cities).
- The `wrangler.toml` in this repo pins the compatibility date
  (`2024-09-01`) and flag (`nodejs_compat`).
- Generous Workers request allowance (100k / day) and build count
  (500 / month).

**Cons**
- Native Next.js support requires the
  [`@cloudflare/next-on-pages`](https://github.com/cloudflare/next-on-pages)
  adapter, which is **not** installed in this repo. You have to opt in
  (see `DEPLOY_FREE.md` §3.2) and adapt `next.config.mjs` (the
  `output: 'standalone'` line is for Docker, not for Cloudflare).
- Without the adapter, only the static marketing pages deploy. API
  routes and server components are not served.
- The adapter is well-maintained but is one more moving piece to keep
  in your dependency tree.

---

## Free-tier limits summary

These are the limits that matter for a read-mostly marketing site with
optional auth + daily-prize endpoints. The exact numbers are what the
providers publish at the time of writing; check the source pages below
for current values.

| Limit | Vercel (Hobby) | Netlify (Free) | Cloudflare Pages (Free) |
| --- | --- | --- | --- |
| Bandwidth | 100 GB / month | 100 GB / month | Unlimited |
| Builds | 100 / month | 300 / month (300 build minutes) | 500 / month |
| Serverless / Workers requests | 1M invocations / month | 125k invocations / month | 100k / day |
| Serverless function timeout | 10 s (Hobby); 30 s for `src/app/api/**` via `vercel.json` | 10 s default | 30 s on Pages Functions |
| Concurrent builds | 1 | 1 | 1 |
| Max deploy size | 100 MB (uncompressed) | 100 MB (uncompressed) | 25 MB per file |
| Team members | 1 (Hobby) | 1 (Free) | Unlimited (Pages) |
| Custom domain | Yes, free | Yes, free | Yes, free |
| SSL | Auto (Let's Encrypt) | Auto (Let's Encrypt) | Auto |
| Database included | No | No | No (D1 is in beta) |

**Source pages**
- Vercel: <https://vercel.com/docs/pricing>
- Netlify: <https://docs.netlify.com/get-started/accounts-and-billing/billing/>
- Cloudflare Pages: <https://developers.cloudflare.com/pages/platform/limits/>

---

## Best for…

This is **not** a recommendation — pick the host that matches the
constraints you actually have. The honest summary is:

- **If you want the path of least resistance for Next.js 14** —
  Vercel. It is the smallest set of moving pieces for this exact
  codebase, and `vercel.json` in this repo already pins the relevant
  settings.
- **If you want the most generous build-minute allowance on the free
  tier** — Netlify. The plugin handles the App Router and the
  `netlify.toml` in this repo covers the rest.
- **If you want unlimited egress and an edge runtime** — Cloudflare
  Pages with the `next-on-pages` adapter (opt-in; see
  `DEPLOY_FREE.md` §3.2). The marketing site alone can ship without
  the adapter as a static export.

In all three cases, the same Neon or Supabase free-tier Postgres
covers the database, and the application code, schema
([`prisma/schema.prisma`](./prisma/schema.prisma)), and environment
variables ([`.env.example`](./.env.example)) do not change.
