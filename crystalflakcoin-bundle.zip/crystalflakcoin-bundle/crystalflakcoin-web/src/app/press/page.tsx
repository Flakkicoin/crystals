import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BOILERPLATE, KEY_FACTS } from '@/lib/boilerplate';
import { BRAND_COLORS, BRAND } from '@/lib/brand-tokens';
import { Download, ExternalLink, FileText, Image as ImageIcon, Mail } from 'lucide-react';
import { env, isPlaceholder } from '@/lib/env';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { CopyButton } from '@/components/press/copy-button';

export const metadata = {
  title: 'Press kit',
  description: 'Logos, brand colors, boilerplate copy, and contact info for journalists and partners.',
};

const LOGO_FILES = [
  { file: 'logo-primary.svg', label: 'Primary logo (SVG)', desc: 'Full color on dark background. Use for most contexts.' },
  { file: 'logo-with-wordmark.svg', label: 'Logo + wordmark', desc: 'Horizontal lockup with "CrystalFlakCoin" text.' },
  { file: 'logo-icon.svg', label: 'Icon only', desc: 'Just the crystal mark, no text. Use for app icons, favicons.' },
  { file: 'logo-mono-light.svg', label: 'Monochrome (light bg)', desc: 'For use on light or white backgrounds.' },
  { file: 'logo-mono-dark.svg', label: 'Monochrome (dark bg)', desc: 'For use on dark backgrounds.' },
];

const COLOR_SWATCHES = [
  { name: 'Crystal', hex: BRAND_COLORS.crystal, note: 'Primary accent, ice glow' },
  { name: 'Ice', hex: BRAND_COLORS.ice, note: 'Links, highlights' },
  { name: 'Violet Deep', hex: BRAND_COLORS.violetDeep, note: 'Headings, deep accents' },
  { name: 'Violet', hex: BRAND_COLORS.violet, note: 'Brand primary' },
  { name: 'Magenta', hex: BRAND_COLORS.magenta, note: 'Energy, gradients' },
  { name: 'Crystal White', hex: BRAND_COLORS.ink0, note: 'Text on dark backgrounds' },
  { name: 'Ink Light', hex: BRAND_COLORS.ink1, note: 'Body text' },
  { name: 'Surface', hex: BRAND_COLORS.surface, note: 'Card backgrounds' },
  { name: 'Background', hex: BRAND_COLORS.bg, note: 'Page background' },
];

export default function PressPage() {
  const support = env.NEXT_PUBLIC_SUPPORT_EMAIL;
  const ogUrl = `${env.NEXT_PUBLIC_APP_URL || ''}/api/og?title=${encodeURIComponent('CrystalFlakCoin')}&subtitle=${encodeURIComponent(BRAND.tagline)}`;

  return (
    <div className="container py-12 space-y-12 max-w-5xl">
      <header className="space-y-3">
        <span className="eyebrow">Press kit</span>
        <h1 className="font-display text-3xl md:text-5xl font-bold mt-3">CrystalFlakCoin press kit</h1>
        <p className="text-muted-foreground max-w-2xl">
          Everything you need to write about {BRAND.name}: logos, brand colors, boilerplate copy, key facts, and contact info.
          All assets are released under the project&apos;s open-source license and may be used freely with attribution.
        </p>
      </header>

      <RiskDisclaimer variant="compact" />

      {/* Logos */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ImageIcon className="h-5 w-5" /> Logos</CardTitle>
          <CardDescription>SVG format. Scalable to any size without quality loss.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 gap-3">
            {LOGO_FILES.map((logo) => (
              <div key={logo.file} className="p-4 rounded-md border border-white/10 bg-white/[0.02] flex items-center gap-3">
                <div className="w-16 h-16 rounded bg-black/40 flex items-center justify-center shrink-0">
                  <img src={`/press/${logo.file}`} alt={logo.label} className="h-12 w-auto" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{logo.label}</div>
                  <div className="text-xs text-muted-foreground">{logo.desc}</div>
                </div>
                <a href={`/press/${logo.file}`} download className="shrink-0">
                  <Button size="sm" variant="outline"><Download className="h-3 w-3" /></Button>
                </a>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Brand colors */}
      <Card>
        <CardHeader>
          <CardTitle>Brand colors</CardTitle>
          <CardDescription>The full CrystalFlakCoin palette. Use these hex values; avoid others.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-3">
            {COLOR_SWATCHES.map((c) => (
              <div key={c.name} className="p-3 rounded-md border border-white/10 bg-white/[0.02]">
                <div className="h-12 rounded mb-2 border border-white/10" style={{ background: c.hex }} />
                <div className="font-medium text-sm">{c.name}</div>
                <div className="font-mono text-xs text-muted-foreground">{c.hex}</div>
                <div className="text-xs text-muted-foreground mt-1">{c.note}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* OG Image generator */}
      <Card>
        <CardHeader>
          <CardTitle>Open Graph / social card</CardTitle>
          <CardDescription>
            A 1200×630 social-sharing image generated on the fly. Customize with <code>?title=...</code> and <code>?subtitle=...</code>.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <a href={ogUrl} target="_blank" rel="noopener noreferrer" className="block">
            <img src={ogUrl} alt="CrystalFlakCoin OG image" className="w-full rounded border border-white/10" />
          </a>
          <div className="text-xs text-muted-foreground">
            Direct link: <a href={ogUrl} className="text-sky-300 underline">{ogUrl}</a>
          </div>
        </CardContent>
      </Card>

      {/* Boilerplate */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" /> Boilerplate copy</CardTitle>
          <CardDescription>Three lengths, all honest and non-promotional. Use as-is or adapt.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {(['short', 'medium', 'long'] as const).map((k) => (
            <div key={k}>
              <div className="flex items-center justify-between mb-2">
                <Badge variant="ice">{k.toUpperCase()} ({BOILERPLATE[k].split(/\s+/).length} words)</Badge>
                <CopyButton text={BOILERPLATE[k]} />
              </div>
              <pre className="whitespace-pre-wrap text-sm bg-black/40 p-3 rounded border border-white/10">{BOILERPLATE[k]}</pre>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Key facts */}
      <Card>
        <CardHeader>
          <CardTitle>Key facts</CardTitle>
          <CardDescription>Only verifiable project facts. No fake stats.</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="grid sm:grid-cols-2 gap-3 text-sm">
            {Object.entries(KEY_FACTS).map(([k, v]) => (
              <div key={k} className="flex flex-col p-2 rounded border border-white/10 bg-white/[0.02]">
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">{k}</dt>
                <dd className="font-medium mt-1">{String(v)}</dd>
              </div>
            ))}
          </dl>
        </CardContent>
      </Card>

      {/* Contact */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5" /> Press contact</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>
            For press inquiries, partnerships, listings, or general questions:
          </p>
          {support && !isPlaceholder(support) ? (
            <a href={`mailto:${support}`} className="text-sky-300 underline text-base">{support}</a>
          ) : (
            <span className="text-muted-foreground italic">To be announced — see <a href="/contact" className="underline">/contact</a></span>
          )}
          <p className="text-xs text-muted-foreground pt-2">
            For security disclosures, please use <a href="/transparency#contact" className="underline">the security channel</a> instead — never the press inbox.
          </p>
        </CardContent>
      </Card>

      {/* External resources */}
      <Card>
        <CardHeader>
          <CardTitle>External resources</CardTitle>
          <CardDescription>Read these before writing about the project.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li><a href="/legal" className="text-sky-300 hover:underline inline-flex items-center gap-1">Risk disclosure <ExternalLink className="h-3 w-3" /></a></li>
            <li><a href="/transparency" className="text-sky-300 hover:underline inline-flex items-center gap-1">Transparency report <ExternalLink className="h-3 w-3" /></a></li>
            <li><a href="/faq" className="text-sky-300 hover:underline inline-flex items-center gap-1">FAQ <ExternalLink className="h-3 w-3" /></a></li>
            <li><a href="/docs" className="text-sky-300 hover:underline inline-flex items-center gap-1">Documentation <ExternalLink className="h-3 w-3" /></a></li>
            <li><a href="/donate" className="text-sky-300 hover:underline inline-flex items-center gap-1">Donations &amp; funding <ExternalLink className="h-3 w-3" /></a></li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

