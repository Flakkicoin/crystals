import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle } from 'lucide-react';

export const metadata = { title: 'Legal & Risk' };

const items = [
  {
    title: 'Not financial advice',
    body: 'Nothing on this site constitutes financial, investment, legal, or tax advice. You are solely responsible for your decisions. Consult a qualified professional before acting.',
  },
  {
    title: 'Digital asset risk',
    body: 'Digital assets are highly volatile. You may lose some or all of the value of your assets. There is no guarantee of liquidity, future value, or availability on any exchange.',
  },
  {
    title: 'Smart contract risk',
    body: 'Smart contracts can contain bugs or be exploited. Even audited contracts can fail. Never deposit more than you can afford to lose.',
  },
  {
    title: 'Regulatory uncertainty',
    body: 'The legal status of digital assets varies by jurisdiction and is evolving. You are responsible for understanding the laws that apply to you. This project does not represent that it is legal in every jurisdiction.',
  },
  {
    title: 'Tax responsibility',
    body: 'You are solely responsible for any tax obligations arising from your digital asset activity. CrystalFlakCoin does not provide tax advice.',
  },
  {
    title: 'No guarantee of value or liquidity',
    body: 'The project does not guarantee that the token will retain value, be listed on any exchange, or remain liquid.',
  },
  {
    title: 'No guarantee of utility or availability',
    body: 'Planned features may be delayed, modified, or never released. A feature being listed on this site is not a commitment to ship it.',
  },
  {
    title: 'Privacy policy (placeholder)',
    body: 'A complete privacy policy will be published before any data is collected beyond what is strictly necessary to operate the site. We use Plausible Analytics, which is privacy-friendly, cookie-free, and GDPR/CCPA compliant. Plausible does not collect IP addresses, personal data, or any cross-site identifiers. No cookie banner is required. If you would prefer no analytics at all, see /admin/analytics (admin only) for the disable instructions.',
  },
  {
    title: 'Terms of use (placeholder)',
    body: 'Full terms of use will be published prior to mainnet launch. By using the site, you agree to comply with applicable law and to use the site at your own risk.',
  },
];

export default function LegalPage() {
  return (
    <div className="container py-16 space-y-8 max-w-3xl">
      <header className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-3xl md:text-5xl font-bold">Legal & risk</h1>
          <Badge variant="warning">Important</Badge>
        </div>
        <p className="text-muted-foreground">
          Please read each section carefully. By interacting with this site or the CrystalFlakCoin
          smart contract, you accept the risks described below.
        </p>
      </header>

      <Card id="risk" className="border-amber-500/30 bg-amber-500/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-300">
            <AlertTriangle className="h-5 w-5" /> Risk summary
          </CardTitle>
        </CardHeader>
        <CardContent className="text-amber-100/80 text-sm">
          Digital assets involve substantial risk. They are volatile, may be subject to
          regulatory action, may be lost through user error, and may be lost through contract
          exploits. Only use funds you can afford to lose. CrystalFlakCoin makes no representations
          about future value, returns, or availability.
        </CardContent>
      </Card>

      <div className="space-y-3">
        {items.map((it) => (
          <Card key={it.title}>
            <CardHeader>
              <CardTitle className="text-lg">{it.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{it.body}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <p className="text-xs text-muted-foreground">
        This page is informational and does not constitute legal advice. Consult a qualified
        attorney for jurisdiction-specific guidance.
      </p>
    </div>
  );
}
