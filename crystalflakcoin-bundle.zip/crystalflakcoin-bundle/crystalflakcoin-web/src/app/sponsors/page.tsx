import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Heart, Server, ShieldCheck, Wallet, Github, ExternalLink, Copy, AlertTriangle, Info, Eye, FileText, Star } from 'lucide-react';
import Link from 'next/link';

export const metadata = {
  title: 'Sponsors',
  description:
    'Support the CrystalFlakCoin project as a sponsor. Sponsorship is a voluntary donation, not a purchase; it does not entitle the sponsor to tokens, NFTs, or any future benefit.',
};

// Same placeholder addresses as /donate. The team replaces both pages together
// when real addresses are published.
const ETH_ADDRESS = '0xPLACEHOLDER_ADDRESS';
const BTC_ADDRESS = 'bc1qPLACEHOLDER';

export default function SponsorsPage() {
  return (
    <div className="container py-16 space-y-10 max-w-4xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Sponsors &amp; supporters</h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Supporting CrystalFlakCoin is the same as donating: a voluntary, non-refundable
          contribution toward the project&apos;s infrastructure, audits, security tooling,
          and contributor time. There is no sponsor tier, no perks list, and no
          expectation of return. This page exists so that people who frame their support
          as &ldquo;sponsorship&rdquo; (rather than a donation) land on the same honest
          information.
        </p>
      </header>

      <RiskDisclaimer variant="banner" />

      <Alert className="border-sky-400/30 bg-sky-400/5">
        <Info className="h-4 w-4 text-sky-300" />
        <AlertTitle className="text-sky-200">Read this first</AlertTitle>
        <AlertDescription className="text-sky-100/80 text-sm">
          Sponsorship is a voluntary donation. It is <strong>non-refundable</strong> and
          does <strong>not</strong> entitle the supporter to tokens, NFTs, airdrops,
          governance rights, or any future benefit. We will never DM, email, or message
          you to ask for funds. This page is informational only and is not financial,
          investment, legal, or tax advice.
        </AlertDescription>
      </Alert>

      {/* Section 1 — Why we accept support */}
      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold flex items-center gap-2">
          <Star className="h-5 w-5 text-violet-300" /> Why we accept support
        </h2>
        <p className="text-muted-foreground">
          CrystalFlakCoin is built by independent contributors. We accept support to
          cover the four categories of unavoidable cost below. We do not run a token
          sale and we do not raise a venture round, so the project is funded entirely
          by voluntary contributions from people and organizations that want it to
          exist.
        </p>
        <div className="grid sm:grid-cols-2 gap-3">
          <Reason icon={<Server className="h-5 w-5" />} title="Server & infrastructure" body="Hosting, RPC endpoints, IPFS, the daily-prize RNG service, monitoring, and the database behind the transparency pages." />
          <Reason icon={<ShieldCheck className="h-5 w-5" />} title="Independent security audits" body="Smart-contract and full-stack reviews by third-party firms. We do not claim to be audited until a report is published." />
          <Reason icon={<Eye className="h-5 w-5" />} title="Security tooling" body="Static analysis, fuzzing, dependency scanning, and the bug-bounty program run through the public security email." />
          <Reason icon={<FileText className="h-5 w-5" />} title="Contributor compensation" body="Time-based, fair-rate pay for documentation, translation, design, and reviewed code work. All compensation is published annually." />
        </div>
      </section>

      {/* Section 2 — How contributions are used */}
      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold flex items-center gap-2">
          <FileText className="h-5 w-5" /> How contributions are used
        </h2>
        <p className="text-muted-foreground">
          Every contribution — whether through GitHub Sponsors, Open Collective, or
          direct crypto — is allocated against the same set of budget categories. The
          allocation is published quarterly in the transparency report.
        </p>
        <Card>
          <CardContent className="pt-6">
            <ul className="divide-y divide-white/5 text-sm">
              <BudgetRow label="Infrastructure (hosting, RPC, monitoring, database)" note="Recurring. Largest single line item." />
              <BudgetRow label="Security audits and tooling" note="Lumpy. We audit when code is ready, not on a marketing timeline." />
              <BudgetRow label="Contributor compensation" note="Hourly or per-milestone. Tracked publicly on Open Collective." />
              <BudgetRow label="Bug-bounty payouts" note="Paid to reporters through the public security email channel." />
              <BudgetRow label="Documentation, translation, design" note="Reviewed work only; never for promotional content." />
              <BudgetRow label="Legal review (jurisdictional, terms, risk disclosures)" note="Independent counsel, not in-house marketing." />
              <BudgetRow label="Reserve / contingency" note="Maintained to keep the project running through a bad quarter." />
            </ul>
            <p className="text-xs text-muted-foreground mt-4">
              We do not spend contributions on: paid promotion, paid influencers, paid
              reviews, paid KOL endorsements, paid group pumps, or any
              paid-for-coverage activity. Those are not part of this project.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Section 3 — How to support */}
      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold flex items-center gap-2">
          <Heart className="h-5 w-5 text-rose-300" /> How to support the project
        </h2>
        <p className="text-muted-foreground">
          Three independent channels. Pick whichever you are most comfortable with.
          All three route into the same project budget.
        </p>

        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Github className="h-5 w-5" /> GitHub Sponsors
              </CardTitle>
              <CardDescription>Recurring or one-time. Processed by GitHub.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p>
                Recurring support for ongoing contributor work. Funds are paid out
                through GitHub&apos;s own infrastructure. The recipient breakdown is
                visible on the GitHub Sponsors page.
              </p>
              <a
                href="https://github.com/sponsors/crystalflakcoin"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sky-300 hover:underline"
              >
                github.com/sponsors/crystalflakcoin <ExternalLink className="h-3 w-3" />
              </a>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5" /> Open Collective
              </CardTitle>
              <CardDescription>Public ledger. Preferred for grants and large gifts.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p>
                Every contribution and every expense is published on the Open
                Collective page. This is the preferred channel for grants (Gitcoin,
                Octant, etc.) and for larger individual contributions because the
                ledger is auditable in real time.
              </p>
              <a
                href="https://opencollective.com/crystalflakcoin"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sky-300 hover:underline"
              >
                opencollective.com/crystalflakcoin <ExternalLink className="h-3 w-3" />
              </a>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Wallet className="h-5 w-5" /> Direct crypto
            </CardTitle>
            <CardDescription>
              For supporters who prefer BTC or ETH. Verify on-chain before sending.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <Alert variant="destructive" className="bg-amber-500/5 border-amber-500/30 text-amber-100/90">
              <AlertTriangle className="h-4 w-4 text-amber-300" />
              <AlertTitle className="text-amber-200">Placeholder addresses</AlertTitle>
              <AlertDescription className="text-amber-100/80">
                The two addresses below are <strong>placeholders</strong>. Real addresses
                are only ever published on the official site
                (<span className="font-mono">https://crystalflakcoin.example/donate</span>)
                and in the public repository. Do not send funds to these placeholder
                strings.
              </AlertDescription>
            </Alert>

            <AddressRow
              network="Ethereum (mainnet)"
              symbol="ETH / ERC-20"
              address={ETH_ADDRESS}
              placeholder
            />
            <AddressRow
              network="Bitcoin"
              symbol="BTC"
              address={BTC_ADDRESS}
              placeholder
            />

            <div className="rounded-md border border-white/10 bg-white/[0.02] p-3 text-xs text-muted-foreground space-y-2">
              <p className="font-medium text-foreground">Before you send</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>
                  We strongly recommend verifying the address on our official site
                  (<Link href="/donate" className="underline">crystalflakcoin.example/donate</Link>)
                  and on-chain before sending.
                </li>
                <li>
                  Send a small test transaction first. Blockchain transactions are
                  irreversible; once a transaction is confirmed it cannot be undone by
                  anyone, including the project.
                </li>
                <li>
                  We will never DM, email, or message you asking for funds. Anyone
                  reaching out with a wallet address is not affiliated with this
                  project.
                </li>
                <li>
                  The project cannot recover mis-sent funds. There is no support
                  channel that can reverse a confirmed transaction.
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Risk disclosure */}
      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold">Risk disclosure</h2>
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardContent className="pt-6 text-sm text-amber-100/80 space-y-3">
            <p>
              <strong>Support contributions are voluntary and non-refundable.</strong>{' '}
              CrystalFlakCoin is a digital asset project; sponsoring or supporting the
              project does not entitle you to tokens, NFTs, airdrops, governance
              rights, allocation in any future sale, or any other benefit.
            </p>
            <p>
              Sponsor information is handled per the privacy notice on this site. We
              do not sell, rent, or share sponsor data with third parties for
              marketing. The project may publish aggregate, non-identifying support
              statistics in the annual transparency report.
            </p>
            <p>
              Crypto contributions are subject to the usual on-chain risks: price
              volatility between send and confirmation, network fees, and the
              irreversibility of confirmed transactions. None of this is financial,
              investment, legal, or tax advice. Please consult your own advisors.
            </p>
          </CardContent>
        </Card>
      </section>

      <p className="text-xs text-muted-foreground">
        See also: <Link href="/donate" className="underline">/donate</Link> (same
        information, alternate path), <Link href="/monetization" className="underline">monetization policy</Link>{' '}
        (if published in-repo), and <Link href="/faq" className="underline">FAQ</Link>.
      </p>
    </div>
  );
}

function Reason({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <Card className="crystal-card">
      <CardHeader>
        <div className="h-9 w-9 rounded-md bg-violet-400/10 border border-violet-400/20 flex items-center justify-center text-violet-300 mb-1">
          {icon}
        </div>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{body}</p>
      </CardContent>
    </Card>
  );
}

function BudgetRow({ label, note }: { label: string; note: string }) {
  return (
    <li className="py-2 flex items-start justify-between gap-3">
      <span className="font-medium">{label}</span>
      <span className="text-xs text-muted-foreground text-right max-w-[55%]">{note}</span>
    </li>
  );
}

function AddressRow({
  network,
  symbol,
  address,
  placeholder,
}: {
  network: string;
  symbol: string;
  address: string;
  placeholder?: boolean;
}) {
  return (
    <div className="rounded-md border border-white/10 bg-white/[0.02] p-3">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="text-sm font-medium flex items-center gap-2">
            {network} <span className="text-xs text-muted-foreground">({symbol})</span>
            {placeholder && <Badge variant="warning">Placeholder</Badge>}
          </div>
          <code className="font-mono text-xs text-muted-foreground break-all">{address}</code>
        </div>
        <button
          type="button"
          disabled
          aria-label="Copy address (disabled — placeholder)"
          className="inline-flex items-center gap-1 text-xs text-muted-foreground border border-white/10 rounded-md px-2 py-1 cursor-not-allowed"
        >
          <Copy className="h-3 w-3" /> Copy
        </button>
      </div>
    </div>
  );
}
