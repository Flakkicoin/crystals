import type { Metadata } from 'next';
import { Inter, Orbitron } from 'next/font/google';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { WalletProvider } from '@/components/wallet/wallet-provider';
import { Plausible } from '@/components/analytics/plausible';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });
const orbitron = Orbitron({ subsets: ['latin'], variable: '--font-orbitron', display: 'swap' });

export const metadata: Metadata = {
  title: {
    default: 'CrystalFlakCoin (CFC) — Transparent Digital Asset Project',
    template: '%s | CrystalFlakCoin',
  },
  description:
    'CrystalFlakCoin (CFC) is a transparent digital asset project. This site is informational only and does not constitute financial advice. Digital assets are subject to market and technical risk.',
  keywords: ['CrystalFlakCoin', 'CFC', 'digital asset', 'blockchain', 'transparency', 'open source'],
  applicationName: 'CrystalFlakCoin',
  authors: [{ name: 'CrystalFlakCoin Contributors' }],
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'),
  openGraph: {
    type: 'website',
    title: 'CrystalFlakCoin (CFC)',
    description: 'A transparent digital asset project. Not financial advice.',
    siteName: 'CrystalFlakCoin',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CrystalFlakCoin (CFC)',
    description: 'A transparent digital asset project. Not financial advice.',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${inter.variable} ${orbitron.variable} font-sans crystal-bg min-h-screen`}>
        <Plausible />
        <WalletProvider>
          <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:px-3 focus:py-1.5 focus:rounded-md focus:bg-background focus:border">
            Skip to main content
          </a>
          <Navbar />
          <main id="main" className="min-h-[60vh]">
            {children}
          </main>
          <Footer />
        </WalletProvider>
      </body>
    </html>
  );
}
