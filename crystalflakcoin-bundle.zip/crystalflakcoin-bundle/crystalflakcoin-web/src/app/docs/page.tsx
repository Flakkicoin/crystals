import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export const metadata = { title: 'Documentation' };

const sections = [
  {
    id: 'what',
    title: 'What is CrystalFlakCoin?',
    body: 'CrystalFlakCoin (CFC) is a transparent, EVM-compatible digital asset. The project publishes verifiable on-chain data, open documentation, and clear risk disclosures. It does not promise returns, yield, or appreciation.',
  },
  {
    id: 'wallet',
    title: 'How to connect a wallet',
    body: 'Click "Connect Wallet" in the navigation. Choose your wallet provider and approve the connection request in your wallet UI. CrystalFlakCoin never receives your private key or seed phrase — it only sees the public address you choose to share.',
  },
  {
    id: 'verify',
    title: 'How to verify the official contract',
    body: 'The official contract address is listed on the Token page and the Transparency page. Always cross-check it on a block explorer and against the project\'s GitHub repository. Never interact with a contract that does not match these references.',
  },
  {
    id: 'tx-safety',
    title: 'Transaction safety',
    body: 'Before signing any transaction, your wallet shows the target contract, method, and amount. Read it carefully. Reject any transaction you did not initiate. Blockchain transactions are irreversible once confirmed.',
  },
  {
    id: 'contract-risk',
    title: 'Smart contract risks',
    body: 'Smart contracts can contain bugs. Even audited contracts can have undiscovered vulnerabilities. Never deposit more than you can afford to lose, and prefer small test transactions before larger ones.',
  },
  {
    id: 'volatility',
    title: 'Volatility risks',
    body: 'The price of any digital asset can be highly volatile. Prices can move rapidly based on market sentiment, liquidity, regulatory news, and technical events. Past performance does not predict future results.',
  },
  {
    id: 'phishing',
    title: 'Phishing protection',
    body: 'Bookmark the official CrystalFlakCoin site. Never click links from unsolicited DMs, emails, or social media. Verify the URL bar before connecting a wallet. Anyone asking for your seed phrase is attempting theft.',
  },
  {
    id: 'regulatory',
    title: 'Regulatory considerations',
    body: 'Digital asset regulation varies by jurisdiction. It is your responsibility to understand the legal status of digital assets in your country, including tax obligations. CrystalFlakCoin does not provide legal or tax advice.',
  },
  {
    id: 'report',
    title: 'How to report a security issue',
    body: 'Please email the security contact listed on the Transparency page. Include a clear description, reproduction steps, and impact assessment. Do not disclose the issue publicly until coordinated disclosure has been agreed upon.',
  },
];

export default function DocsPage() {
  return (
    <div className="container py-16 space-y-8 max-w-4xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Documentation</h1>
        <p className="text-muted-foreground">
          Everything you need to understand, use, and verify CrystalFlakCoin safely.
        </p>
      </header>

      <Tabs defaultValue="what" className="w-full">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-transparent p-0">
          {sections.map((s) => (
            <TabsTrigger key={s.id} value={s.id} className="data-[state=active]:bg-white/10 data-[state=active]:text-foreground">
              {s.title}
            </TabsTrigger>
          ))}
        </TabsList>
        {sections.map((s) => (
          <TabsContent key={s.id} value={s.id}>
            <Card>
              <CardHeader>
                <CardTitle>{s.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{s.body}</p>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
