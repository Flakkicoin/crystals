import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { SecurityReportSchema } from '@/lib/validation';
import { rateLimit, clientKeyFromRequest } from '@/lib/rate-limit';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const rl = await rateLimit({ key: `sec-report:${clientKeyFromRequest(req)}`, limit: 3, windowMs: 60 * 60_000 });
  if (!rl.ok) return NextResponse.json({ error: 'Too many reports from your IP. Please try again later.' }, { status: 429 });

  let body: unknown;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }); }
  const parsed = SecurityReportSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });

  const report = await prisma.securityReport.create({
    data: {
      title: parsed.data.title,
      description: parsed.data.description,
      severity: parsed.data.severity,
      reporter: parsed.data.reporter || null,
      details: parsed.data.details || null,
      status: 'open',
    },
  });
  await audit({ action: 'security.report.create', resource: report.id, ip: clientKeyFromRequest(req) });
  return NextResponse.json({ ok: true, id: report.id });
}
