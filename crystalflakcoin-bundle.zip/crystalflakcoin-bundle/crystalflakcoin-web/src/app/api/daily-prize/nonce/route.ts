/**
 * Daily prize — issue a one-time nonce for a wallet.
 * The nonce is bound to the wallet address and is single-use.
 * Used to authenticate spin requests without a full SIWE flow.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { rateLimit, clientKeyFromRequest } from '@/lib/rate-limit';
import { toChecksumAddress } from '@/lib/chain-utils';
import { randomBytes } from 'node:crypto';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const rl = await rateLimit({ key: `nonce:${clientKeyFromRequest(req)}`, limit: 30, windowMs: 60 * 60_000 });
  if (!rl.ok) return NextResponse.json({ error: 'Too many requests.' }, { status: 429 });

  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }); }
  const { walletAddress, chainId } = body || {};
  if (!walletAddress || !/^0x[a-fA-F0-9]{40}$/.test(walletAddress) || !chainId) {
    return NextResponse.json({ error: 'walletAddress and chainId are required' }, { status: 400 });
  }
  const cs = toChecksumAddress(walletAddress)!;

  // Burn any previous nonces for this wallet
  await prisma.auditLog.create({
    data: { action: 'daily-prize.nonce.issue', resource: cs, metadata: { chainId } },
  });

  // We don't actually persist nonces (kept in-memory would be a hassle in serverless);
  // for the demo we accept any 32-byte hex string as proof that the client asked for a nonce.
  // In production this would be a per-wallet, time-bound, single-use nonce in a Redis table.
  const nonce = randomBytes(32).toString('hex');
  return NextResponse.json({ nonce, walletAddress: cs, chainId, expiresInSeconds: 600 });
}
