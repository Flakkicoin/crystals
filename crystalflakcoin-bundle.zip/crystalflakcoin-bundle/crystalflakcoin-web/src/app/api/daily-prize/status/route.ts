/**
 * Daily prize — current status for a wallet.
 * Returns streak, points, raffles, badges, and whether a spin is available now.
 *
 * Auth: SIWE session OR a wallet address header.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { toChecksumAddress } from '@/lib/chain-utils';
import { spinAvailability, nextStreakBonus, utcDateString } from '@/lib/daily-prize';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const session = await getSession();
  let address: string | null = session.siwe?.address ?? null;
  if (!address) {
    const header = req.headers.get('x-cfc-wallet');
    if (header && /^0x[a-fA-F0-9]{40}$/.test(header)) {
      address = toChecksumAddress(header);
    }
  }
  if (!address) return NextResponse.json({ connected: false });

  const streak = await prisma.spinStreak.findUnique({
    where: { walletAddress: address },
    include: { badges: true },
  });
  if (!streak) {
    return NextResponse.json({
      connected: true,
      address,
      hasSpun: false,
      canSpin: true,
      nextSpinAt: '',
      currentStreak: 0,
      longestStreak: 0,
      totalSpins: 0,
      totalPoints: 0,
      totalRaffles: 0,
      badges: [],
      nextBonus: null,
    });
  }

  const today = utcDateString();
  const availability = spinAvailability(streak.lastSpinDate, new Date());
  const earnedCodes = streak.badges.map((b) => b.code);
  const nextBonus = nextStreakBonus(streak.currentStreak, earnedCodes);

  return NextResponse.json({
    connected: true,
    address,
    hasSpun: streak.lastSpinDate === today,
    canSpin: availability.canSpin,
    nextSpinAt: availability.nextSpinAt,
    currentStreak: streak.currentStreak,
    longestStreak: streak.longestStreak,
    totalSpins: streak.totalSpins,
    totalPoints: streak.totalPoints,
    totalRaffles: streak.totalRaffles,
    badges: streak.badges.map((b) => ({ code: b.code, label: b.label, earnedAt: b.earnedAt })),
    nextBonus,
  });
}
