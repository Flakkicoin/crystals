/**
 * Public — extended daily-prize leaderboard.
 * Returns top streaks, top raffle holders, recent winners, and a few
 * derived stats. Pagination supported via ?limit and ?offset.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { shortenAddress } from '@/lib/chain-utils';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const limit = Math.min(MAX_LIMIT, Math.max(1, Number(searchParams.get('limit')) || DEFAULT_LIMIT));
  const sort = searchParams.get('sort') || 'streak'; // "streak" | "raffles" | "points" | "spins"

  let orderBy: any = { longestStreak: 'desc' };
  if (sort === 'raffles') orderBy = { totalRaffles: 'desc' };
  else if (sort === 'points') orderBy = { totalPoints: 'desc' };
  else if (sort === 'spins') orderBy = { totalSpins: 'desc' };
  else orderBy = { longestStreak: 'desc' };

  const [top, recent, totals] = await Promise.all([
    prisma.spinStreak.findMany({
      orderBy,
      take: limit,
      include: { badges: true },
    }),
    prisma.dailySpin.findMany({
      orderBy: { createdAt: 'desc' },
      take: 15,
    }),
    prisma.$transaction([
      prisma.spinStreak.aggregate({ _sum: { totalSpins: true, totalPoints: true, totalRaffles: true } }),
      prisma.spinStreak.count(),
      prisma.dailySpin.count(),
    ]),
  ]);

  const [agg, uniqueWallets, totalSpins] = totals;

  return NextResponse.json({
    sort,
    limit,
    top: top.map((s, idx) => ({
      rank: idx + 1,
      address: shortenAddress(s.walletAddress, 6, 4),
      fullAddress: s.walletAddress,
      longestStreak: s.longestStreak,
      currentStreak: s.currentStreak,
      totalSpins: s.totalSpins,
      totalPoints: s.totalPoints,
      totalRaffles: s.totalRaffles,
      badges: s.badges.map((b) => b.code).sort(),
    })),
    recent: recent.map((r) => ({
      address: shortenAddress(r.walletAddress, 6, 4),
      prizeLabel: r.prizeLabel,
      prizeCode: r.prizeCode,
      streak: r.streak,
      bonus: r.bonusCode,
      ago: r.createdAt,
    })),
    totals: {
      uniqueWallets,
      totalSpins,
      totalPoints: agg._sum.totalPoints ?? 0,
      totalRaffles: agg._sum.totalRaffles ?? 0,
    },
    note: 'Non-monetary engagement metric. Points and raffle entries have no cash value until a token contract is deployed.',
  });
}
