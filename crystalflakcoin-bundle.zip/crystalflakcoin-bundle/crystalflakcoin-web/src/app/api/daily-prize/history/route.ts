/**
 * Public — past spins for a wallet.
 * Returns the user's spin history including the server seed for each
 * spin, so the user can independently verify the outcome.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { toChecksumAddress } from '@/lib/chain-utils';
import { getActiveRandomness, listAvailableSources } from '@/lib/randomness';
import { createHash } from 'node:crypto';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const TOTAL_WEIGHT = 10000; // We expose the in-code default here for the verification math; admins can also re-verify with the live total.

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const wallet = searchParams.get('wallet');
  if (!wallet || !/^0x[a-fA-F0-9]{40}$/.test(wallet)) {
    return NextResponse.json({ error: 'Provide a valid wallet query parameter' }, { status: 400 });
  }
  const cs = toChecksumAddress(wallet)!;

  const [spins, streak, randomness] = await Promise.all([
    prisma.dailySpin.findMany({
      where: { walletAddress: cs },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
    prisma.spinStreak.findUnique({ where: { walletAddress: cs } }),
    getActiveRandomness(),
  ]);

  // For each spin, recompute the proof so the user can verify locally.
  const verified = spins.map((s) => {
    const hash = createHash('sha256').update(`${s.walletAddress}:${s.spinDate}:${s.serverSeed}`).digest('hex');
    const roll = parseInt(hash.slice(0, 8), 16) % TOTAL_WEIGHT;
    return {
      id: s.id,
      date: s.spinDate,
      prizeCode: s.prizeCode,
      prizeLabel: s.prizeLabel,
      outcomeIndex: s.outcomeIndex,
      streak: s.streak,
      bonus: s.bonusCode,
      serverSeed: s.serverSeed,
      proof: `sha256("${s.walletAddress}:${s.spinDate}:${s.serverSeed}").slice(0,8) % ${TOTAL_WEIGHT} = ${roll}`,
      // We can't fully verify the prize mapping because the catalog can change over time.
      // We expose the index and the prizeCode at the time of the spin, but the weight table
      // may have shifted since then. Admin can re-verify using the admin/stats endpoint.
    };
  });

  return NextResponse.json({
    wallet: cs,
    streak: streak ? {
      current: streak.currentStreak,
      longest: streak.longestStreak,
      totalSpins: streak.totalSpins,
      totalPoints: streak.totalPoints,
      totalRaffles: streak.totalRaffles,
      badges: [], // not paginated here
    } : null,
    spins: verified,
    randomness: { source: randomness.id, label: randomness.label, description: randomness.description },
    availableSources: listAvailableSources(),
    note: 'Each spin includes the server seed used. You can verify the proof by running the same SHA-256 computation locally. The server seed is also recorded in the admin audit log.',
  });
}
