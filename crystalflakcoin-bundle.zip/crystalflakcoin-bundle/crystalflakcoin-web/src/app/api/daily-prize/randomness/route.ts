/**
 * Public — current randomness source configuration.
 * Used by the daily-prize page to display the source label and for the
 * admin panel to list available sources.
 */
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { listAvailableSources } from '@/lib/randomness';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const config = await prisma.randomnessConfig.findFirst({ where: { isEnabled: true } });
  return NextResponse.json({
    active: {
      source: config?.source || 'server',
      description: config?.description || null,
    },
    available: listAvailableSources(),
  });
}
