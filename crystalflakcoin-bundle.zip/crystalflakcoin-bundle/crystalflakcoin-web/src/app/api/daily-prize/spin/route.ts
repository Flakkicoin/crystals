/**
 * Daily prize — claim a spin.
 *
 * Auth: SIWE-signed message (preferred) OR wallet + nonce header (demo fallback).
 * Both paths are server-enforced; the demo path is rate-limited and clearly marked.
 *
 * The prize catalogue and randomness source are read from the database at
 * request time, with sensible in-code defaults if the DB has none configured.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { rateLimit, clientKeyFromRequest } from '@/lib/rate-limit';
import { toChecksumAddress } from '@/lib/chain-utils';
import { verifySiwe } from '@/lib/auth';
import { getActiveRandomness } from '@/lib/randomness';
import { PRIZE_CATALOG as DEFAULT_PRIZES, type PrizeDef, utcDateString, spinAvailability, STREAK_BONUSES } from '@/lib/daily-prize';

const CURRENT_PERIOD = (() => {
  const d = new Date();
  return `${d.getUTCFullYear()}-Q${Math.floor(d.getUTCMonth() / 3) + 1}`;
})();

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

interface ActivePrize {
  code: string;
  label: string;
  description: string;
  category: string;
  weight: number;
  color: string;
  points: number;
  raffles: number;
  freezesStreak: boolean;
  disclosure: string;
  order: number;
}

let cachedPrizes: { prizes: ActivePrize[]; totalWeight: number; fetchedAt: number } | null = null;
const PRIZE_CACHE_MS = 10_000;

async function loadActivePrizes(): Promise<{ prizes: ActivePrize[]; totalWeight: number }> {
  const now = Date.now();
  if (cachedPrizes && now - cachedPrizes.fetchedAt < PRIZE_CACHE_MS) {
    return { prizes: cachedPrizes.prizes, totalWeight: cachedPrizes.totalWeight };
  }
  const dbPrizes = await prisma.prizeCatalogItem.findMany({
    where: { isActive: true },
    orderBy: [{ order: 'asc' }, { code: 'asc' }],
  });
  let prizes: ActivePrize[];
  if (dbPrizes.length === 0) {
    prizes = DEFAULT_PRIZES.map((p, i) => ({
      code: p.code,
      label: p.label,
      description: p.description,
      category: p.category,
      weight: p.weight,
      color: p.color,
      points: p.points ?? 0,
      raffles: p.raffles ?? 0,
      freezesStreak: p.freezesStreak ?? false,
      disclosure: p.disclosure,
      order: i,
    }));
  } else {
    prizes = dbPrizes.map((p) => ({
      code: p.code,
      label: p.label,
      description: p.description,
      category: p.category,
      weight: p.weight,
      color: p.color,
      points: p.points ?? 0,
      raffles: p.raffles ?? 0,
      freezesStreak: p.freezesStreak,
      disclosure: p.disclosure,
      order: p.order,
    }));
  }
  const totalWeight = prizes.reduce((acc, p) => acc + p.weight, 0);
  cachedPrizes = { prizes, totalWeight, fetchedAt: now };
  return { prizes, totalWeight };
}

function pickPrizeFromList(prizes: ActivePrize[], roll: number): { prize: ActivePrize; index: number } {
  if (roll < 0 || roll >= prizes.reduce((a, p) => a + p.weight, 0)) {
    return { prize: prizes[0], index: 0 };
  }
  let acc = 0;
  for (let i = 0; i < prizes.length; i++) {
    acc += prizes[i].weight;
    if (roll < acc) return { prize: prizes[i], index: i };
  }
  return { prize: prizes[prizes.length - 1], index: prizes.length - 1 };
}

/** Auth resolution. Returns a verified wallet (address + chainId) or null. */
async function resolveWallet(req: NextRequest, body: any): Promise<{ address: string; chainId: number; authMethod: 'siwe' | 'nonce' } | null> {
  // 1. SIWE session cookie (best — already verified by iron-session)
  const session = await getSession();
  if (session.isLoggedIn && session.siwe?.address) {
    return { address: session.siwe.address, chainId: session.siwe.chainId, authMethod: 'siwe' };
  }

  // 2. SIWE body (server-verified fresh signature on this request)
  if (body?.siwe_message && body?.siwe_signature) {
    const verified = await verifySiwe(body.siwe_message, body.siwe_signature);
    if (!verified) return null;
    return { address: verified.address, chainId: verified.chainId, authMethod: 'siwe' };
  }

  // 3. Header-based demo path (low-trust, rate-limited)
  const addr = req.headers.get('x-cfc-wallet');
  const chainIdHeader = req.headers.get('x-cfc-chain');
  const nonce = req.headers.get('x-cfc-nonce');
  if (!addr || !nonce || !chainIdHeader) return null;
  if (!/^0x[a-fA-F0-9]{40}$/.test(addr) || !/^[a-fA-F0-9]{8,128}$/.test(nonce)) return null;
  const cs = toChecksumAddress(addr);
  if (!cs) return null;
  const chainId = Number(chainIdHeader);
  if (!Number.isFinite(chainId)) return null;
  return { address: cs, chainId, authMethod: 'nonce' };
}

export async function POST(req: NextRequest) {
  const rl = await rateLimit({ key: `spin:${clientKeyFromRequest(req)}`, limit: 6, windowMs: 60 * 60_000 });
  if (!rl.ok) return NextResponse.json({ error: 'Too many spin attempts. Please try again later.' }, { status: 429 });

  let body: any = {};
  try { body = await req.json(); } catch { /* empty body is OK */ }

  const wallet = await resolveWallet(req, body);
  if (!wallet) {
    return NextResponse.json({ error: 'Authentication required. Connect a wallet to spin.' }, { status: 401 });
  }

  const { prizes, totalWeight } = await loadActivePrizes();
  if (prizes.length === 0 || totalWeight === 0) {
    return NextResponse.json({ error: 'No active prizes configured.' }, { status: 503 });
  }

  const today = utcDateString();
  const existingToday = await prisma.dailySpin.findUnique({
    where: { walletAddress_spinDate: { walletAddress: wallet.address, spinDate: today } },
  });
  if (existingToday) {
    const availability = spinAvailability(today, new Date());
    return NextResponse.json({ error: 'You have already claimed today\'s spin.', cooldownRemainingMs: availability.cooldownRemainingMs }, { status: 429 });
  }

  // Use the configured randomness source
  const randomness = await getActiveRandomness();
  const { roll, seed, source, proof } = await randomness.roll({ wallet: wallet.address, date: today, totalWeight });
  const { prize, index } = pickPrizeFromList(prizes, roll);

  // Streak logic
  const streak = await prisma.spinStreak.upsert({
    where: { walletAddress: wallet.address },
    create: {
      walletAddress: wallet.address,
      chainId: wallet.chainId,
      currentStreak: 1,
      longestStreak: 1,
      totalSpins: 0,
      streakStart: today,
      lastSpinDate: null,
    },
    update: {},
  });

  const yesterday = utcDateString(new Date(Date.now() - 86_400_000));
  const sameAsYesterday = streak.lastSpinDate === yesterday;
  const newStreak = sameAsYesterday ? streak.currentStreak + 1 : 1;
  const newLongest = Math.max(streak.longestStreak, newStreak);

  const earnedBadges = await prisma.badge.findMany({ where: { spinStreakId: streak.id } });
  const earnedCodes = earnedBadges.map((b) => b.code);
  const streakBonus = STREAK_BONUSES.find((b) => newStreak >= b.threshold && !earnedCodes.includes(b.code));
  const bonusCode = streakBonus?.code ?? null;
  let bonusRaffles = 0;
  if (streakBonus?.code === 'SILVER') bonusRaffles = 5;

  if (streakBonus) {
    await prisma.badge.create({
      data: {
        spinStreakId: streak.id,
        code: streakBonus.code,
        label: streakBonus.label,
        description: streakBonus.description,
      },
    });
  }

  await prisma.$transaction([
    prisma.dailySpin.create({
      data: {
        walletAddress: wallet.address,
        chainId: wallet.chainId,
        spinDate: today,
        prizeCode: prize.code,
        prizeLabel: prize.label,
        outcomeIndex: index,
        streak: newStreak,
        bonusAwarded: !!streakBonus,
        bonusCode,
        serverSeed: seed,
      },
    }),
    prisma.spinStreak.update({
      where: { walletAddress: wallet.address },
      data: {
        currentStreak: newStreak,
        longestStreak: newLongest,
        totalSpins: streak.totalSpins + 1,
        totalPoints: streak.totalPoints + prize.points + bonusRaffles * 0, // points come from prize, not bonus
        totalRaffles: streak.totalRaffles + prize.raffles + bonusRaffles,
        lastSpinDate: today,
        streakStart: sameAsYesterday && streak.lastSpinDate ? streak.streakStart : today,
      },
    }),
    ...(((prize.raffles ?? 0) + bonusRaffles) > 0
      ? [
          prisma.raffleEntry.create({
            data: {
              walletAddress: wallet.address,
              chainId: wallet.chainId,
              sourcePrize: prize.code,
              doubled: false,
              period: CURRENT_PERIOD,
            },
          }),
        ]
      : []),
  ]);

  await audit({
    action: 'daily-prize.spin',
    resource: wallet.address,
    metadata: { prize: prize.code, streak: newStreak, bonus: bonusCode, source, seed, proof, authMethod: wallet.authMethod },
  });

  return NextResponse.json({
    ok: true,
    authMethod: wallet.authMethod,
    randomness: { source, seed, proof },
    prize: {
      code: prize.code,
      label: prize.label,
      description: prize.description,
      category: prize.category,
      points: prize.points,
      raffles: prize.raffles,
      outcomeIndex: index,
      disclosure: prize.disclosure,
    },
    bonus: streakBonus
      ? { code: streakBonus.code, label: streakBonus.label, description: streakBonus.description }
      : null,
    streak: {
      current: newStreak,
      longest: newLongest,
      wasReset: !sameAsYesterday && streak.totalSpins > 0,
    },
    nextSpinAt: spinAvailability(today, new Date()).nextSpinAt,
  });
}

export async function GET() {
  const { prizes, totalWeight } = await loadActivePrizes();
  return NextResponse.json({
    prizes: prizes.map((p) => ({
      code: p.code,
      label: p.label,
      description: p.description,
      category: p.category,
      disclosure: p.disclosure,
      odds: +(p.weight / totalWeight * 100).toFixed(2),
    })),
    period: CURRENT_PERIOD,
    totalWeight,
    note: 'Prizes are non-monetary. Points and raffle entries have no cash value until a token contract is deployed and a conversion ratio is announced.',
  });
}
