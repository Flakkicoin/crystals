/**
 * Public — list past raffle draws and their winners.
 */
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { shortenAddress } from '@/lib/chain-utils';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const draws = await prisma.raffleDraw.findMany({
    orderBy: { drawnAt: 'desc' },
    include: {
      winners: {
        include: { tier: true },
      },
    },
  });
  return NextResponse.json({
    draws: draws.map((d) => ({
      id: d.id,
      period: d.period,
      drawnAt: d.drawnAt,
      totalEntries: d.totalEntries,
      totalUniqueWallets: d.totalUniqueWallets,
      serverSeed: d.serverSeed,
      resultJson: JSON.parse(d.resultJson),
      winners: d.winners.map((w) => ({
        tier: w.tier.code,
        tierLabel: w.tier.label,
        wallet: shortenAddress(w.walletAddress, 6, 4),
        fullWallet: w.walletAddress,
      })),
    })),
  });
}
