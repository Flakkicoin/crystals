import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { env, isPlaceholder } from '@/lib/env';

export const dynamic = 'force-dynamic';

export async function GET() {
  const row = await prisma.tokenMetadata.findFirst();
  const contract = env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS;
  const deployed = !isPlaceholder(contract);

  return NextResponse.json({
    name: row?.name || env.NEXT_PUBLIC_TOKEN_NAME,
    symbol: row?.symbol || env.NEXT_PUBLIC_TOKEN_SYMBOL,
    decimals: row?.decimals ?? env.TOKEN_DECIMALS,
    network: row?.network ?? null,
    chainId: row?.chainId ?? null,
    contractAddress: deployed ? contract : null,
    isDeployed: row?.isDeployed && deployed,
    blockExplorer: env.NEXT_PUBLIC_BLOCK_EXPLORER_URL,
  });
}
