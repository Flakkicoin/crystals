import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { z } from 'zod';
import { toChecksumAddress } from '@/lib/chain-utils';

const AllocationSchema = z.object({
  id: z.string().optional(),
  category: z.string().min(1).max(64),
  label: z.string().min(1).max(128),
  percentage: z.number().min(0).max(100).nullable().optional(),
  amount: z.string().nullable().optional(),
  vestingMonths: z.number().int().min(0).max(120).nullable().optional(),
  cliffMonths: z.number().int().min(0).max(120).nullable().optional(),
  unlockDate: z.string().nullable().optional(),
  walletAddress: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  order: z.number().int().min(0).max(1000),
});

const Body = z.object({ rows: z.array(AllocationSchema) });

export const dynamic = 'force-dynamic';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const rows = await prisma.tokenomicsAllocation.findMany({ orderBy: [{ order: 'asc' }, { category: 'asc' }] });
  return NextResponse.json({ rows });
}

export async function PUT(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const body = await req.json().catch(() => null);
  const parsed = Body.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });

  // Validate sum of percentages
  const total = parsed.data.rows.reduce((acc, r) => acc + (r.percentage ?? 0), 0);
  if (total > 0 && Math.abs(total - 100) > 0.01) {
    return NextResponse.json({ error: `Percentages must sum to 100 (got ${total.toFixed(2)})` }, { status: 400 });
  }

  // Upsert by category
  const results = [] as any[];
  for (const r of parsed.data.rows) {
    let wallet = r.walletAddress;
    if (wallet) {
      const cs = toChecksumAddress(wallet);
      if (!cs) return NextResponse.json({ error: `Invalid wallet for ${r.category}` }, { status: 400 });
      wallet = cs;
    }
    const data = {
      category: r.category,
      label: r.label,
      percentage: r.percentage ?? null,
      amount: r.amount ?? null,
      vestingMonths: r.vestingMonths ?? null,
      cliffMonths: r.cliffMonths ?? null,
      unlockDate: r.unlockDate ? new Date(r.unlockDate) : null,
      walletAddress: wallet ?? null,
      notes: r.notes ?? null,
      order: r.order,
      updatedBy: guard.session.userId!,
    };
    const row = await prisma.tokenomicsAllocation.upsert({
      where: { category: r.category } as any,
      update: data,
      create: data,
    });
    results.push(row);
  }
  await audit({ userId: guard.session.userId, action: 'tokenomics.update', metadata: { count: results.length } });
  return NextResponse.json({ rows: results });
}
