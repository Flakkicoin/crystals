/**
 * Admin — randomness source management.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { invalidateRandomnessCache, listAvailableSources } from '@/lib/randomness';
import { z } from 'zod';

const UpdateSchema = z.object({
  source: z.string().min(1),
  description: z.string().max(500).optional(),
  isEnabled: z.boolean().optional(),
});

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const config = await prisma.randomnessConfig.findFirst();
  return NextResponse.json({ config, available: listAvailableSources() });
}

export async function PUT(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const body = await req.json().catch(() => null);
  const parsed = UpdateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });
  const available = listAvailableSources();
  if (!available.find((s) => s.id === parsed.data.source)) {
    return NextResponse.json({ error: `Unknown randomness source: ${parsed.data.source}` }, { status: 400 });
  }
  // Find existing or create new
  const existing = await prisma.randomnessConfig.findFirst();
  const config = existing
    ? await prisma.randomnessConfig.update({ where: { id: existing.id }, data: { ...parsed.data, updatedBy: guard.session.userId! } })
    : await prisma.randomnessConfig.create({ data: { ...parsed.data, updatedBy: guard.session.userId! } });
  invalidateRandomnessCache();
  await audit({ userId: guard.session.userId, action: 'admin.daily-prize.randomness.update', resource: config.id, metadata: parsed.data as any });
  return NextResponse.json({ config });
}
