/**
 * Admin — daily-prize aggregate stats.
 */
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });

  const since = new Date(Date.now() - 30 * 86_400_000);

  const [totalSpins, spinsLast30d, uniqueWallets, totalPoints, totalRaffles, prizeCounts, recentSpins] = await Promise.all([
    prisma.dailySpin.count(),
    prisma.dailySpin.count({ where: { createdAt: { gte: since } } }),
    prisma.spinStreak.count(),
    prisma.spinStreak.aggregate({ _sum: { totalPoints: true } }),
    prisma.spinStreak.aggregate({ _sum: { totalRaffles: true } }),
    prisma.dailySpin.groupBy({ by: ['prizeCode'], _count: { prizeCode: true } }),
    prisma.dailySpin.findMany({ orderBy: { createdAt: 'desc' }, take: 25 }),
  ]);

  return NextResponse.json({
    totalSpins,
    spinsLast30d,
    uniqueWallets,
    totalPointsAwarded: totalPoints._sum.totalPoints ?? 0,
    totalRafflesAwarded: totalRaffles._sum.totalRaffles ?? 0,
    prizeDistribution: prizeCounts.map((p) => ({ code: p.prizeCode, count: p._count.prizeCode })),
    recentSpins: recentSpins.map((r) => ({
      id: r.id,
      wallet: r.walletAddress,
      date: r.spinDate,
      prize: r.prizeCode,
      streak: r.streak,
      bonus: r.bonusCode,
      seed: r.serverSeed,
      createdAt: r.createdAt,
    })),
  });
}
