/**
 * Admin — delete a single prize.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function DELETE(_req: NextRequest, { params }: { params: { code: string } }) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const code = params.code;
  const item = await prisma.prizeCatalogItem.findUnique({ where: { code } });
  if (!item) return NextResponse.json({ error: 'Prize not found' }, { status: 404 });
  // We do NOT hard-delete — instead, set isActive=false. Existing spins that
  // reference the prize code retain their copy. This preserves auditability.
  await prisma.prizeCatalogItem.update({
    where: { code },
    data: { isActive: false, updatedBy: guard.session.userId! },
  });
  await audit({ userId: guard.session.userId, action: 'admin.daily-prize.prize.deactivate', resource: code });
  return NextResponse.json({ ok: true });
}
