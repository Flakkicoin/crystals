/**
 * Admin — manage raffle tiers.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { z } from 'zod';

const TierSchema = z.object({
  code: z.string().min(2).max(64).regex(/^[A-Z0-9_]+$/),
  label: z.string().min(1).max(128),
  description: z.string().min(1).max(500),
  disclosure: z.string().min(1).max(500),
  numWinners: z.number().int().min(1).max(10_000),
  isActive: z.boolean().optional(),
  order: z.number().int().min(0).max(10_000).optional(),
});

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const tiers = await prisma.raffleTier.findMany({ orderBy: [{ order: 'asc' }, { numWinners: 'desc' }] });
  return NextResponse.json({ tiers });
}

export async function POST(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const body = await req.json().catch(() => null);
  const parsed = TierSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  const tier = await prisma.raffleTier.upsert({
    where: { code: parsed.data.code },
    update: { ...parsed.data, updatedBy: guard.session.userId! },
    create: { ...parsed.data, updatedBy: guard.session.userId! },
  });
  await audit({ userId: guard.session.userId, action: 'admin.daily-prize.raffle-tier.upsert', resource: tier.id, metadata: parsed.data as any });
  return NextResponse.json({ tier });
}
