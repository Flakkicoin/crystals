/**
 * Admin — prize catalog management.
 * Read/update/add/remove prizes. Changes are cached for 10s on the read path.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { z } from 'zod';

const PrizeSchema = z.object({
  code: z.string().min(2).max(64).regex(/^[A-Z0-9_]+$/),
  label: z.string().min(1).max(128),
  description: z.string().min(1).max(500),
  category: z.enum(['points', 'raffle', 'badge', 'streak_freeze', 'none']),
  weight: z.number().int().min(1).max(100_000),
  color: z.string().min(1).max(128),
  points: z.number().int().min(0).max(1_000_000).nullable().optional(),
  raffles: z.number().int().min(0).max(1_000_000).nullable().optional(),
  freezesStreak: z.boolean().optional(),
  disclosure: z.string().min(1).max(500),
  isActive: z.boolean().optional(),
  order: z.number().int().min(0).max(10_000).optional(),
});

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const items = await prisma.prizeCatalogItem.findMany({ orderBy: [{ order: 'asc' }, { code: 'asc' }] });
  const totalWeight = items.reduce((acc, p) => acc + p.weight, 0);
  return NextResponse.json({ items, totalWeight });
}

export async function POST(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const body = await req.json().catch(() => null);
  const parsed = PrizeSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  const item = await prisma.prizeCatalogItem.upsert({
    where: { code: parsed.data.code },
    update: { ...parsed.data, updatedBy: guard.session.userId! },
    create: { ...parsed.data, updatedBy: guard.session.userId! },
  });
  await audit({ userId: guard.session.userId, action: 'admin.daily-prize.prize.upsert', resource: item.id, metadata: parsed.data as any });
  return NextResponse.json({ item });
}
