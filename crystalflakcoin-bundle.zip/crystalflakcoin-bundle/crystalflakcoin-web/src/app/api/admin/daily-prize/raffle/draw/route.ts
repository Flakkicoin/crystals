/**
 * Admin — trigger a raffle draw for a period.
 *
 * POST body: { period: "2026-Q1", dryRun?: boolean }
 * - dryRun: true returns the result without persisting
 * - dryRun: false (default) persists the draw and individual winners
 *
 * Idempotent: re-running for a period that already has a draw returns
 * the previous result.
 */
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { runRaffleDraw } from '@/lib/raffle-draw';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';

const Body = z.object({
  period: z.string().min(1).max(64),
  dryRun: z.boolean().optional(),
});

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const body = await req.json().catch(() => ({}));
  const parsed = Body.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  try {
    const result = await runRaffleDraw({
      period: parsed.data.period,
      drawnBy: guard.session.userId!,
      dryRun: parsed.data.dryRun,
    });
    if (!result.alreadyDrawn && !parsed.data.dryRun) {
      await audit({
        userId: guard.session.userId,
        action: 'admin.daily-prize.raffle-draw',
        resource: parsed.data.period,
        metadata: { totalEntries: result.totalEntries, totalUniqueWallets: result.totalUniqueWallets, serverSeed: result.serverSeed },
      });
    }
    return NextResponse.json({ ok: true, result });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Draw failed' }, { status: 400 });
  }
}

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const [draws, totalEntries] = await Promise.all([
    prisma.raffleDraw.findMany({ orderBy: { drawnAt: 'desc' } }),
    prisma.raffleEntry.count(),
  ]);
  // Group entries by period
  const grouped: Record<string, number> = {};
  for (const e of await prisma.raffleEntry.groupBy({ by: ['period'], _count: { period: true } })) {
    grouped[e.period] = e._count.period;
  }
  return NextResponse.json({ draws, entriesByPeriod: grouped, totalEntries });
}
