import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { TokenMetadataUpdateSchema } from '@/lib/validation';
import { toChecksumAddress } from '@/lib/chain-utils';

export const dynamic = 'force-dynamic';

export async function GET() {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });

  let row = await prisma.tokenMetadata.findFirst();
  if (!row) {
    row = await prisma.tokenMetadata.create({
      data: { name: 'CrystalFlakCoin', symbol: 'CFC', decimals: 18, isDeployed: false, updatedBy: guard.session.userId! },
    });
  }
  return NextResponse.json({ row });
}

export async function PUT(req: NextRequest) {
  const guard = await requireAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });

  let body: unknown;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }); }
  const parsed = TokenMetadataUpdateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });

  // Address checksum if provided
  if (parsed.data.contractAddress) {
    const cs = toChecksumAddress(parsed.data.contractAddress);
    if (!cs) return NextResponse.json({ error: 'Invalid contract address' }, { status: 400 });
    parsed.data.contractAddress = cs;
  }

  const existing = await prisma.tokenMetadata.findFirst();
  const row = existing
    ? await prisma.tokenMetadata.update({ where: { id: existing.id }, data: { ...parsed.data, updatedBy: guard.session.userId! } })
    : await prisma.tokenMetadata.create({ data: { name: 'CrystalFlakCoin', symbol: 'CFC', decimals: 18, isDeployed: false, updatedBy: guard.session.userId!, ...parsed.data } });

  await audit({ userId: guard.session.userId, action: 'token.update', resource: row.id, metadata: parsed.data as any });
  return NextResponse.json({ row });
}
