/**
 * Open Graph image generator.
 * Returns a 1200×630 PNG with the CrystalFlakCoin brand.
 * Uses pure SVG-to-PNG via the @vercel/og library (already optional).
 * Falls back to a server-rendered SVG image if @vercel/og is unavailable.
 */
import { ImageResponse } from 'next/og';
import { NextRequest } from 'next/server';
import { BRAND } from '@/lib/brand';
import { BRAND_GRADIENTS } from '@/lib/brand-tokens';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const title = searchParams.get('title') || BRAND.name;
  const subtitle = searchParams.get('subtitle') || BRAND.tagline;
  const cfcTicker = searchParams.get('ticker') || BRAND.ticker;

  try {
    return new ImageResponse(
      (
        <div
          style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            padding: '80px',
            background: BRAND_GRADIENTS.crystal,
            backgroundImage: 'radial-gradient(ellipse at 50% 0%, rgba(125,211,252,0.4) 0%, transparent 60%), radial-gradient(ellipse at 100% 100%, rgba(217,70,239,0.3) 0%, transparent 60%)',
            color: '#ffffff',
            fontFamily: 'Inter, system-ui, sans-serif',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <Crystal />
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: 4, color: '#bae6fd' }}>{BRAND.name.toUpperCase()}</div>
              <div style={{ fontSize: 16, letterSpacing: 8, color: '#a855f7' }}>{cfcTicker}</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: '950px' }}>
            <div style={{ fontSize: 64, fontWeight: 800, lineHeight: 1.1, letterSpacing: '-1px' }}>{title}</div>
            <div style={{ fontSize: 28, lineHeight: 1.4, color: '#e9d8ff', opacity: 0.85 }}>{subtitle}</div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div style={{ fontSize: 18, color: '#7dd3fc' }}>crystalflakcoin.example</div>
            <div style={{ fontSize: 14, color: '#b6a3d4', textTransform: 'uppercase', letterSpacing: 2 }}>Transparent digital asset project</div>
          </div>
        </div>
      ),
      {
        width: 1200,
        height: 630,
        headers: {
          'Cache-Control': 'public, max-age=3600, s-maxage=3600',
        },
      },
    );
  } catch (e) {
    // Fallback: return an SVG image if @vercel/og is unavailable
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
      <defs>
        <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#0a1530"/>
          <stop offset="100%" stop-color="#1e1b4b"/>
        </linearGradient>
      </defs>
      <rect width="1200" height="630" fill="url(#g)"/>
      <text x="80" y="500" font-family="Inter, sans-serif" font-size="48" font-weight="800" fill="#ffffff">${escapeXml(title)}</text>
      <text x="80" y="550" font-family="Inter, sans-serif" font-size="20" fill="#bae6fd">${escapeXml(subtitle)}</text>
      <text x="80" y="600" font-family="Inter, sans-serif" font-size="14" fill="#a855f7">crystalflakcoin.example</text>
    </svg>`;
    return new Response(svg, {
      headers: { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=3600' },
    });
  }
}

function escapeXml(s: string) {
  return s.replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]!));
}

function Crystal() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 120, height: 120 }}>
      <svg viewBox="0 0 200 240" width="120" height="120">
        <defs>
          <linearGradient id="og-crystal" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#7c3aed"/>
            <stop offset="50%" stop-color="#a855f7"/>
            <stop offset="100%" stop-color="#d946ef"/>
          </linearGradient>
        </defs>
        <polygon points="100,8 184,86 156,200 100,232 44,200 16,86" fill="url(#og-crystal)" stroke="#ffffff" stroke-opacity=".4" strokeWidth="1.5"/>
        <polygon points="100,8 184,86 100,108 16,86" fill="#ffffff" fill-opacity=".2"/>
        <polygon points="100,232 156,200 100,108 44,200" fill="#000000" fill-opacity=".2"/>
      </svg>
    </div>
  );
}
