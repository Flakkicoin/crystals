import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  // Only return proposals that have an on-chain externalId (i.e. fetched from a verified source).
  // Drafts and placeholder rows are excluded from the public API.
  const proposals = await prisma.governanceProposal.findMany({
    where: { externalId: { not: null } },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json({ proposals });
}
