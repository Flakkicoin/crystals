'use client';
import { useFormState, useFormStatus } from 'react-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import { env, isPlaceholder } from '@/lib/env';
import { submitContactForm, type ContactState } from '@/app/actions/contact';

export default function ContactPage() {
  const support = env.NEXT_PUBLIC_SUPPORT_EMAIL;
  const security = env.NEXT_PUBLIC_SECURITY_EMAIL;
  const [state, action] = useFormState<ContactState, FormData>(submitContactForm, { ok: false });

  return (
    <div className="container py-16 space-y-10 max-w-3xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Contact</h1>
        <p className="text-muted-foreground">
          Reach out to the project. For security issues, please use the dedicated channel.
        </p>
      </header>

      <Card className="border-amber-500/30 bg-amber-500/5">
        <CardContent className="pt-6 text-amber-100/80 text-sm flex items-start gap-2">
          <AlertTriangle className="h-5 w-5 mt-0.5 shrink-0" />
          <p>
            <strong>CrystalFlakCoin will never ask for your seed phrase or private key.</strong>{' '}
            Anyone asking for these is attempting theft. Do not send them. We cannot recover lost
            credentials.
          </p>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-4 text-sm">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Support</CardTitle>
            <CardDescription>General questions, partnership inquiries.</CardDescription>
          </CardHeader>
          <CardContent>
            {support && !isPlaceholder(support) ? (
              <a href={`mailto:${support}`} className="text-sky-300 hover:underline">{support}</a>
            ) : <span className="text-muted-foreground italic">To be announced</span>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Security</CardTitle>
            <CardDescription>Vulnerability reports. We follow coordinated disclosure.</CardDescription>
          </CardHeader>
          <CardContent>
            {security && !isPlaceholder(security) ? (
              <a href={`mailto:${security}`} className="text-sky-300 hover:underline">{security}</a>
            ) : <span className="text-muted-foreground italic">To be announced</span>}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Send a message</CardTitle>
          <CardDescription>For non-sensitive inquiries. Do not include financial information.</CardDescription>
        </CardHeader>
        <CardContent>
          <form action={action} className="grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" name="name" required minLength={1} maxLength={120} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" required maxLength={200} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" name="message" required minLength={1} maxLength={4000} />
            </div>
            {state.error && (
              <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{state.error}</AlertDescription></Alert>
            )}
            {state.ok && state.message && (
              <Alert><AlertTitle>Sent</AlertTitle><AlertDescription>{state.message}</AlertDescription></Alert>
            )}
            <SubmitButton />
            <RiskDisclaimer variant="compact" />
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" variant="ice" disabled={pending}>
      {pending ? 'Sending…' : 'Send'}
    </Button>
  );
}
