import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { Eye, Users, Code2 } from 'lucide-react';

export const metadata = { title: 'About' };

export default function AboutPage() {
  return (
    <div className="container py-16 space-y-12 max-w-4xl">
      <header className="space-y-4">
        <h1 className="font-display text-3xl md:text-5xl font-bold">About CrystalFlakCoin</h1>
        <p className="text-lg text-muted-foreground">
          CrystalFlakCoin (CFC) is a transparent, community-driven digital asset project. The
          project's purpose is to provide a verifiable on-chain primitive — not to generate
          returns for any party.
        </p>
      </header>

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold">Purpose</h2>
        <p className="text-muted-foreground">
          We are building an open, documented digital asset that can be inspected, audited, and
          reasoned about by anyone. We do not promise that the asset will appreciate, that any
          service built on top of it will succeed, or that holders will receive any form of yield.
          Those outcomes depend on independent market, technical, and regulatory conditions.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold">Design principles</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <Principle icon={<Eye className="h-5 w-5" />} title="Transparency" body="Every fact published on this site is traceable to an on-chain or document source. If we cannot verify it, we say 'to be announced'." />
          <Principle icon={<Users className="h-5 w-5" />} title="User control" body="CrystalFlakCoin never custodies user funds. Every interaction is a signed transaction from the user's own wallet." />
          <Principle icon={<Code2 className="h-5 w-5" />} title="Open development" body="All contracts, documentation, and tooling are open source. Reports and contributions are welcome." />
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-bold">What this project is not</h2>
        <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
          <li>CrystalFlakCoin is <strong>not</strong> an investment vehicle.</li>
          <li>It is <strong>not</strong> a securities offering and has not been registered as one in any jurisdiction.</li>
          <li>It does <strong>not</strong> provide financial, investment, legal, or tax advice.</li>
          <li>It does <strong>not</strong> offer recruitment, multi-level, or affiliate compensation.</li>
        </ul>
      </section>

      <RiskDisclaimer variant="banner" />
    </div>
  );
}

function Principle({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <Card className="crystal-card">
      <CardHeader>
        <div className="h-10 w-10 rounded-md bg-violet-400/10 border border-violet-400/20 flex items-center justify-center text-violet-300 mb-2">
          {icon}
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{body}</p>
      </CardContent>
    </Card>
  );
}
