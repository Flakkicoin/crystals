import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { prisma } from '@/lib/prisma';
import { env, isPlaceholder } from '@/lib/env';
import { ExternalLink, Github, FileText, Wallet } from 'lucide-react';
import Link from 'next/link';

export const metadata = { title: 'Transparency' };
export const dynamic = 'force-dynamic';

export default async function TransparencyPage() {
  const networks = await prisma.supportedNetwork.findMany({ where: { enabled: true }, orderBy: { chainId: 'asc' } });
  const tokenMeta = await prisma.tokenMetadata.findFirst();
  const auditReports = [] as Array<{ title: string; url: string | null; status: string }>;

  return (
    <div className="container py-16 space-y-10 max-w-4xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Transparency</h1>
        <p className="text-muted-foreground">
          Verified information about the project. Where information is not yet available, this
          page clearly states so rather than inventing values.
        </p>
      </header>

      <RiskDisclaimer variant="compact" />

      <Section title="Contract & network">
        <div className="grid md:grid-cols-2 gap-3 text-sm">
          <Row k="Token" v={env.NEXT_PUBLIC_TOKEN_NAME} />
          <Row k="Symbol" v={env.NEXT_PUBLIC_TOKEN_SYMBOL} />
          <Row k="Contract address" v={tokenMeta?.contractAddress && !isPlaceholder(tokenMeta.contractAddress) ? <code className="font-mono">{tokenMeta.contractAddress}</code> : <NotAvailable />} />
          <Row k="Network" v={tokenMeta?.network ?? <NotAvailable />} />
          <Row k="Block explorer" v={
            <a href={env.NEXT_PUBLIC_BLOCK_EXPLORER_URL} target="_blank" rel="noopener noreferrer" className="text-sky-300 inline-flex items-center gap-1 hover:underline">
              {env.NEXT_PUBLIC_BLOCK_EXPLORER_URL} <ExternalLink className="h-3 w-3" />
            </a>
          } />
          <Row k="Source code" v={
            env.NEXT_PUBLIC_GITHUB_URL && !isPlaceholder(env.NEXT_PUBLIC_GITHUB_URL) ? (
              <a href={env.NEXT_PUBLIC_GITHUB_URL} target="_blank" rel="noopener noreferrer" className="text-sky-300 inline-flex items-center gap-1 hover:underline">
                <Github className="h-3 w-3" /> Repository
              </a>
            ) : <NotAvailable />
          } />
        </div>
      </Section>

      <Section title="Audit reports">
        {auditReports.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            <NotAvailable /> — No public audit report has been published. CrystalFlakCoin does not
            claim to be audited unless a verifiable report is linked here.
          </p>
        ) : (
          <ul className="space-y-2 text-sm">
            {auditReports.map((a) => (
              <li key={a.title} className="flex items-center justify-between p-3 rounded-md border border-white/10">
                <span className="flex items-center gap-2"><FileText className="h-4 w-4" /> {a.title}</span>
                {a.url ? <a href={a.url} className="text-sky-300 hover:underline" target="_blank" rel="noopener noreferrer">View</a> : <Badge variant="muted">Not available</Badge>}
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Treasury">
        <p className="text-sm text-muted-foreground">
          Treasury wallet addresses and on-chain balances are not yet published. When available,
          they will be listed here with their purpose, vesting, and on-chain activity.
        </p>
      </Section>

      <Section title="Supported networks">
        <div className="grid sm:grid-cols-2 gap-3">
          {networks.map((n) => (
            <div key={n.id} className="p-3 rounded-md border border-white/10 bg-white/[0.02] flex items-center justify-between">
              <div>
                <div className="font-medium">{n.name}</div>
                <div className="text-xs text-muted-foreground">Chain ID {n.chainId}</div>
              </div>
              <div className="flex items-center gap-2">
                {n.isTestnet && <Badge variant="warning">Testnet</Badge>}
                <a href={n.explorerUrl} target="_blank" rel="noopener noreferrer" className="text-sky-300 hover:underline text-xs">Explorer</a>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Change log & incident reports">
        <p className="text-sm text-muted-foreground">
          A public change log and incident report timeline will be published at this URL once the
          project is live. Until then, see <Link href="/docs" className="underline">documentation</Link>{' '}
          for the latest updates.
        </p>
      </Section>

      <Section title="Contact">
        <div className="text-sm space-y-1">
          <p className="flex items-center gap-2"><Wallet className="h-4 w-4" /> Support: {env.NEXT_PUBLIC_SUPPORT_EMAIL ?? <NotAvailable />}</p>
          <p className="flex items-center gap-2"><FileText className="h-4 w-4" /> Security reports: {env.NEXT_PUBLIC_SECURITY_EMAIL ?? <NotAvailable />}</p>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{k}</span>
      <span>{v}</span>
    </div>
  );
}

function NotAvailable() {
  return <span className="text-muted-foreground italic">Not available</span>;
}
