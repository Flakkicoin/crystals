import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, BookOpen, Code2, Boxes, Plug } from 'lucide-react';

export const metadata = { title: 'Ecosystem' };

const sections = [
  {
    icon: Users,
    title: 'Community governance',
    body: 'Token holders can submit and vote on protocol changes through the governance interface. Quorum requirements and voting periods are configured by the deployed contract.',
    status: 'Planned' as const,
  },
  {
    icon: BookOpen,
    title: 'Educational resources',
    body: 'Guides covering wallet safety, transaction verification, and how to read on-chain data. Content is open and licensed for reuse.',
    status: 'Live' as const,
  },
  {
    icon: Code2,
    title: 'Developer tools',
    body: 'TypeScript SDK, contract ABIs, and example integrations. Open source under a permissive license.',
    status: 'Planned' as const,
  },
  {
    icon: Boxes,
    title: 'Ecosystem applications',
    body: 'Third-party services that integrate with the CrystalFlakCoin contract. Listed applications are independently operated and not endorsed.',
    status: 'Planned' as const,
  },
  {
    icon: Plug,
    title: 'Future integrations',
    body: 'Cross-chain bridges, additional network support, and partner integrations under evaluation. Inclusion does not guarantee launch.',
    status: 'Under evaluation' as const,
  },
];

export default function EcosystemPage() {
  return (
    <div className="container py-16 space-y-10 max-w-5xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Ecosystem</h1>
        <p className="text-muted-foreground">
          The CrystalFlakCoin ecosystem consists of educational resources, developer tooling,
          governance, and integrations. Unreleased features are clearly marked as Planned.
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-4">
        {sections.map((s) => (
          <Card key={s.title} className="crystal-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="h-10 w-10 rounded-md bg-sky-400/10 border border-sky-400/20 flex items-center justify-center text-sky-300">
                  <s.icon className="h-5 w-5" />
                </div>
                <Badge variant={s.status === 'Live' ? 'success' : s.status === 'Planned' ? 'muted' : 'warning'}>
                  {s.status}
                </Badge>
              </div>
              <CardTitle className="text-lg mt-3">{s.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{s.body}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      <p className="text-xs text-muted-foreground">
        Third-party services listed in the ecosystem are independently operated. Inclusion does
        not imply endorsement. Always verify the official contract address before interacting.
      </p>
    </div>
  );
}
