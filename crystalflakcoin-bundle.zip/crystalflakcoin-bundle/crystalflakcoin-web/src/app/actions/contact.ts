'use server';

import { z } from 'zod';
import { rateLimit, clientKeyFromRequest } from '@/lib/rate-limit';
import { headers } from 'next/headers';
import { audit } from '@/lib/audit';

const Schema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email().max(200),
  message: z.string().min(1).max(4000),
});

export type ContactState = { ok: boolean; message?: string; error?: string };

export async function submitContactForm(_prev: ContactState, formData: FormData): Promise<ContactState> {
  const parsed = Schema.safeParse({
    name: formData.get('name'),
    email: formData.get('email'),
    message: formData.get('message'),
  });
  if (!parsed.success) {
    return { ok: false, error: 'Invalid input. Please review the form.' };
  }

  // Rate limit per IP — 5 submissions / 10 min
  const h = headers();
  const fakeReq = new Request('http://x', { headers: new Headers([['x-forwarded-for', h.get('x-forwarded-for') || h.get('x-real-ip') || 'unknown']]) });
  const rl = await rateLimit({ key: `contact:${clientKeyFromRequest(fakeReq)}`, limit: 5, windowMs: 10 * 60_000 });
  if (!rl.ok) {
    return { ok: false, error: 'Too many submissions. Please try again later.' };
  }

  // Sanitize: never log the raw message body, only metadata
  await audit({
    action: 'contact.submit',
    metadata: { emailDomain: parsed.data.email.split('@')[1] || 'unknown', messageLength: parsed.data.message.length },
  });

  // Email delivery is intentionally not implemented here. Hook into your SMTP / queue.
  return { ok: true, message: 'Thanks — we will be in touch if a response is needed.' };
}
