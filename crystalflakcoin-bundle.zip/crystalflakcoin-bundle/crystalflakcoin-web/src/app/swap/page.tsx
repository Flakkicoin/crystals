import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { env, isPlaceholder } from '@/lib/env';
import { AlertTriangle, ArrowDownUp } from 'lucide-react';

export const metadata = { title: 'Swap' };

export default function SwapPage() {
  const enabled = env.NEXT_PUBLIC_ENABLE_SWAP && !isPlaceholder(env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS);

  return (
    <div className="container py-16 space-y-8 max-w-3xl">
      <header className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-3xl md:text-5xl font-bold">Swap</h1>
          {enabled ? <Badge variant="success">Available</Badge> : <Badge variant="warning">Not available</Badge>}
        </div>
        <p className="text-muted-foreground">
          Token-to-token swaps route through verified liquidity pools. This interface is
          non-custodial: every swap is a signed transaction in your own wallet.
        </p>
      </header>

      {!enabled ? (
        <Card>
          <CardHeader>
            <CardTitle>Swapping is not yet available</CardTitle>
            <CardDescription>
              The official contract and liquidity pool have not been confirmed. This page will
              become active only after the contract is deployed, audited, and a verified liquidity
              pool exists.
            </CardDescription>
          </CardHeader>
        </Card>
      ) : (
        <SwapInterface />
      )}

      <RiskDisclaimer
        variant="banner"
        context="Blockchain transactions are irreversible. Once submitted, a swap cannot be undone by CrystalFlakCoin or anyone else."
      />

      <Card>
        <CardHeader>
          <CardTitle>Safety checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="text-sm text-muted-foreground space-y-2 list-disc pl-5">
            <li>Always verify the contract address on the <a className="underline" href="/token">Token</a> page before swapping.</li>
            <li>Set a reasonable slippage tolerance. High values expose you to MEV and sandwich attacks.</li>
            <li>Read the price-impact warning. Large trades on thin pools can move the price significantly.</li>
            <li>Never sign a transaction whose method, contract, or amount you do not understand.</li>
            <li>Test with a small amount first.</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

function SwapInterface() {
  // Placeholder UI; real implementation reads verified pool reserves via wagmi/viem.
  return (
    <Card>
      <CardHeader>
        <CardTitle>Swap tokens</CardTitle>
        <CardDescription>This is a UI scaffold. A swap is only sent for signature after you confirm the on-chain quote.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 rounded-md border border-white/10 bg-white/[0.02]">
          <label className="text-xs text-muted-foreground">From</label>
          <div className="flex items-center justify-between mt-1">
            <input defaultValue="0" className="bg-transparent text-2xl font-display w-1/2 outline-none" />
            <span className="text-sm text-muted-foreground">ETH</span>
          </div>
        </div>
        <div className="flex justify-center">
          <div className="h-10 w-10 rounded-full border border-white/10 flex items-center justify-center bg-background">
            <ArrowDownUp className="h-4 w-4" />
          </div>
        </div>
        <div className="p-4 rounded-md border border-white/10 bg-white/[0.02]">
          <label className="text-xs text-muted-foreground">To (estimated)</label>
          <div className="flex items-center justify-between mt-1">
            <input defaultValue="0" className="bg-transparent text-2xl font-display w-1/2 outline-none" />
            <span className="text-sm text-muted-foreground">CFC</span>
          </div>
        </div>
        <div className="text-xs text-muted-foreground p-3 rounded-md bg-amber-500/5 border border-amber-500/30 text-amber-200 flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
          <span>You will be asked to sign a transaction in your wallet. Blockchain transactions are irreversible. The exact contract and method will be shown before signing.</span>
        </div>
        <Button variant="ice" className="w-full" disabled>Connect wallet to swap</Button>
      </CardContent>
    </Card>
  );
}
