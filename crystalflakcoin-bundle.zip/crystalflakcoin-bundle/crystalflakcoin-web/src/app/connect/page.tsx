'use client';
import { useAccount, useConnect, useDisconnect, useChainId, useSwitchChain } from 'wagmi';
import { WalletButton } from '@/components/wallet/wallet-button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, RefreshCw, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { shortenAddress } from '@/lib/chain-utils';
import { supportedChainIds } from '@/lib/env';

export default function ConnectPage() {
  const { address, isConnected } = useAccount();
  const { connect, connectors, isPending } = useConnect();
  const { disconnect } = useDisconnect();
  const chainId = useChainId();
  const { switchChain, isPending: switching } = useSwitchChain();

  const isSupported = supportedChainIds.includes(chainId);

  return (
    <div className="container py-16 max-w-2xl space-y-6">
      <header>
        <h1 className="font-display text-3xl md:text-4xl font-bold">Connect wallet</h1>
        <p className="text-muted-foreground mt-2">
          Connect a wallet to view your CrystalFlakCoin balance and on-chain activity. Your
          private keys and seed phrase are never shared with this site.
        </p>
      </header>

      {!isConnected ? (
        <Card>
          <CardHeader>
            <CardTitle>Choose a wallet</CardTitle>
            <CardDescription>WalletConnect, MetaMask, Coinbase Wallet, Rainbow, and more.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2">
            {connectors.map((c) => (
              <button
                key={c.uid}
                disabled={isPending}
                onClick={() => connect({ connector: c })}
                className="w-full flex items-center justify-between p-3 rounded-md border border-white/10 hover:border-primary/50 hover:bg-white/5 transition-colors text-left disabled:opacity-50"
              >
                <span className="font-medium">{c.name}</span>
                <span className="text-xs text-muted-foreground">Connect</span>
              </button>
            ))}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Connected</CardTitle>
              {isSupported ? <Badge variant="success">Network supported</Badge> : <Badge variant="warning">Unsupported network</Badge>}
            </div>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row k="Address" v={
              <span className="flex items-center gap-2 font-mono">
                {address}
                <button onClick={() => navigator.clipboard.writeText(address!)} className="text-muted-foreground hover:text-foreground" title="Copy"><Copy className="h-3.5 w-3.5" /></button>
              </span>
            } />
            <Row k="Short" v={<span className="font-mono">{shortenAddress(address!)}</span>} />
            <Row k="Chain ID" v={String(chainId)} />
            {!isSupported && (
              <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-amber-200 text-xs flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>You are connected to an unsupported network. Switch to a supported network to use the dashboard.</span>
              </div>
            )}
            <div className="flex gap-2 flex-wrap">
              {supportedChainIds.map((id) => (
                <Button key={id} size="sm" variant="outline" onClick={() => switchChain({ chainId: id })} disabled={switching}>
                  <RefreshCw className="h-3 w-3 mr-1" /> Switch to chain {id}
                </Button>
              ))}
              <Button size="sm" variant="destructive" onClick={() => disconnect()}>Disconnect</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      <span className="text-xs uppercase tracking-wider text-muted-foreground col-span-1">{k}</span>
      <span className="col-span-2">{v}</span>
    </div>
  );
}
