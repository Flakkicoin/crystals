import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';
export default async function AdminContentPage() {
  const pages = await prisma.documentationPage.findMany({ orderBy: [{ category: 'asc' }, { order: 'asc' }] });
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Documentation</h1>
      <p className="text-sm text-muted-foreground">Editorial interface is stubbed for this scaffold; pages are CRUD via the database.</p>
      <div className="space-y-2">
        {pages.length === 0 ? (
          <Card><CardContent className="py-6 text-sm text-muted-foreground">No documentation pages yet.</CardContent></Card>
        ) : pages.map((p) => (
          <Card key={p.id}>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>{p.title}</span>
                <div className="flex items-center gap-2">
                  <Badge variant="ice">{p.category}</Badge>
                  {p.published ? <Badge variant="success">Published</Badge> : <Badge variant="muted">Draft</Badge>}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">/{p.slug}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
