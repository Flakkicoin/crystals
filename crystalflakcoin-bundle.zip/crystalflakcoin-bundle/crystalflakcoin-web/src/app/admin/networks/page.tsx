import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';
export default async function AdminNetworksPage() {
  const networks = await prisma.supportedNetwork.findMany({ orderBy: { chainId: 'asc' } });
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Supported networks</h1>
      <Card>
        <CardHeader><CardTitle className="text-base">Read-only — edit via prisma studio or seed</CardTitle></CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left border-b border-white/10">
                <th className="py-2 pr-3">Chain ID</th><th>Name</th><th>Short</th><th>Testnet</th><th>Enabled</th>
              </tr>
            </thead>
            <tbody>
              {networks.map((n) => (
                <tr key={n.id} className="border-b border-white/5">
                  <td className="py-2 pr-3">{n.chainId}</td>
                  <td>{n.name}</td>
                  <td>{n.shortName}</td>
                  <td>{n.isTestnet ? <Badge variant="warning">Yes</Badge> : <Badge variant="muted">No</Badge>}</td>
                  <td>{n.enabled ? <Badge variant="success">On</Badge> : <Badge variant="muted">Off</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
