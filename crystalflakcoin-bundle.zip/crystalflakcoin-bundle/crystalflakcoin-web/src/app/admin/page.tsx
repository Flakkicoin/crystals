import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const dynamic = 'force-dynamic';

export default async function AdminOverview() {
  const [users, tokens, allocations, proposals, reports, recentLogs] = await Promise.all([
    prisma.user.count(),
    prisma.tokenMetadata.count(),
    prisma.tokenomicsAllocation.count(),
    prisma.governanceProposal.count(),
    prisma.securityReport.count(),
    prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { user: true } }),
  ]);

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-bold">Admin overview</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <Stat label="Users" value={users} />
        <Stat label="Token rows" value={tokens} />
        <Stat label="Allocations" value={allocations} />
        <Stat label="Proposals" value={proposals} />
        <Stat label="Security reports" value={reports} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent audit logs</CardTitle>
        </CardHeader>
        <CardContent>
          {recentLogs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No actions yet.</p>
          ) : (
            <ul className="text-sm space-y-1 font-mono">
              {recentLogs.map((l) => (
                <li key={l.id} className="flex items-center justify-between border-b border-white/5 py-1.5">
                  <span className="text-muted-foreground">{new Date(l.createdAt).toISOString()}</span>
                  <span>{l.action}</span>
                  <span className="text-muted-foreground">{l.user?.email ?? l.ip ?? 'system'}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="font-display text-2xl font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
