import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const dynamic = 'force-dynamic';
export default async function AdminLogsPage() {
  const logs = await prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 200, include: { user: true } });
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Audit logs</h1>
      <Card>
        <CardHeader><CardTitle className="text-base">Most recent 200 actions</CardTitle></CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No actions logged yet.</p>
          ) : (
            <ul className="text-xs font-mono divide-y divide-white/5">
              {logs.map((l) => (
                <li key={l.id} className="py-1.5 flex items-center gap-3 flex-wrap">
                  <span className="text-muted-foreground">{new Date(l.createdAt).toISOString()}</span>
                  <span className="px-1.5 py-0.5 rounded bg-white/5">{l.action}</span>
                  <span className="text-muted-foreground">{l.resource ?? ''}</span>
                  <span className="ml-auto text-muted-foreground">{l.user?.email ?? l.ip ?? 'system'}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
