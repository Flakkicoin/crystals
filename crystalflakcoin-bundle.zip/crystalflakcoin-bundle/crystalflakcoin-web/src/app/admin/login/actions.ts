'use server';
import { LoginSchema } from '@/lib/validation';
import { getSession, loginWithEmail } from '@/lib/auth';
import { audit } from '@/lib/audit';
import { rateLimit, clientKeyFromRequest } from '@/lib/rate-limit';
import { headers } from 'next/headers';

export async function loginAction(formData: FormData) {
  const parsed = LoginSchema.safeParse({ email: formData.get('email'), password: formData.get('password') });
  if (!parsed.success) return { ok: false, error: 'Invalid input' };

  // Rate limit per IP — 10 / 5 min
  const h = headers();
  const fakeReq = new Request('http://x', { headers: new Headers([['x-forwarded-for', h.get('x-forwarded-for') || h.get('x-real-ip') || 'unknown']]) });
  const rl = await rateLimit({ key: `login:${clientKeyFromRequest(fakeReq)}`, limit: 10, windowMs: 5 * 60_000 });
  if (!rl.ok) return { ok: false, error: 'Too many attempts. Please try again later.' };

  const user = await loginWithEmail(parsed.data.email, parsed.data.password);
  if (!user) {
    await audit({ action: 'admin.login.fail', metadata: { emailDomain: parsed.data.email.split('@')[1] } });
    return { ok: false, error: 'Invalid credentials' };
  }
  const session = await getSession();
  session.isLoggedIn = true;
  session.userId = user.id;
  session.email = user.email!;
  session.role = user.role.name;
  session.permissions = user.role.permissions;
  session.csrf = undefined as any; // regenerate
  await session.save();

  await audit({ userId: user.id, action: 'admin.login.success' });
  return { ok: true };
}

export async function logoutAction() {
  const session = await getSession();
  await audit({ userId: session.userId, action: 'admin.logout' });
  session.destroy();
  return { ok: true };
}
