import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';
export default async function AdminSecurityPage() {
  const reports = await prisma.securityReport.findMany({ orderBy: { createdAt: 'desc' } });
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Security reports</h1>
      <p className="text-sm text-muted-foreground">Submissions from the public form. Triage in line with coordinated disclosure.</p>
      <div className="space-y-2">
        {reports.length === 0 ? (
          <Card><CardContent className="py-6 text-sm text-muted-foreground">No reports.</CardContent></Card>
        ) : reports.map((r) => (
          <Card key={r.id}>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>{r.title}</span>
                <div className="flex items-center gap-2">
                  <Badge variant={r.severity === 'critical' ? 'destructive' : r.severity === 'high' ? 'warning' : 'ice'}>
                    {r.severity}
                  </Badge>
                  <Badge variant="muted">{r.status}</Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground line-clamp-3">{r.description}</p>
              <p className="text-xs text-muted-foreground mt-2">{r.reporter ? `From ${r.reporter} · ` : ''}{new Date(r.createdAt).toISOString()}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
