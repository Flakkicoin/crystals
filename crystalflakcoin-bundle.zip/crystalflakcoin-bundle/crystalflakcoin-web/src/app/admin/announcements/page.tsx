import { prisma } from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';
export default async function AdminAnnouncementsPage() {
  const announcements = await prisma.announcement.findMany({ orderBy: { updatedAt: 'desc' } });
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Announcements</h1>
      <p className="text-sm text-muted-foreground">CRUD for /announcements and the public homepage banner. The editor is stubbed for this scaffold.</p>
      <div className="space-y-2">
        {announcements.length === 0 ? (
          <Card><CardContent className="py-6 text-sm text-muted-foreground">No announcements yet.</CardContent></Card>
        ) : announcements.map((a) => (
          <Card key={a.id}>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span>{a.title}</span>
                <div className="flex items-center gap-2">
                  <Badge variant={a.severity === 'critical' ? 'destructive' : a.severity === 'warning' ? 'warning' : 'ice'}>
                    {a.severity}
                  </Badge>
                  {a.published ? <Badge variant="success">Published</Badge> : <Badge variant="muted">Draft</Badge>}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">/{a.slug} · updated {a.updatedAt.toISOString()}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
