'use client';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';

interface Allocation {
  id?: string;
  category: string;
  label: string;
  percentage: number | null;
  amount: string | null;
  vestingMonths: number | null;
  cliffMonths: number | null;
  unlockDate: string | null;
  walletAddress: string | null;
  notes: string | null;
  order: number;
}

const DEFAULT_CATS = ['community', 'ecosystem', 'treasury', 'liquidity', 'development'];

export default function AdminTokenomicsPage() {
  const [rows, setRows] = useState<Allocation[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/admin/tokenomics', { credentials: 'include' })
      .then((r) => r.json())
      .then((j) => setRows(j.rows.length ? j.rows : DEFAULT_CATS.map((c) => empty(c))));
  }, []);

  function empty(category: string): Allocation {
    return { category, label: category.charAt(0).toUpperCase() + category.slice(1), percentage: null, amount: null, vestingMonths: null, cliffMonths: null, unlockDate: null, walletAddress: null, notes: null, order: 0 };
  }

  async function save() {
    setSaving(true);
    const r = await fetch('/api/admin/tokenomics', {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows }),
    });
    setSaving(false);
    if (r.ok) {
      const j = await r.json();
      setRows(j.rows);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold">Tokenomics</h1>
        <Button onClick={save} disabled={saving} variant="ice">{saving ? 'Saving…' : 'Save all'}</Button>
      </div>
      <p className="text-sm text-muted-foreground">
        Edit allocation, vesting, and wallet data. Percentage values must total 100 if all are configured.
        Leave a value null to mark it "Not configured".
      </p>
      <div className="space-y-3">
        {rows.map((r, i) => (
          <Card key={r.category}>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                <span className="capitalize">{r.category}</span>
                {r.percentage == null ? <Badge variant="muted">Not configured</Badge> : <Badge variant="ice">{r.percentage}%</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-3">
                <Field label="Label" value={r.label} onChange={(v) => update(setRows, i, { label: v })} />
                <Field label="Percentage" type="number" value={r.percentage ?? ''} onChange={(v) => update(setRows, i, { percentage: v === '' ? null : Number(v) })} />
                <Field label="Amount (raw)" value={r.amount ?? ''} onChange={(v) => update(setRows, i, { amount: v || null })} />
                <Field label="Cliff (mo)" type="number" value={r.cliffMonths ?? ''} onChange={(v) => update(setRows, i, { cliffMonths: v === '' ? null : Number(v) })} />
                <Field label="Vesting (mo)" type="number" value={r.vestingMonths ?? ''} onChange={(v) => update(setRows, i, { vestingMonths: v === '' ? null : Number(v) })} />
                <Field label="Unlock date" type="date" value={r.unlockDate?.slice(0, 10) ?? ''} onChange={(v) => update(setRows, i, { unlockDate: v ? new Date(v).toISOString() : null })} />
                <div className="md:col-span-2"><Field label="Wallet address" value={r.walletAddress ?? ''} onChange={(v) => update(setRows, i, { walletAddress: v || null })} /></div>
                <Field label="Order" type="number" value={r.order} onChange={(v) => update(setRows, i, { order: Number(v) || 0 })} />
                <div className="md:col-span-3 grid gap-1.5">
                  <Label>Notes</Label>
                  <Textarea value={r.notes ?? ''} onChange={(e) => update(setRows, i, { notes: e.target.value || null })} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function update(setRows: any, i: number, patch: Partial<Allocation>) {
  setRows((prev: Allocation[]) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
}

function Field({ label, value, onChange, type = 'text' }: { label: string; value: any; onChange: (v: string) => void; type?: string }) {
  return (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      <Input value={value as any} type={type} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
