import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { env } from '@/lib/env';
import { EVENTS, EVENT_PROPS, type EventName } from '@/lib/analytics';
import { ExternalLink, Eye, ShieldCheck, Activity } from 'lucide-react';

export const metadata = {
  title: 'Analytics',
  description: 'Privacy-friendly analytics status and event inventory.',
};

const EVENT_DESCRIPTIONS: Record<EventName, string> = {
  [EVENTS.WALLET_CONNECTED]: 'A wallet was connected (via MetaMask, WalletConnect, Coinbase, or Rainbow)',
  [EVENTS.WALLET_DISCONNECTED]: 'A wallet was disconnected',
  [EVENTS.DAILY_PRIZE_PAGE_VIEWED]: 'User viewed the daily prize page',
  [EVENTS.DAILY_PRIZE_SPIN_STARTED]: 'User initiated a spin',
  [EVENTS.DAILY_PRIZE_SPIN_COMPLETED]: 'Spin completed server-side and the result was returned',
  [EVENTS.DAILY_PRIZE_PRIZE_WON]: 'User saw the prize reveal modal',
  [EVENTS.DAILY_PRIZE_MILESTONE]: 'User crossed a streak milestone',
  [EVENTS.DAILY_PRIZE_LEADERBOARD_VIEWED]: 'User viewed the leaderboard',
  [EVENTS.DAILY_PRIZE_DRAWS_VIEWED]: 'User viewed the raffle draws',
  [EVENTS.DONATION_CLICKED]: 'User clicked a donation method link',
  [EVENTS.SPONSORS_PAGE_VIEWED]: 'User viewed the sponsors page',
  [EVENTS.DOCS_VIEWED]: 'User viewed the docs page or a section',
  [EVENTS.TRANSPARENCY_VIEWED]: 'User viewed the transparency page',
  [EVENTS.PRESS_PAGE_VIEWED]: 'User viewed the press kit page',
  [EVENTS.EXTERNAL_LINK_CLICKED]: 'User clicked an outbound link',
  [EVENTS.ADMIN_LOGIN_ATTEMPT]: 'An admin login attempt was made',
  [EVENTS.ADMIN_LOGIN_SUCCESS]: 'An admin login succeeded',
  [EVENTS.ADMIN_LOGIN_FAILED]: 'An admin login failed',
  [EVENTS.ADMIN_TOKEN_METADATA_UPDATED]: 'Admin updated token metadata',
  [EVENTS.ADMIN_RAFFLE_DRAW_TRIGGERED]: 'Admin triggered a raffle draw',
};

export default function AnalyticsAdminPage() {
  const configured = !!env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
  const dashboardUrl = configured ? `https://plausible.io/${env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN}` : null;
  const enabled = env.NEXT_PUBLIC_ANALYTICS_ENABLED !== false;

  return (
    <div className="container py-10 space-y-8 max-w-4xl">
      <header className="space-y-2">
        <h1 className="font-display text-3xl font-bold flex items-center gap-2"><Activity className="h-6 w-6" /> Analytics</h1>
        <p className="text-muted-foreground">Privacy-friendly analytics status and event inventory.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Eye className="h-5 w-5" /> Provider</CardTitle>
          <CardDescription>
            CrystalFlakCoin uses Plausible Analytics — privacy-friendly, cookie-free, GDPR/CCPA compliant.
            No personally identifiable information is ever sent.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3 flex-wrap">
            <Badge variant={configured ? 'success' : 'muted'}>
              {configured ? 'Configured' : 'Not configured'}
            </Badge>
            <Badge variant={enabled ? 'ice' : 'muted'}>
              {enabled ? 'Enabled' : 'Disabled'}
            </Badge>
            {configured && (
              <span className="text-sm text-muted-foreground">
                Domain: <code className="text-sky-300">{env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN}</code>
              </span>
            )}
          </div>
          {dashboardUrl && (
            <a href={dashboardUrl} target="_blank" rel="noopener noreferrer" className="text-sky-300 hover:underline inline-flex items-center gap-1 text-sm">
              Open Plausible dashboard <ExternalLink className="h-3 w-3" />
            </a>
          )}
          {!configured && (
            <p className="text-sm text-muted-foreground">
              To enable, set <code>NEXT_PUBLIC_PLAUSIBLE_DOMAIN</code> in your environment. See <code>ANALYTICS.md</code> for details.
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5" /> Privacy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>Plausible is cookieless and does not collect:</p>
          <ul className="list-disc list-inside text-muted-foreground space-y-1">
            <li>IP addresses (truncated server-side by Plausible)</li>
            <li>Personal data of any kind</li>
            <li>Cross-site identifiers</li>
            <li>Fingerprinting data</li>
          </ul>
          <p className="pt-2">
            No cookie banner is required for GDPR or CCPA compliance. See the <a href="/legal" className="underline">legal page</a> for our full privacy notice.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Event inventory</CardTitle>
          <CardDescription>
            Every event the application can fire. Events are no-ops when Plausible is not configured.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border border-white/10 rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-white/5">
                <tr>
                  <th className="text-left p-3 font-medium">Event</th>
                  <th className="text-left p-3 font-medium">Description</th>
                </tr>
              </thead>
              <tbody>
                {Object.values(EVENTS).map((e) => (
                  <tr key={e} className="border-t border-white/5 hover:bg-white/[0.02]">
                    <td className="p-3 font-mono text-xs text-sky-300">{e}</td>
                    <td className="p-3 text-muted-foreground">{EVENT_DESCRIPTIONS[e as EventName]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Standard props</CardTitle>
          <CardDescription>Categorical properties used across events. No PII.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="text-sm grid sm:grid-cols-2 gap-2">
            {Object.entries(EVENT_PROPS).map(([k, v]) => (
              <li key={k} className="p-2 rounded border border-white/10 bg-white/[0.02]">
                <div className="font-mono text-xs text-sky-300">{v}</div>
                <div className="text-xs text-muted-foreground">{k.replace(/_/g, ' ').toLowerCase()}</div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Disable analytics</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <p>To disable analytics entirely, set:</p>
          <pre className="bg-black/40 p-3 rounded border border-white/10"><code>NEXT_PUBLIC_ANALYTICS_ENABLED=false</code></pre>
          <p className="text-muted-foreground">The Plausible script will not be loaded, and all <code>trackEvent</code> calls will be silent no-ops.</p>
        </CardContent>
      </Card>
    </div>
  );
}
