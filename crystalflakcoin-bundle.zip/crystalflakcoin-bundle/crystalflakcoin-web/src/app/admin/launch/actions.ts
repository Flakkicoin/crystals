/**
 * Admin-side helper: read live contract info for the launch wizard.
 */
import { readTokenState, type TokenState } from '@/lib/token/contract';

export interface LiveContractInfo {
  deployed: boolean;
  renounced?: boolean;
  address?: string;
  totalSupplyFormatted?: string;
  maxSupplyFormatted?: string;
  explorerUrl?: string;
  owner?: string;
}

export async function readContractInfo(): Promise<LiveContractInfo> {
  try {
    const state = await readTokenState();
    if (!state.deployed) return { deployed: false };

    return {
      deployed: true,
      renounced: state.immutable,
      address: state.address,
      totalSupplyFormatted: state.totalSupplyFormatted,
      maxSupplyFormatted: state.maxSupplyFormatted,
      explorerUrl: state.explorerUrl,
      owner: state.owner,
    };
  } catch {
    return { deployed: false };
  }
}
