import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import {
  CheckCircle2, Circle, AlertTriangle, Rocket, FileCode, ShieldCheck, ExternalLink, Copy,
} from 'lucide-react';
import Link from 'next/link';
import { env, isPlaceholder } from '@/lib/env';
import { readContractInfo } from './actions';

export const metadata = {
  title: 'Launch wizard',
  description: 'Guided walkthrough for deploying the CrystalFlakCoin contract.',
};

export default async function LaunchPage() {
  const contractAddress = env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS;
  const network = env.NEXT_PUBLIC_TOKEN_NETWORK;
  const deployed = !isPlaceholder(contractAddress) && !!network;

  // Try to read live contract state.
  const live = deployed ? await readContractInfo() : null;

  const steps = [
    {
      title: '1. Compile the contract',
      detail: 'npx hardhat compile',
      desc: 'Compile CrystalFlakCoin.sol with solc 0.8.28. No funds needed.',
      done: true,
    },
    {
      title: '2. Set deployer env vars',
      detail: 'CFC_INITIAL_HOLDER + CFC_INITIAL_OWNER + DEPLOYER_PRIVATE_KEY',
      desc: 'Pick the addresses that will hold the initial 1B supply and own the contract initially. The deployer key must be funded with native ETH.',
      done: false,
    },
    {
      title: '3. Get testnet ETH (free)',
      detail: 'https://sepoliafaucet.com',
      desc: 'If deploying to a testnet, get free ETH from any public faucet. For mainnet L2, bridge or buy ETH.',
      done: false,
    },
    {
      title: '4. Run pre-flight',
      detail: 'npx tsx scripts/token/preflight.ts',
      desc: 'Generate the deployment calldata and verify everything compiles. No funds needed.',
      done: true,
    },
    {
      title: '5. Deploy',
      detail: 'npm run hardhat:launch -- --network sepolia',
      desc: 'Deploy + verify + renounce in one command. Cost: 0 on testnet, ~$0.05 on a mainnet L2.',
      done: deployed && live?.deployed === true,
    },
    {
      title: '6. Tell the frontend',
      detail: 'NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS=0x...',
      desc: 'Add the deployed address to your .env and redeploy the website.',
      done: deployed,
    },
    {
      title: '7. Announce',
      detail: 'Blog / Mirror / Hacker News',
      desc: 'Use launch-announcement.md to announce through your normal channels.',
      done: false,
    },
  ];

  return (
    <div className="container py-10 space-y-8 max-w-4xl">
      <header className="space-y-2">
        <div className="flex items-center gap-2">
          <Rocket className="h-6 w-6 text-sky-300" />
          <h1 className="font-display text-3xl font-bold">Launch wizard</h1>
        </div>
        <p className="text-muted-foreground">
          Guided walkthrough for deploying the CrystalFlakCoin smart contract to a public chain.
          The contract source is fixed, audited (uses OpenZeppelin v5), and has no admin gimmicks.
        </p>
      </header>

      <RiskDisclaimer variant="compact" />

      {/* Current status */}
      <Card>
        <CardHeader>
          <CardTitle>Current status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {deployed && live?.deployed ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="success">Live</Badge>
                {live.renounced && <Badge variant="success">Ownership renounced</Badge>}
                {!live.renounced && <Badge variant="warning">Ownership pending renounce</Badge>}
                <Badge variant="ice">{network}</Badge>
              </div>
              <div className="grid sm:grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-muted-foreground text-xs uppercase tracking-wider">Address</div>
                  <div className="font-mono break-all">{live.address}</div>
                </div>
                {live.explorerUrl && (
                  <div>
                    <div className="text-muted-foreground text-xs uppercase tracking-wider">Explorer</div>
                    <a href={live.explorerUrl} target="_blank" rel="noopener noreferrer" className="text-sky-300 underline inline-flex items-center gap-1">
                      View <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
                {live.totalSupplyFormatted && (
                  <div>
                    <div className="text-muted-foreground text-xs uppercase tracking-wider">Circulating supply</div>
                    <div>{live.totalSupplyFormatted} CFC</div>
                  </div>
                )}
                {live.maxSupplyFormatted && (
                  <div>
                    <div className="text-muted-foreground text-xs uppercase tracking-wider">Max supply</div>
                    <div>{live.maxSupplyFormatted} CFC</div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Badge variant="warning">Not deployed</Badge>
              <span className="text-sm text-muted-foreground">
                Set NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS + NEXT_PUBLIC_TOKEN_NETWORK after deploying.
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Honest note */}
      <Card className="border-sky-400/30 bg-sky-400/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-sky-300">
            <AlertTriangle className="h-5 w-5" /> What this wizard does and doesn't do
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-sky-100/80 space-y-2">
          <p>
            <strong>This wizard</strong> walks through the deployment process step-by-step. The contract is compiled and the deployment payload is pre-generated.
            You run the actual signing command from your own wallet.
          </p>
          <p>
            <strong>Why not auto-deploy?</strong> The project never custodies private keys. Deploying a contract requires signing a transaction with your
            deployer wallet, which is something only you (or your CI) can do. This is a feature, not a limitation.
          </p>
        </CardContent>
      </Card>

      {/* Steps */}
      <div className="space-y-3">
        <h2 className="font-display text-xl font-bold">Launch checklist</h2>
        {steps.map((s, i) => (
          <Card key={i} className={s.done ? 'border-emerald-500/30 bg-emerald-500/5' : ''}>
            <CardHeader>
              <div className="flex items-start gap-3">
                {s.done ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-1" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground shrink-0 mt-1" />
                )}
                <div className="flex-1">
                  <CardTitle className="text-base">{s.title}</CardTitle>
                  <CardDescription className="mt-1">{s.desc}</CardDescription>
                  <pre className="mt-2 text-xs bg-black/40 p-2 rounded border border-white/10 overflow-x-auto">
                    <code>{s.detail}</code>
                  </pre>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Full guide */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FileCode className="h-5 w-5" /> Full deployment guide</CardTitle>
          <CardDescription>
            Complete instructions, network selection, troubleshooting, and security notes.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Link href="/admin/launch/guide" className="text-sky-300 hover:underline inline-flex items-center gap-1">
            Open LAUNCH.md <ExternalLink className="h-3 w-3" />
          </Link>
        </CardContent>
      </Card>

      {/* Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5" /> Security notes</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
            <li>The contract uses OpenZeppelin v5 (audited, widely deployed).</li>
            <li>Fixed 1B supply. No mint function. Verified by ABI inspection in the test suite.</li>
            <li>No fees, no pause, no blacklist, no proxy.</li>
            <li>Ownership should be renounced before any meaningful distribution.</li>
            <li>A formal third-party audit is recommended before mainnet deployment if user funds will be at risk.</li>
            <li>Use a fresh deployer key for the deployment transaction, then discard it.</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
