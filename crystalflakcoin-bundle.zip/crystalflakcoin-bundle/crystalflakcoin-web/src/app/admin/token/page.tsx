'use client';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface TokenRow {
  id: string;
  name: string;
  symbol: string;
  decimals: number;
  network: string | null;
  chainId: number | null;
  contractAddress: string | null;
  isDeployed: boolean;
  description: string | null;
}

export default function AdminTokenPage() {
  const [row, setRow] = useState<TokenRow | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    fetch('/api/admin/token', { credentials: 'include' })
      .then((r) => r.json())
      .then((j) => setRow(j.row))
      .catch((e) => setMsg({ type: 'err', text: String(e) }));
  }, []);

  if (!row) return <div className="text-sm text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold">Token metadata</h1>
        {row.isDeployed ? <Badge variant="success">Deployed</Badge> : <Badge variant="warning">Not deployed</Badge>}
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Edit metadata</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setSaving(true);
              setMsg(null);
              const fd = new FormData(e.currentTarget);
              const raw = Object.fromEntries(fd.entries()) as Record<string, string>;
              const body: Record<string, unknown> = {
                name: raw.name || undefined,
                symbol: raw.symbol || undefined,
                network: raw.network || undefined,
                contractAddress: raw.contractAddress || undefined,
                description: raw.description || undefined,
                decimals: raw.decimals ? Number(raw.decimals) : undefined,
                chainId: raw.chainId ? Number(raw.chainId) : undefined,
                isDeployed: raw.isDeployed === 'on',
              };
              const r = await fetch('/api/admin/token', {
                method: 'PUT',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
              });
              setSaving(false);
              if (r.ok) {
                const j = await r.json();
                setRow(j.row);
                setMsg({ type: 'ok', text: 'Saved.' });
              } else {
                const j = await r.json().catch(() => ({}));
                setMsg({ type: 'err', text: j.error || 'Save failed' });
              }
            }}
            className="grid md:grid-cols-2 gap-3"
          >
            <Field label="Name" name="name" defaultValue={row.name} />
            <Field label="Symbol" name="symbol" defaultValue={row.symbol} />
            <Field label="Decimals" name="decimals" type="number" defaultValue={row.decimals} />
            <Field label="Network" name="network" defaultValue={row.network ?? ''} placeholder="Ethereum Mainnet" />
            <Field label="Chain ID" name="chainId" type="number" defaultValue={row.chainId ?? ''} />
            <div className="md:col-span-2"><Field label="Contract address" name="contractAddress" defaultValue={row.contractAddress ?? ''} placeholder="0x…" /></div>
            <div className="md:col-span-2 flex items-center gap-2">
              <input id="isDeployed" name="isDeployed" type="checkbox" defaultChecked={row.isDeployed} className="h-4 w-4" />
              <Label htmlFor="isDeployed">Mark as deployed (only after contract is published & verified)</Label>
            </div>
            <div className="md:col-span-2 grid gap-2">
              <Label htmlFor="description">Description</Label>
              <textarea id="description" name="description" defaultValue={row.description ?? ''} className="min-h-[80px] rounded-md border border-input bg-background px-3 py-2 text-sm" />
            </div>
            {msg?.text && (
              <div className="md:col-span-2">
                <Alert variant={msg.type === 'err' ? 'destructive' : 'default'}>
                  <AlertTitle>{msg.type === 'err' ? 'Error' : 'Saved'}</AlertTitle>
                  <AlertDescription>{msg.text}</AlertDescription>
                </Alert>
              </div>
            )}
            <div className="md:col-span-2">
              <Button type="submit" variant="ice" disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function Field({ label, name, type = 'text', defaultValue, placeholder }: { label: string; name: string; type?: string; defaultValue?: any; placeholder?: string }) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} defaultValue={defaultValue as any} placeholder={placeholder} />
    </div>
  );
}
