'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Plus, Save, Trash2, RefreshCw, AlertTriangle, Check, Trophy, Play, FlaskConical } from 'lucide-react';

interface PrizeRow {
  id: string;
  code: string;
  label: string;
  description: string;
  category: 'points' | 'raffle' | 'badge' | 'streak_freeze' | 'none';
  weight: number;
  color: string;
  points: number | null;
  raffles: number | null;
  freezesStreak: boolean;
  disclosure: string;
  isActive: boolean;
  order: number;
}

interface Stats {
  totalSpins: number;
  spinsLast30d: number;
  uniqueWallets: number;
  totalPointsAwarded: number;
  totalRafflesAwarded: number;
  prizeDistribution: { code: string; count: number }[];
  recentSpins: { id: string; wallet: string; date: string; prize: string; streak: number; bonus: string | null; seed: string; createdAt: string }[];
}

interface TierRow {
  id: string;
  code: string;
  label: string;
  description: string;
  disclosure: string;
  numWinners: number;
  isActive: boolean;
  order: number;
}

interface DrawRow {
  id: string;
  period: string;
  drawnAt: string;
  totalEntries: number;
  totalUniqueWallets: number;
  serverSeed: string;
  resultJson: string;
}

const CATEGORY_OPTIONS = [
  { value: 'points', label: 'Points' },
  { value: 'raffle', label: 'Raffle' },
  { value: 'badge', label: 'Badge' },
  { value: 'streak_freeze', label: 'Streak freeze' },
  { value: 'none', label: 'None' },
];

export default function AdminDailyPrizePage() {
  const [prizes, setPrizes] = useState<PrizeRow[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [totalWeight, setTotalWeight] = useState(0);
  const [saving, setSaving] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [randomness, setRandomness] = useState<{ config: any; available: { id: string; label: string; description: string; enabled: boolean }[] } | null>(null);
  const [tiers, setTiers] = useState<TierRow[]>([]);
  const [draws, setDraws] = useState<DrawRow[]>([]);
  const [entriesByPeriod, setEntriesByPeriod] = useState<Record<string, number>>({});
  const [drawPeriod, setDrawPeriod] = useState<string>('');

  useEffect(() => { load(); loadRandomness(); loadRaffle(); }, []);

  async function load() {
    const [c, s] = await Promise.all([
      fetch('/api/admin/daily-prize/catalog', { credentials: 'include' }).then((r) => r.json()),
      fetch('/api/admin/daily-prize/stats', { credentials: 'include' }).then((r) => r.json()),
    ]);
    setPrizes(c.items || []);
    setTotalWeight(c.totalWeight || 0);
    setStats(s);
  }

  async function loadRandomness() {
    const r = await fetch('/api/admin/daily-prize/randomness', { credentials: 'include' });
    if (r.ok) setRandomness(await r.json());
  }

  async function loadRaffle() {
    const [t, d] = await Promise.all([
      fetch('/api/admin/daily-prize/raffle/tiers', { credentials: 'include' }).then((r) => r.json()),
      fetch('/api/admin/daily-prize/raffle/draw', { credentials: 'include' }).then((r) => r.json()),
    ]);
    setTiers(t.tiers || []);
    setDraws(d.draws || []);
    setEntriesByPeriod(d.entriesByPeriod || {});
  }

  async function save(p: PrizeRow) {
    setSaving(p.code);
    setMsg(null);
    const r = await fetch('/api/admin/daily-prize/catalog', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(p),
    });
    setSaving(null);
    if (r.ok) { setMsg({ type: 'ok', text: `Saved ${p.code}.` }); await load(); }
    else { const j = await r.json().catch(() => ({})); setMsg({ type: 'err', text: j.error || 'Save failed' }); }
  }

  async function deactivate(p: PrizeRow) {
    if (!confirm(`Deactivate prize ${p.code}?`)) return;
    const r = await fetch(`/api/admin/daily-prize/catalog/${p.code}`, { method: 'DELETE', credentials: 'include' });
    if (r.ok) { setMsg({ type: 'ok', text: `Deactivated ${p.code}.` }); await load(); }
  }

  async function setRandomnessSource(sourceId: string) {
    if (!confirm(`Switch active randomness source to "${sourceId}"?`)) return;
    const r = await fetch('/api/admin/daily-prize/randomness', {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source: sourceId }),
    });
    if (r.ok) { setMsg({ type: 'ok', text: `Randomness source updated.` }); await loadRandomness(); }
    else { const j = await r.json().catch(() => ({})); setMsg({ type: 'err', text: j.error || 'Update failed' }); }
  }

  async function saveTier(t: TierRow) {
    setSaving(t.code);
    setMsg(null);
    const r = await fetch('/api/admin/daily-prize/raffle/tiers', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(t),
    });
    setSaving(null);
    if (r.ok) { setMsg({ type: 'ok', text: `Saved tier ${t.code}.` }); await loadRaffle(); }
    else { const j = await r.json().catch(() => ({})); setMsg({ type: 'err', text: j.error || 'Save failed' }); }
  }

  async function runDraw(dryRun: boolean) {
    if (!drawPeriod) {
      setMsg({ type: 'err', text: 'Enter a period (e.g. 2026-Q1).' });
      return;
    }
    if (!dryRun && !confirm(`Run a real draw for ${drawPeriod}? This is irreversible.`)) return;
    const r = await fetch('/api/admin/daily-prize/raffle/draw', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ period: drawPeriod, dryRun }),
    });
    const j = await r.json();
    if (r.ok) {
      if (dryRun) {
        setMsg({ type: 'ok', text: `Dry-run complete: ${j.result.totalEntries} entries, ${j.result.totalUniqueWallets} unique wallets. Winners: ${JSON.stringify(j.result.winnersByTier)}` });
      } else {
        setMsg({ type: 'ok', text: `Draw complete for ${drawPeriod}. ${j.result.totalEntries} entries, ${j.result.totalUniqueWallets} unique wallets.` });
        await loadRaffle();
      }
    } else {
      setMsg({ type: 'err', text: j.error || 'Draw failed' });
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="font-display text-2xl font-bold">Daily Prize — admin</h1>
        <Button onClick={() => { load(); loadRandomness(); loadRaffle(); }} size="sm" variant="ghost"><RefreshCw className="h-4 w-4 mr-1" /> Refresh</Button>
      </div>

      {msg && (
        <Alert variant={msg.type === 'err' ? 'destructive' : 'default'}>
          {msg.type === 'err' ? <AlertTriangle className="h-4 w-4" /> : <Check className="h-4 w-4" />}
          <AlertTitle>{msg.type === 'err' ? 'Error' : 'Done'}</AlertTitle>
          <AlertDescription className="whitespace-pre-wrap break-words max-h-32 overflow-y-auto">{msg.text}</AlertDescription>
        </Alert>
      )}

      {stats && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <Stat label="Total spins" value={stats.totalSpins} />
          <Stat label="Last 30 days" value={stats.spinsLast30d} />
          <Stat label="Unique wallets" value={stats.uniqueWallets} />
          <Stat label="Total points" value={stats.totalPointsAwarded} />
          <Stat label="Total raffles" value={stats.totalRafflesAwarded} />
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Prize catalogue</CardTitle>
              <CardDescription>
                Edit weights, labels, and disclosures. Weights are basis points (1 = 0.01%). Total weight: <strong>{totalWeight.toLocaleString()}</strong>.
              </CardDescription>
            </div>
            <Button onClick={() => setNewOpen(!newOpen)} variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-1" /> Add prize
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {newOpen && (
            <NewPrizeForm
              onSave={async (p) => { await save(p); setNewOpen(false); }}
              onCancel={() => setNewOpen(false)}
            />
          )}
          {prizes.length === 0 && <p className="text-sm text-muted-foreground">No prizes configured. The spin endpoint will fall back to the in-code defaults.</p>}
          {prizes.map((p) => (
            <PrizeEditor
              key={p.id}
              prize={p}
              oddsPct={totalWeight > 0 ? (p.weight / totalWeight * 100).toFixed(2) : '0.00'}
              saving={saving === p.code}
              onSave={save}
              onDeactivate={deactivate}
              onChange={(patch) => setPrizes((prev) => prev.map((x) => x.id === p.id ? { ...x, ...patch } : x))}
            />
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2"><Trophy className="h-5 w-5 text-amber-400" /> Raffle draw system</CardTitle>
              <CardDescription>Configure raffle tiers and trigger periodic draws. All draws are reproducible from the published server seed.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="text-sm font-medium mb-2">Tiers</h4>
            <div className="space-y-3">
              {tiers.length === 0 && <p className="text-xs text-muted-foreground">No tiers configured.</p>}
              {tiers.map((t) => (
                <TierEditor
                  key={t.id}
                  tier={t}
                  saving={saving === t.code}
                  onSave={saveTier}
                  onChange={(patch) => setTiers((prev) => prev.map((x) => x.id === t.id ? { ...x, ...patch } : x))}
                />
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-white/5 space-y-2">
            <h4 className="text-sm font-medium">Run a draw</h4>
            <div className="flex flex-wrap items-end gap-2">
              <div className="grid gap-1.5">
                <Label htmlFor="drawPeriod">Period</Label>
                <Input id="drawPeriod" value={drawPeriod} onChange={(e) => setDrawPeriod(e.target.value)} placeholder="2026-Q1" className="w-40" />
              </div>
              <div className="text-xs text-muted-foreground self-center">
                Entries in period: <strong>{entriesByPeriod[drawPeriod] ?? 0}</strong>
              </div>
              <Button onClick={() => runDraw(true)} variant="outline" size="sm"><FlaskConical className="h-4 w-4 mr-1" /> Dry-run</Button>
              <Button onClick={() => runDraw(false)} variant="ice" size="sm" disabled={(entriesByPeriod[drawPeriod] ?? 0) === 0}><Play className="h-4 w-4 mr-1" /> Run real draw</Button>
            </div>
            <p className="text-xs text-muted-foreground">Draws are irreversible. A real draw is persisted, individual winners are recorded, and the result becomes public.</p>
          </div>

          {draws.length > 0 && (
            <div className="pt-3 border-t border-white/5">
              <h4 className="text-sm font-medium mb-2">Past draws</h4>
              <ul className="space-y-1 text-sm">
                {draws.map((d) => (
                  <li key={d.id} className="flex items-center justify-between border-b border-white/5 py-1.5">
                    <span className="font-mono text-xs">{d.period}</span>
                    <span className="text-xs">{new Date(d.drawnAt).toLocaleString()}</span>
                    <span className="text-xs">{d.totalEntries} entries</span>
                    <code className="text-[10px] text-muted-foreground">{d.serverSeed.slice(0, 8)}…{d.serverSeed.slice(-4)}</code>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {randomness && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Randomness source</CardTitle>
            <CardDescription>Active: <Badge variant="ice">{randomness.config?.source || 'server'}</Badge></CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {randomness.available.map((s) => (
              <div key={s.id} className="p-3 rounded-md border border-white/10 flex items-center justify-between gap-3">
                <div>
                  <div className="font-medium text-sm">{s.label} <Badge variant={s.enabled ? 'success' : 'muted'} className="ml-2">{s.enabled ? 'Ready' : 'Stub'}</Badge></div>
                  <p className="text-xs text-muted-foreground mt-1">{s.description}</p>
                </div>
                {s.enabled && randomness.config?.source !== s.id && (
                  <Button size="sm" variant="outline" onClick={() => setRandomnessSource(s.id)}>Activate</Button>
                )}
                {randomness.config?.source === s.id && <Badge variant="success">Active</Badge>}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {stats && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent spins</CardTitle>
            <CardDescription>Most recent 25 spins. Server seeds are included so admins can verify outcomes.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left border-b border-white/10">
                    <th className="py-2 pr-2">When</th>
                    <th className="py-2 pr-2">Wallet</th>
                    <th className="py-2 pr-2">Prize</th>
                    <th className="py-2 pr-2">Streak</th>
                    <th className="py-2 pr-2">Bonus</th>
                    <th className="py-2 pr-2">Seed</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recentSpins.map((r) => (
                    <tr key={r.id} className="border-b border-white/5">
                      <td className="py-2 pr-2 text-muted-foreground">{new Date(r.createdAt).toISOString().slice(0, 19).replace('T', ' ')}</td>
                      <td className="py-2 pr-2 font-mono">{r.wallet.slice(0, 6)}…{r.wallet.slice(-4)}</td>
                      <td className="py-2 pr-2"><Badge variant="muted">{r.prize}</Badge></td>
                      <td className="py-2 pr-2">{r.streak}</td>
                      <td className="py-2 pr-2">{r.bonus || '—'}</td>
                      <td className="py-2 pr-2 font-mono text-muted-foreground">{r.seed.slice(0, 8)}…{r.seed.slice(-4)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <Card><CardContent className="pt-6">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-2xl font-bold mt-1">{value.toLocaleString()}</div>
    </CardContent></Card>
  );
}

function TierEditor({ tier, saving, onSave, onChange }: { tier: TierRow; saving: boolean; onSave: (t: TierRow) => void; onChange: (p: Partial<TierRow>) => void }) {
  return (
    <div className="p-3 rounded-md border border-white/10 bg-white/[0.02] space-y-2">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <code className="text-xs text-muted-foreground">{tier.code}</code>
          <Badge variant={tier.isActive ? 'success' : 'muted'}>{tier.isActive ? 'Active' : 'Inactive'}</Badge>
        </div>
        <Button size="sm" variant="ice" onClick={() => onSave(tier)} disabled={saving}>
          <Save className="h-4 w-4 mr-1" /> {saving ? 'Saving…' : 'Save'}
        </Button>
      </div>
      <div className="grid md:grid-cols-3 gap-2">
        <Field label="Label" value={tier.label} onChange={(v) => onChange({ label: v })} />
        <Field label="Winners" type="number" value={tier.numWinners} onChange={(v) => onChange({ numWinners: Number(v) })} />
        <Field label="Order" type="number" value={tier.order} onChange={(v) => onChange({ order: Number(v) })} />
        <div className="md:col-span-3"><Field label="Description" value={tier.description} onChange={(v) => onChange({ description: v })} /></div>
        <div className="md:col-span-3"><Field label="Disclosure" value={tier.disclosure} onChange={(v) => onChange({ disclosure: v })} /></div>
        <div className="md:col-span-3 flex items-center gap-2">
          <input id={`active-${tier.id}`} type="checkbox" checked={tier.isActive} onChange={(e) => onChange({ isActive: e.target.checked })} className="h-4 w-4" />
          <Label htmlFor={`active-${tier.id}`}>Active</Label>
        </div>
      </div>
    </div>
  );
}

function PrizeEditor({
  prize, oddsPct, saving, onSave, onDeactivate, onChange,
}: {
  prize: PrizeRow;
  oddsPct: string;
  saving: boolean;
  onSave: (p: PrizeRow) => void;
  onDeactivate: (p: PrizeRow) => void;
  onChange: (patch: Partial<PrizeRow>) => void;
}) {
  return (
    <div className="p-4 rounded-md border border-white/10 bg-white/[0.02] space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <code className="text-xs text-muted-foreground">{prize.code}</code>
          <Badge variant={prize.isActive ? 'success' : 'muted'}>{prize.isActive ? 'Active' : 'Inactive'}</Badge>
          <Badge variant="ice">{oddsPct}%</Badge>
        </div>
        <div className="flex gap-2">
          {prize.isActive && (
            <Button size="sm" variant="ghost" onClick={() => onDeactivate(prize)}>
              <Trash2 className="h-4 w-4 mr-1" /> Deactivate
            </Button>
          )}
          <Button size="sm" variant="ice" onClick={() => onSave(prize)} disabled={saving}>
            <Save className="h-4 w-4 mr-1" /> {saving ? 'Saving…' : 'Save'}
          </Button>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        <Field label="Label" value={prize.label} onChange={(v) => onChange({ label: v })} />
        <Field label="Color (Tailwind gradient pair)" value={prize.color} onChange={(v) => onChange({ color: v })} />
        <Field label="Weight (basis points)" type="number" value={prize.weight} onChange={(v) => onChange({ weight: Number(v) })} />
        <div className="grid gap-1.5">
          <Label>Category</Label>
          <select
            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
            value={prize.category}
            onChange={(e) => onChange({ category: e.target.value as any })}
          >
            {CATEGORY_OPTIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>
        <Field label="Points" type="number" value={prize.points ?? 0} onChange={(v) => onChange({ points: v === '' ? null : Number(v) })} />
        <Field label="Raffles" type="number" value={prize.raffles ?? 0} onChange={(v) => onChange({ raffles: v === '' ? null : Number(v) })} />
        <Field label="Order" type="number" value={prize.order} onChange={(v) => onChange({ order: Number(v) })} />
        <div className="grid gap-1.5">
          <Label>Freezes streak?</Label>
          <div className="h-10 flex items-center">
            <input
              type="checkbox"
              checked={prize.freezesStreak}
              onChange={(e) => onChange({ freezesStreak: e.target.checked })}
              className="h-4 w-4"
            />
          </div>
        </div>
        <div className="md:col-span-2 grid gap-1.5">
          <Label>Description</Label>
          <Textarea value={prize.description} onChange={(e) => onChange({ description: e.target.value })} />
        </div>
        <div className="md:col-span-2 grid gap-1.5">
          <Label>Disclosure (shown to user)</Label>
          <Textarea value={prize.disclosure} onChange={(e) => onChange({ disclosure: e.target.value })} />
        </div>
      </div>
    </div>
  );
}

function NewPrizeForm({ onSave, onCancel }: { onSave: (p: PrizeRow) => void; onCancel: () => void }) {
  const [draft, setDraft] = useState<PrizeRow>({
    id: '',
    code: 'NEW_PRIZE',
    label: 'New prize',
    description: 'Describe what the prize is.',
    category: 'points',
    weight: 100,
    color: 'from-violet-700/40 to-violet-500/20',
    points: 10,
    raffles: 0,
    freezesStreak: false,
    disclosure: 'Non-monetary.',
    isActive: true,
    order: 99,
  });
  return (
    <div className="p-4 rounded-md border border-sky-500/30 bg-sky-500/5 space-y-3">
      <p className="text-sm font-medium">New prize</p>
      <div className="grid md:grid-cols-2 gap-3">
        <Field label="Code (UPPER_SNAKE)" value={draft.code} onChange={(v) => setDraft({ ...draft, code: v.toUpperCase().replace(/[^A-Z0-9_]/g, '_') })} />
        <Field label="Label" value={draft.label} onChange={(v) => setDraft({ ...draft, label: v })} />
        <Field label="Weight (basis points)" type="number" value={draft.weight} onChange={(v) => setDraft({ ...draft, weight: Number(v) })} />
        <Field label="Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: Number(v) })} />
        <div className="md:col-span-2"><Field label="Description" value={draft.description} onChange={(v) => setDraft({ ...draft, description: v })} /></div>
        <div className="md:col-span-2"><Field label="Disclosure" value={draft.disclosure} onChange={(v) => setDraft({ ...draft, disclosure: v })} /></div>
      </div>
      <div className="flex gap-2 justify-end">
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button variant="ice" onClick={() => onSave(draft)}><Save className="h-4 w-4 mr-1" /> Create</Button>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = 'text' }: { label: string; value: any; onChange: (v: string) => void; type?: string }) {
  return (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      <Input value={value as any} type={type} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
