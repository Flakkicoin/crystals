import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import Link from 'next/link';
import { ReactNode } from 'react';
import { LayoutDashboard, Coins, FileText, Megaphone, Network, ShieldAlert, ScrollText, Sparkles, Activity, Rocket } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  if (!session.isLoggedIn) redirect('/admin/login');
  if (session.role !== 'ADMIN') {
    return (
      <div className="container py-20 text-center">
        <h1 className="text-2xl font-bold mb-2">Insufficient permissions</h1>
        <p className="text-muted-foreground">You do not have access to the admin panel.</p>
      </div>
    );
  }

  const navItems = [
    { href: '/admin', label: 'Overview', icon: LayoutDashboard },
    { href: '/admin/token', label: 'Token', icon: Coins },
    { href: '/admin/tokenomics', label: 'Tokenomics', icon: FileText },
    { href: '/admin/daily-prize', label: 'Daily Prize', icon: Sparkles },
    { href: '/admin/content', label: 'Content', icon: ScrollText },
    { href: '/admin/announcements', label: 'Announcements', icon: Megaphone },
    { href: '/admin/networks', label: 'Networks', icon: Network },
    { href: '/admin/security', label: 'Security reports', icon: ShieldAlert },
    { href: '/admin/logs', label: 'Audit logs', icon: ScrollText },
    { href: '/admin/analytics', label: 'Analytics', icon: Activity },
    { href: '/admin/launch', label: 'Launch', icon: Rocket },
  ];

  return (
    <div className="container py-10 grid lg:grid-cols-[220px_1fr] gap-8">
      <aside className="space-y-1">
        <div className="mb-4 p-3 rounded-md border border-white/10 bg-white/[0.02]">
          <div className="text-xs text-muted-foreground">Signed in as</div>
          <div className="text-sm font-medium truncate">{session.email}</div>
          <Badge variant="ice" className="mt-2">{session.role}</Badge>
        </div>
        <nav className="grid gap-1">
          {navItems.map((it) => (
            <Link key={it.href} href={it.href} className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-white/5 text-muted-foreground hover:text-foreground">
              <it.icon className="h-4 w-4" /> {it.label}
            </Link>
          ))}
        </nav>
      </aside>
      <section className="min-w-0">{children}</section>
    </div>
  );
}
