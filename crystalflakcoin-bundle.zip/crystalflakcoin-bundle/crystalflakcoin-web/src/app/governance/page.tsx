import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { prisma } from '@/lib/prisma';
import { env, isPlaceholder } from '@/lib/env';

export const metadata = { title: 'Governance' };
export const dynamic = 'force-dynamic';

export default async function GovernancePage() {
  const enabled = env.NEXT_PUBLIC_ENABLE_GOVERNANCE && !isPlaceholder(env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS);
  const proposals = enabled ? await prisma.governanceProposal.findMany({ orderBy: { createdAt: 'desc' } }) : [];

  return (
    <div className="container py-16 space-y-8 max-w-4xl">
      <header className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-3xl md:text-5xl font-bold">Governance</h1>
          {enabled ? <Badge variant="success">Available</Badge> : <Badge variant="warning">Not available</Badge>}
        </div>
        <p className="text-muted-foreground">
          Proposals and on-chain voting. CrystalFlakCoin does not simulate or fabricate vote
          results. Any tally shown here is fetched from the verified governance contract.
        </p>
      </header>

      {!enabled ? (
        <Card>
          <CardHeader>
            <CardTitle>Governance is not yet available</CardTitle>
            <CardDescription>
              The governance contract has not been deployed. This page will become active after
              the contract is published and a verification process is complete.
            </CardDescription>
          </CardHeader>
        </Card>
      ) : proposals.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No active proposals</CardTitle>
            <CardDescription>No on-chain proposals have been created yet.</CardDescription>
          </CardHeader>
        </Card>
      ) : (
        <div className="space-y-3">
          {proposals.map((p) => (
            <Card key={p.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{p.title}</CardTitle>
                  <Badge variant={p.status === 'active' ? 'ice' : 'muted'}>{p.status}</Badge>
                </div>
                <CardDescription>External ID: {p.externalId ?? '—'}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-3">{p.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>How voting works</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>Voting is only ever possible through a signed message or transaction in your own wallet. CrystalFlakCoin never votes on your behalf.</p>
          <p>Eligibility is determined by the on-chain contract at the snapshot block. Quorum and voting periods are part of the contract and cannot be changed by the website.</p>
        </CardContent>
      </Card>
    </div>
  );
}
