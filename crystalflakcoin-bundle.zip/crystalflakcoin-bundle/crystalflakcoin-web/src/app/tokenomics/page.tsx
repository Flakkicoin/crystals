import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { prisma } from '@/lib/prisma';

export const metadata = { title: 'Tokenomics' };
export const dynamic = 'force-dynamic';

export default async function TokenomicsPage() {
  // Pull editable allocations from DB; default categories if not yet configured.
  const categories = ['community', 'ecosystem', 'treasury', 'liquidity', 'development'];
  const allocations = await prisma.tokenomicsAllocation.findMany({ orderBy: { order: 'asc' } });
  const byCategory = new Map(allocations.map((a) => [a.category, a]));

  return (
    <div className="container py-16 space-y-10 max-w-5xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Tokenomics</h1>
        <p className="text-muted-foreground">
          Token allocation and vesting. All values are editable through the admin panel and must
          be approved by governance before changes take effect. Do not interpret allocations as
          return projections.
        </p>
      </header>

      <RiskDisclaimer variant="banner" context="Allocation percentages do not imply any future value, yield, or guarantee." />

      <Card>
        <CardHeader>
          <CardTitle>Allocation</CardTitle>
          <CardDescription>Categories and percentages. Items marked "Not configured" have not been finalized.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-3">
            {categories.map((cat) => {
              const row = byCategory.get(cat);
              const pct = row?.percentage;
              return (
                <div key={cat} className="p-4 rounded-md border border-white/10 bg-white/[0.02] flex items-center justify-between gap-4">
                  <div>
                    <div className="font-medium capitalize">{cat}</div>
                    {row?.notes ? <div className="text-xs text-muted-foreground mt-1">{row.notes}</div> : null}
                  </div>
                  <div className="text-right">
                    {pct == null ? <Badge variant="muted">Not configured</Badge> : (
                      <>
                        <div className="font-display text-2xl font-bold crystal-text">{pct}%</div>
                        {row && row.vestingMonths ? <div className="text-xs text-muted-foreground">{row.vestingMonths}-mo vest</div> : null}
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Vesting & wallet addresses</CardTitle>
          <CardDescription>Per-allocation cliff, vesting schedule, and receiving wallet. Not configured values are clearly labeled.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b border-white/10">
                  <th className="py-2 pr-4">Category</th>
                  <th className="py-2 pr-4">Cliff (mo)</th>
                  <th className="py-2 pr-4">Vesting (mo)</th>
                  <th className="py-2 pr-4">Wallet</th>
                  <th className="py-2 pr-4">Unlock date</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((cat) => {
                  const row = byCategory.get(cat);
                  return (
                    <tr key={cat} className="border-b border-white/5">
                      <td className="py-2 pr-4 capitalize">{cat}</td>
                      <td className="py-2 pr-4">{row?.cliffMonths ?? '—'}</td>
                      <td className="py-2 pr-4">{row?.vestingMonths ?? '—'}</td>
                      <td className="py-2 pr-4 font-mono text-xs text-muted-foreground">{row?.walletAddress ?? 'Not configured'}</td>
                      <td className="py-2 pr-4">{row?.unlockDate ? row.unlockDate.toISOString().slice(0, 10) : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        Tokenomics values are not financial projections. Past performance, market conditions, and
        on-chain behavior do not guarantee future outcomes. Always verify the latest figures
        through the <a className="underline" href="/transparency">Transparency</a> page.
      </p>
    </div>
  );
}
