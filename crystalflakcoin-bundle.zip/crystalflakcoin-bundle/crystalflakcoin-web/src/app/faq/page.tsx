import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';

export const metadata = { title: 'FAQ' };

const faqs = [
  {
    q: 'Is CrystalFlakCoin an investment?',
    a: 'No. CrystalFlakCoin is a digital asset project. It is not an investment vehicle, securities offering, or financial product. The value of any digital asset is not guaranteed and may go to zero.',
  },
  {
    q: 'Are returns guaranteed?',
    a: 'No. Nothing on this site promises returns, yield, or appreciation. Any rewards, where they exist, come directly from the verified smart contract and are variable.',
  },
  {
    q: 'Is staking available?',
    a: 'Only after a verified staking contract is published. The Staking page will display "Staking is not yet available" until then. When available, all reward data is read from the contract, not invented.',
  },
  {
    q: 'Is there an automated trading bot?',
    a: 'No. CrystalFlakCoin does not provide any trading bot, signal service, or strategy. The project operates no automated trading system of any kind.',
  },
  {
    q: 'Is recruitment rewarded?',
    a: 'No. CrystalFlakCoin has no recruitment, multi-level, affiliate, or referral compensation plan unless explicitly documented and legally reviewed. Any third party claiming otherwise is not affiliated with this project.',
  },
  {
    q: 'How do I verify official links?',
    a: 'Bookmark this site. Cross-check the contract address, GitHub repository, and social handles listed on the Transparency page. Be skeptical of any link sent to you — phishing is the most common attack vector in this space.',
  },
  {
    q: 'What happens if I lose my wallet?',
    a: 'If you lose access to your wallet and your seed phrase, your assets are unrecoverable. CrystalFlakCoin has no ability to restore access. Always back up your seed phrase securely and offline.',
  },
  {
    q: 'Can blockchain transactions be reversed?',
    a: 'No. Once a transaction is confirmed on-chain, it cannot be reversed by anyone, including CrystalFlakCoin contributors. Always verify the recipient, amount, and contract before signing.',
  },
  {
    q: 'What is the daily community spin?',
    a: 'A free, server-enforced engagement mechanic. Connect your wallet (or enter a demo address) to claim one spin per UTC day. Prizes are non-monetary: community points, raffle entries, streak freezes, or supporter badges. They have no cash value until a token contract is deployed and a conversion ratio is announced. All odds are disclosed on the /daily-prize page.',
  },
  {
    q: 'Are the prizes worth money?',
    a: 'Not yet. Until the token contract is deployed, every prize is non-transferable and has no cash value. When a token is published, community points may become convertible to token units at a ratio that is published in advance and approved through governance. Raffle entries are entries into a periodic on-chain draw; the draw, eligibility, and prize pool are published before entries are redeemed.',
  },
  {
    q: 'Is the spin provably fair?',
    a: 'The outcome is determined by a server-issued 32-byte random seed combined with your wallet address and the UTC date. The seed is recorded in the audit log. For higher assurance, a future version of this page will use a commit-reveal scheme or a verifiable on-chain randomness source (e.g. Chainlink VRF). The current implementation is a transparent server RNG with logged seeds.',
  },
  {
    q: 'Is donating the same as buying a token?',
    a: 'No. Donations are voluntary contributions to the project, not purchases of any asset. The project does not sell tokens and there is no token-for-donation swap. Donations are routed through public infrastructure (GitHub Sponsors, Open Collective, or direct crypto) and are tracked as contributions, not sales. Donating does not entitle you to tokens, NFTs, airdrops, governance rights, or any future benefit. See the /donate page and MONETIZATION.md for the full policy.',
  },
  {
    q: 'Will I get anything in return for donating?',
    a: 'No. There is no return of any kind. Donations are voluntary and non-refundable. The project does not allocate tokens, NFTs, airdrops, governance rights, whitelist spots, or any other benefit to donors, sponsors, or supporters. The only thing a donation buys is the continued existence of the project. If you are looking for an investment, this is not one — see /about and /legal.',
  },
  {
    q: 'Can I get a refund on a donation?',
    a: 'No. Donations are voluntary and non-refundable. The project does not sell anything, so there is no refund process. Crypto donations are also subject to the irreversibility of confirmed blockchain transactions: once a transaction is confirmed, no one — including the project — can reverse it. If funds were sent to the wrong address, the project cannot recover them. Please verify the recipient address on the official /donate page and on-chain before sending.',
  },
];

export default function FaqPage() {
  return (
    <div className="container py-16 space-y-8 max-w-3xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Frequently asked questions</h1>
        <p className="text-muted-foreground">Honest answers. We will never claim something we cannot verify.</p>
      </header>

      <RiskDisclaimer variant="banner" />

      <Accordion type="single" collapsible className="w-full">
        {faqs.map((f, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="border-white/10">
            <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
