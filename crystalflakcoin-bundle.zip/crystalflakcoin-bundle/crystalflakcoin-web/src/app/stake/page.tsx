import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { env, isPlaceholder } from '@/lib/env';

export const metadata = { title: 'Staking' };

export default function StakePage() {
  const enabled = env.NEXT_PUBLIC_ENABLE_STAKE && !isPlaceholder(env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS);

  return (
    <div className="container py-16 space-y-8 max-w-3xl">
      <header className="space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-3xl md:text-5xl font-bold">Staking</h1>
          {enabled ? <Badge variant="success">Available</Badge> : <Badge variant="warning">Not available</Badge>}
        </div>
        <p className="text-muted-foreground">
          Staking lets you delegate tokens to a verified contract in exchange for variable,
          on-chain rewards. Rewards depend on protocol parameters and are not guaranteed.
        </p>
      </header>

      <RiskDisclaimer
        variant="banner"
        context="Any reward information is variable and subject to risk. Past reward rates do not predict future rates. APY shown is never guaranteed."
      />

      {!enabled ? (
        <Card>
          <CardHeader>
            <CardTitle>Staking is not yet available.</CardTitle>
            <CardDescription>
              The staking contract has not been deployed and verified. This page will become
              active only after the contract is published and an audit report is available.
            </CardDescription>
          </CardHeader>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Stake your tokens</CardTitle>
            <CardDescription>UI scaffold — values are read from the verified staking contract.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Once a verified staking contract is published, this page will read the current
              reward rate, your staked balance, and any claimable rewards directly from
              on-chain data. No APY is displayed unless it is fetched from the contract at
              request time.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
