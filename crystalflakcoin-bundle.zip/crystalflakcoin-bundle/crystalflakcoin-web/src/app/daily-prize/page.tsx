import { DailyPrizeClient } from '@/components/daily-prize/spin-wheel';

export const metadata = {
  title: 'Daily Prize',
  description: 'A non-monetary community spin for CrystalFlakCoin supporters. Connect your wallet to participate. No deposits, no promises, no cash value.',
};

export default function DailyPrizePage() {
  return <DailyPrizeClient />;
}
