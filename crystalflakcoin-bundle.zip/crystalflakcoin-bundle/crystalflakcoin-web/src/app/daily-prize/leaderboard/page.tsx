'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { Trophy, Flame, Sparkles, Users, Award, Crown, ChevronUp, Clock } from 'lucide-react';
import Link from 'next/link';

interface LeaderboardEntry {
  rank: number;
  address: string;
  fullAddress: string;
  longestStreak: number;
  currentStreak: number;
  totalSpins: number;
  totalPoints: number;
  totalRaffles: number;
  badges: string[];
}

interface LeaderboardPayload {
  sort: string;
  limit: number;
  top: LeaderboardEntry[];
  recent: { address: string; prizeLabel: string; prizeCode: string; streak: number; bonus: string | null; ago: string }[];
  totals: { uniqueWallets: number; totalSpins: number; totalPoints: number; totalRaffles: number };
  note: string;
}

const SORT_OPTIONS = [
  { key: 'streak', label: 'Longest streak', icon: Flame },
  { key: 'raffles', label: 'Raffle entries', icon: Trophy },
  { key: 'points', label: 'Points', icon: Sparkles },
  { key: 'spins', label: 'Spins', icon: Clock },
];

export default function LeaderboardPage() {
  const [data, setData] = useState<LeaderboardPayload | null>(null);
  const [sort, setSort] = useState('streak');
  const [loading, setLoading] = useState(false);

  async function load(s: string) {
    setLoading(true);
    const r = await fetch(`/api/daily-prize/leaderboard?sort=${s}&limit=50`);
    setLoading(false);
    if (r.ok) setData(await r.json());
  }

  useEffect(() => { load(sort); }, [sort]);

  return (
    <div className="container py-12 space-y-8 max-w-5xl">
      <header className="space-y-3 text-center">
        <span className="eyebrow">Community leaderboard</span>
        <h1 className="font-display text-3xl md:text-5xl font-bold mt-3">Top CrystalFlak supporters</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Engagement metrics, not financial rankings. Points and raffle entries are non-monetary.
        </p>
      </header>

      <RiskDisclaimer variant="compact" />

      {data && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Stat label="Unique wallets" value={data.totals.uniqueWallets} icon={Users} />
          <Stat label="Total spins" value={data.totals.totalSpins} icon={Sparkles} />
          <Stat label="Points awarded" value={data.totals.totalPoints} icon={Award} />
          <Stat label="Raffle entries" value={data.totals.totalRaffles} icon={Trophy} />
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-lg">Top supporters</CardTitle>
            <div className="flex gap-2 flex-wrap">
              {SORT_OPTIONS.map((opt) => (
                <Button
                  key={opt.key}
                  size="sm"
                  variant={sort === opt.key ? 'ice' : 'outline'}
                  onClick={() => setSort(opt.key)}
                  disabled={loading}
                >
                  <opt.icon className="h-4 w-4 mr-1" /> {opt.label}
                </Button>
              ))}
            </div>
          </div>
          <CardDescription>Refreshes whenever a new spin is recorded.</CardDescription>
        </CardHeader>
        <CardContent>
          {!data ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : data.top.length === 0 ? (
            <p className="text-sm text-muted-foreground">No spins yet. <Link href="/daily-prize" className="underline">Be the first to spin.</Link></p>
          ) : (
            <div className="space-y-2">
              {data.top.map((entry) => (
                <EntryRow key={entry.fullAddress} entry={entry} sort={data.sort} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {data && data.recent.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent winners</CardTitle>
            <CardDescription>Most recent 15 spins</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {data.recent.map((r, i) => (
                <li key={i} className="flex items-center justify-between border-b border-white/5 pb-1.5">
                  <span className="font-mono text-xs">{r.address}</span>
                  <span className="text-xs flex-1 px-3 truncate">{r.prizeLabel}</span>
                  <span className="text-xs text-muted-foreground">streak {r.streak}{r.bonus ? ` · ${r.bonus}` : ''}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Stat({ label, value, icon: Icon }: { label: string; value: number; icon: any }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
            <div className="font-display text-2xl font-bold mt-1">{value.toLocaleString()}</div>
          </div>
          <Icon className="h-7 w-7 text-muted-foreground/50" />
        </div>
      </CardContent>
    </Card>
  );
}

function EntryRow({ entry, sort }: { entry: LeaderboardEntry; sort: string }) {
  const isTop3 = entry.rank <= 3;
  return (
    <div className={[
      'flex items-center justify-between gap-4 p-3 rounded-md border',
      isTop3 ? 'border-amber-500/30 bg-gradient-to-r from-amber-500/5 to-transparent' : 'border-white/10 bg-white/[0.02]',
    ].join(' ')}>
      <div className="flex items-center gap-3 min-w-0">
        <div className={[
          'w-9 h-9 rounded-full flex items-center justify-center font-display font-bold text-sm',
          entry.rank === 1 ? 'bg-amber-500/20 text-amber-300' :
          entry.rank === 2 ? 'bg-slate-400/20 text-slate-300' :
          entry.rank === 3 ? 'bg-orange-700/30 text-orange-300' :
          'bg-white/5 text-muted-foreground',
        ].join(' ')}>
          {entry.rank === 1 ? <Crown className="h-4 w-4" /> : entry.rank}
        </div>
        <div className="min-w-0">
          <div className="font-mono text-sm truncate">{entry.address}</div>
          {entry.badges.length > 0 && (
            <div className="flex gap-1 mt-0.5 flex-wrap">
              {entry.badges.map((b) => (
                <Badge key={b} variant="ice" className="text-[9px] px-1.5 py-0">{b}</Badge>
              ))}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-4 text-right">
        {sort === 'streak' && (
          <div>
            <div className="font-display text-lg font-bold">{entry.longestStreak}</div>
            <div className="text-[10px] text-muted-foreground">days</div>
          </div>
        )}
        {sort === 'raffles' && (
          <div>
            <div className="font-display text-lg font-bold">{entry.totalRaffles}</div>
            <div className="text-[10px] text-muted-foreground">entries</div>
          </div>
        )}
        {sort === 'points' && (
          <div>
            <div className="font-display text-lg font-bold">{entry.totalPoints}</div>
            <div className="text-[10px] text-muted-foreground">points</div>
          </div>
        )}
        {sort === 'spins' && (
          <div>
            <div className="font-display text-lg font-bold">{entry.totalSpins}</div>
            <div className="text-[10px] text-muted-foreground">spins</div>
          </div>
        )}
      </div>
    </div>
  );
}
