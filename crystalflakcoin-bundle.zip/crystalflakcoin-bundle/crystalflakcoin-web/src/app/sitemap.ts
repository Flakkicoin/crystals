import type { MetadataRoute } from 'next';

const BASE = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ['', '/about', '/token', '/tokenomics', '/ecosystem', '/governance', '/transparency', '/docs', '/faq', '/legal', '/contact'];
  const lastModified = new Date();
  return routes.map((r) => ({ url: `${BASE}${r}`, lastModified, changeFrequency: 'monthly', priority: r === '' ? 1 : 0.6 }));
}
