import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { env, isPlaceholder } from '@/lib/env';
import { loadTokenPageData } from '@/lib/token/token-page-data';
import { ExternalLink, Copy } from 'lucide-react';

export const metadata = { title: 'Token information' };
export const dynamic = 'force-dynamic';

export default async function TokenPage() {
  const data = await loadTokenPageData();
  const contract = env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS;
  const network = env.NEXT_PUBLIC_TOKEN_NETWORK;
  const explorer = env.NEXT_PUBLIC_BLOCK_EXPLORER_URL;
  const deployed = data.deployed;
  const s = data.state;

  return (
    <div className="container py-16 space-y-10 max-w-4xl">
      <header className="space-y-3">
        <h1 className="font-display text-3xl md:text-5xl font-bold">Token information</h1>
        <p className="text-muted-foreground">
          CrystalFlakCoin is a digital asset on an EVM-compatible network. All values below are
          placeholders until the contract is deployed, verified, and announced through official
          channels.
        </p>
      </header>

      <RiskDisclaimer variant="banner" />

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle>Contract details</CardTitle>
            {data.statusVariant === 'immutable' ? (
              <Badge variant="success">Live · immutable</Badge>
            ) : data.statusVariant === 'live' ? (
              <Badge variant="ice">Live · ownership pending renounce</Badge>
            ) : (
              <Badge variant="warning">To be announced</Badge>
            )}
          </div>
          <CardDescription>
            Always verify the contract address on a block explorer before interacting.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-5">
          <Row k="Token name" v={s.name ?? env.NEXT_PUBLIC_TOKEN_NAME} />
          <Row k="Symbol" v={s.symbol ?? env.NEXT_PUBLIC_TOKEN_SYMBOL} />
          <Row k="Network" v={deployed ? s.network : <Pending />} />
          <Row k="Decimals" v={deployed && s.decimals !== undefined ? s.decimals : <Pending />} />
          <Row k="Total supply" v={deployed && s.totalSupplyFormatted ? `${s.totalSupplyFormatted} CFC` : <Pending />} />
          <Row k="Max supply" v={deployed && s.maxSupplyFormatted ? `${s.maxSupplyFormatted} CFC (fixed)` : <Pending />} />
          <div className="md:col-span-2">
            <Row
              k="Contract address"
              v={
                deployed ? (
                  <span className="flex items-center gap-2 font-mono text-sm break-all">
                    {contract}
                    <button onClick={() => navigator.clipboard?.writeText(contract!)} className="text-muted-foreground hover:text-foreground" title="Copy">
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                    <a
                      href={`${explorer}/address/${contract}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sky-300 hover:underline inline-flex items-center gap-1"
                    >
                      View on explorer <ExternalLink className="h-3 w-3" />
                    </a>
                  </span>
                ) : (
                  <Pending />
                )
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card id="contract">
        <CardHeader>
          <CardTitle>How to verify the contract</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <ol className="list-decimal pl-5 space-y-2">
            <li>Open the block explorer linked above.</li>
            <li>Confirm the <strong>Contract</strong> tab is present and the source code is verified.</li>
            <li>Compare the deployed bytecode with the published source on the project's GitHub.</li>
            <li>Check the audit report referenced in the <a className="underline" href="/transparency">Transparency</a> page.</li>
            <li>Do not interact with contracts that fail any of the above checks.</li>
          </ol>
          <p className="text-xs">If you find a discrepancy, please file a <a className="underline" href="/contact">security report</a>.</p>
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{k}</span>
      <span className="font-medium">{v}</span>
    </div>
  );
}

function Pending() {
  return <span className="text-muted-foreground italic text-sm">Not yet deployed</span>;
}
