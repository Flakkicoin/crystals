import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import { Shield, Code2, BookOpen, Github, ExternalLink, FileSearch, Eye, Sparkles, ArrowRight } from 'lucide-react';
import { BRAND } from '@/lib/brand';
import { isPlaceholder, env, tokenIsDeployed } from '@/lib/env';

export default function HomePage() {
  const explorerUrl = env.NEXT_PUBLIC_BLOCK_EXPLORER_URL;
  const contract = env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS;

  return (
    <div className="container py-16 space-y-20">
      {/* HERO */}
      <section className="grid lg:grid-cols-2 gap-10 items-center">
        <div className="space-y-6">
          <Badge variant="ice" className="text-xs">Open Source · Transparent · Community-governed</Badge>
          <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight">
            A <span className="crystal-text">crystalline</span><br />
            digital asset<br />
            built for the open internet.
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl">
            CrystalFlakCoin ({BRAND.ticker}) is a transparent digital asset project focused on
            verifiable on-chain activity, open documentation, and clear risk disclosure. Nothing
            on this site promises returns.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="ice" size="lg">
              <Link href="/ecosystem">Explore the ecosystem</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/docs">View documentation</Link>
            </Button>
            <Button asChild variant="ghost" size="lg">
              <Link href="/token#contract">
                <FileSearch className="h-4 w-4 mr-1" /> View contract
              </Link>
            </Button>
          </div>
        </div>

        <div className="relative aspect-square max-w-md mx-auto w-full">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-sky-400/20 via-violet-500/10 to-transparent blur-3xl" />
          <div className="absolute inset-8 rounded-full border border-sky-400/20 crystal-float" />
          <div className="absolute inset-16 rounded-full border border-violet-400/20 crystal-float" style={{ animationDelay: '1s' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="h-32 w-32 rounded-2xl bg-gradient-ice flex items-center justify-center text-6xl font-display font-bold text-background shadow-2xl shadow-sky-400/20 crystal-float">
              ◆
            </div>
          </div>
        </div>
      </section>

      {/* RISK BANNER */}
      <RiskDisclaimer variant="banner" />

      {/* LIVE TOKEN INFO — only shown if contract is deployed */}
      <section className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h2 className="font-display text-2xl md:text-3xl font-bold">Token information</h2>
          {tokenIsDeployed ? (
            <Badge variant="success">Verified on-chain</Badge>
          ) : (
            <Badge variant="warning">Not yet deployed</Badge>
          )}
        </div>

        {tokenIsDeployed ? (
          <TokenInfoDeployed explorerUrl={explorerUrl} contract={contract!} />
        ) : (
          <TokenInfoPending />
        )}
      </section>

      {/* PILLARS */}
      <section className="space-y-6">
        <h2 className="font-display text-2xl md:text-3xl font-bold">Design principles</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <Pillar
            icon={<Eye className="h-5 w-5" />}
            title="Verifiable"
            body="Every on-chain fact (contract address, supply, holders) is fetched from a verified source — never invented on this site."
          />
          <Pillar
            icon={<Shield className="h-5 w-5" />}
            title="Risk-first"
            body="Risk disclosures live next to every feature that could affect your assets: swapping, staking, governance."
          />
          <Pillar
            icon={<Code2 className="h-5 w-5" />}
            title="Open source"
            body="Documentation, contracts, and tooling are public. Anyone can audit, contribute, or report issues."
          />
        </div>
      </section>

      {/* CTA */}
      <section className="text-center space-y-4 py-10">
        <h3 className="font-display text-2xl font-bold">Read before you act</h3>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          CrystalFlakCoin is an experimental digital asset project. Please review the{' '}
          <Link href="/legal" className="underline">legal & risk notice</Link>, the{' '}
          <Link href="/docs" className="underline">documentation</Link>, and the{' '}
          <Link href="/faq" className="underline">FAQ</Link> before transacting.
        </p>
      </section>

      {/* DAILY PRIZE CTA */}
      <section className="space-y-6">
        <Card className="crystal-card">
          <CardHeader>
            <div className="flex items-center gap-3 flex-wrap">
              <Sparkles className="h-6 w-6 text-sky-300" />
              <CardTitle>Try the daily community spin</CardTitle>
              <Badge variant="ice">Non-monetary</Badge>
            </div>
            <CardDescription>
              One free spin, every UTC day. Win community points, raffle entries, or streak badges.
              No deposit required. All prizes are non-monetary until a token contract is deployed.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center gap-3 flex-wrap">
            <Button asChild variant="ice">
              <Link href="/daily-prize">Spin the wheel <ArrowRight className="h-4 w-4 ml-1" /></Link>
            </Button>
            <Button asChild variant="ghost">
              <Link href="/daily-prize/leaderboard">Leaderboard</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link href="/faq#daily-prize">How it works</Link>
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

function TokenInfoDeployed({ explorerUrl, contract }: { explorerUrl: string; contract: string }) {
  return (
    <Card>
      <CardContent className="pt-6 grid md:grid-cols-2 gap-4">
        <KV k="Token" v={env.NEXT_PUBLIC_TOKEN_NAME} />
        <KV k="Symbol" v={env.NEXT_PUBLIC_TOKEN_SYMBOL} />
        <KV k="Network" v={env.NEXT_PUBLIC_TOKEN_NETWORK || '—'} />
        <KV k="Decimals" v={String(env.TOKEN_DECIMALS)} />
        <div className="md:col-span-2">
          <KV
            k="Contract"
            v={
              <a
                href={`${explorerUrl}/address/${contract}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-sm text-sky-300 hover:underline break-all inline-flex items-center gap-1"
              >
                {contract} <ExternalLink className="h-3 w-3" />
              </a>
            }
          />
        </div>
      </CardContent>
    </Card>
  );
}

function TokenInfoPending() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Token not yet deployed</CardTitle>
        <CardDescription>
          The CrystalFlakCoin contract has not been published. All values below will be filled in
          once the contract is deployed, verified, and announced through official channels.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid md:grid-cols-2 gap-4">
        <KV k="Token" v="CrystalFlakCoin" />
        <KV k="Symbol" v="CFC" />
        <KV k="Network" v={<Pending />} />
        <KV k="Contract address" v={<Pending />} />
        <KV k="Total supply" v={<Pending />} />
        <KV k="Decimals" v={<Pending />} />
      </CardContent>
    </Card>
  );
}

function Pending() {
  return <span className="text-muted-foreground text-sm italic">To be announced</span>;
}

function KV({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex flex-col">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{k}</span>
      <span className="font-medium mt-1">{v}</span>
    </div>
  );
}

function Pillar({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <Card className="crystal-card">
      <CardHeader>
        <div className="h-10 w-10 rounded-md bg-sky-400/10 border border-sky-400/20 flex items-center justify-center text-sky-300 mb-2">
          {icon}
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{body}</p>
      </CardContent>
    </Card>
  );
}
