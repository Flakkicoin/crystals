import { NextResponse, type NextRequest } from 'next/server';

// Lightweight edge middleware: protect /admin (except /admin/login) at the edge.
// The route handlers re-validate the session in Node.
export function middleware(req: NextRequest) {
  const url = req.nextUrl;
  if (url.pathname.startsWith('/admin') && url.pathname !== '/admin/login') {
    const session = req.cookies.get(process.env.SESSION_COOKIE_NAME || 'cfc_session');
    if (!session || !session.value) {
      const loginUrl = new URL('/admin/login', req.url);
      loginUrl.searchParams.set('next', url.pathname);
      return NextResponse.redirect(loginUrl);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};
