/**
 * Environment variable validation using Zod.
 * Throws at startup if required values are missing or invalid.
 * This is the only place secrets are referenced.
 */
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  NEXT_PUBLIC_APP_URL: z.string().url(),
  NEXT_PUBLIC_APP_NAME: z.string().default('CrystalFlakCoin'),
  PORT: z.coerce.number().int().positive().default(3000),

  DATABASE_URL: z.string().min(1),
  DIRECT_DATABASE_URL: z.string().min(1).optional(),

  SESSION_PASSWORD: z.string().min(32, 'SESSION_PASSWORD must be at least 32 chars'),
  SESSION_COOKIE_NAME: z.string().default('cfc_session'),
  SESSION_TTL_SECONDS: z.coerce.number().int().positive().default(86_400),

  ADMIN_BOOTSTRAP_EMAIL: z.string().email().optional(),
  ADMIN_BOOTSTRAP_PASSWORD: z.string().optional(),

  NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID: z.string().optional(),
  NEXT_PUBLIC_SUPPORTED_CHAIN_IDS: z.string().default('1,11155111'),

  ETHEREUM_RPC_URL: z.string().url().optional(),
  SEPOLIA_RPC_URL: z.string().url().optional(),

  NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS: z.string().optional(),
  NEXT_PUBLIC_TOKEN_NETWORK: z.string().optional(),
  TOKEN_DECIMALS: z.coerce.number().int().min(0).max(36).default(18),
  NEXT_PUBLIC_TOKEN_SYMBOL: z.string().default('CFC'),
  NEXT_PUBLIC_TOKEN_NAME: z.string().default('CrystalFlakCoin'),

  ETHERSCAN_API_KEY: z.string().optional(),
  NEXT_PUBLIC_BLOCK_EXPLORER_URL: z.string().url().default('https://etherscan.io'),

  RATE_LIMIT_PROVIDER: z.enum(['memory', 'upstash']).default('memory'),
  UPSTASH_REDIS_REST_URL: z.string().optional(),
  UPSTASH_REDIS_REST_TOKEN: z.string().optional(),

  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().int().positive().optional(),
  SMTP_USER: z.string().optional(),
  SMTP_PASSWORD: z.string().optional(),
  SMTP_FROM: z.string().optional(),

  NEXT_PUBLIC_GITHUB_URL: z.string().url().optional(),
  NEXT_PUBLIC_DOCS_URL: z.string().url().optional(),
  NEXT_PUBLIC_AUDIT_URL: z.string().url().optional(),
  NEXT_PUBLIC_SUPPORT_EMAIL: z.string().email().optional(),
  NEXT_PUBLIC_SECURITY_EMAIL: z.string().email().optional(),
  NEXT_PUBLIC_TWITTER_URL: z.string().url().optional(),
  NEXT_PUBLIC_DISCORD_URL: z.string().url().optional(),
  NEXT_PUBLIC_TELEGRAM_URL: z.string().url().optional(),

  NEXT_PUBLIC_ENABLE_SWAP: z.coerce.boolean().default(false),
  NEXT_PUBLIC_ENABLE_STAKE: z.coerce.boolean().default(false),
  NEXT_PUBLIC_ENABLE_GOVERNANCE: z.coerce.boolean().default(false),

  // Privacy-friendly analytics (Plausible). Empty = disabled.
  NEXT_PUBLIC_PLAUSIBLE_DOMAIN: z.string().optional(),
  NEXT_PUBLIC_PLAUSIBLE_SCRIPT: z.string().url().optional().default('https://plausible.io/js/script.js'),
  NEXT_PUBLIC_ANALYTICS_ENABLED: z.coerce.boolean().default(true),
});

function parse() {
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    // In test/dev, return a permissive default rather than crashing.
    // Production will throw on import.
    if (process.env.NODE_ENV === 'production') {
      console.error('[env] Invalid environment configuration:');
      console.error(parsed.error.flatten().fieldErrors);
      throw new Error('Invalid environment configuration');
    }
    // Best-effort: fill required strings with placeholders, do not re-throw.
    return schema.parse({
      ...process.env,
      DATABASE_URL: process.env.DATABASE_URL || 'postgresql://test:test@localhost:5432/test',
      SESSION_PASSWORD: process.env.SESSION_PASSWORD || 'x'.repeat(32),
      NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
    });
  }
  return parsed.data;
}

export const env = parse();

export function isPlaceholder(value: string | undefined | null): boolean {
  if (!value) return true;
  if (value.includes('CHANGE_ME')) return true;
  return false;
}

export const supportedChainIds = (env.NEXT_PUBLIC_SUPPORTED_CHAIN_IDS || '')
  .split(',')
  .map((s) => Number(s.trim()))
  .filter(Boolean);

export const tokenIsDeployed = !isPlaceholder(env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS) && !!env.NEXT_PUBLIC_TOKEN_NETWORK;
