/**
 * Server-side data loader for the /token page.
 * Reads from the deployed contract (if configured) or returns placeholder data.
 */
import { readTokenState, tokenDeploymentConfigured, type TokenState } from './contract';

export interface TokenPageData {
  deployed: boolean;
  configured: boolean;
  state: TokenState;
  statusText: string;
  statusVariant: 'pending' | 'live' | 'immutable';
}

export async function loadTokenPageData(): Promise<TokenPageData> {
  const configured = tokenDeploymentConfigured();
  const state = await readTokenState();

  if (!configured || !state.deployed) {
    return {
      deployed: false,
      configured,
      state,
      statusText: 'Not yet deployed',
      statusVariant: 'pending',
    };
  }

  if (state.immutable) {
    return {
      deployed: true,
      configured,
      state,
      statusText: 'Live · ownership renounced',
      statusVariant: 'immutable',
    };
  }

  return {
    deployed: true,
    configured,
    state,
    statusText: 'Live · ownership not yet renounced',
    statusVariant: 'live',
  };
}
