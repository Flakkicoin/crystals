/**
 * CrystalFlakCoin — Frontend integration.
 *
 * Reads token state from the deployed contract using viem (already installed
 * for wagmi). When no contract is deployed, every function returns
 * safe placeholders that the UI can render.
 *
 * Usage:
 *   const state = await readTokenState('sepolia');
 *   if (state.deployed) {
 *     console.log(state.symbol, state.totalSupplyFormatted);
 *   }
 */
import { createPublicClient, http, formatUnits, type Address, type PublicClient } from 'viem';
import { mainnet, sepolia, base, optimism, arbitrum, polygon } from 'viem/chains';
import { env, isPlaceholder, tokenIsDeployed } from '@/lib/env';

export type SupportedNetwork = 'mainnet' | 'sepolia' | 'base' | 'optimism' | 'arbitrum' | 'polygon';

export interface TokenState {
  deployed: boolean;
  network?: SupportedNetwork;
  address?: Address;
  name?: string;
  symbol?: string;
  decimals?: number;
  totalSupply?: bigint;
  totalSupplyFormatted?: string;
  maxSupply?: bigint;
  maxSupplyFormatted?: string;
  owner?: Address;
  immutable?: boolean;
  explorerUrl?: string;
}

const NETWORK_CHAIN_IDS: Record<SupportedNetwork, number> = {
  mainnet: 1,
  sepolia: 11155111,
  base: 8453,
  optimism: 10,
  arbitrum: 42161,
  polygon: 137,
};

const CHAIN_BY_ID: Record<number, any> = {
  1: mainnet,
  11155111: sepolia,
  8453: base,
  10: optimism,
  42161: arbitrum,
  137: polygon,
};

function explorerFor(network: SupportedNetwork, address: Address): string {
  switch (network) {
    case 'mainnet':
      return `https://etherscan.io/address/${address}`;
    case 'sepolia':
      return `https://sepolia.etherscan.io/address/${address}`;
    case 'base':
      return `https://basescan.org/address/${address}`;
    case 'optimism':
      return `https://optimistic.etherscan.io/address/${address}`;
    case 'arbitrum':
      return `https://arbiscan.io/address/${address}`;
    case 'polygon':
      return `https://polygonscan.com/address/${address}`;
  }
}

const ERC20_ABI = [
  { type: 'function', name: 'name', stateMutability: 'view', inputs: [], outputs: [{ type: 'string' }] },
  { type: 'function', name: 'symbol', stateMutability: 'view', inputs: [], outputs: [{ type: 'string' }] },
  { type: 'function', name: 'decimals', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint8' }] },
  { type: 'function', name: 'totalSupply', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'MAX_SUPPLY', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'maxSupply', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
] as const;

let cachedClient: { network: SupportedNetwork; client: PublicClient } | null = null;

function getClient(network: SupportedNetwork): PublicClient {
  if (cachedClient && cachedClient.network === network) return cachedClient.client;

  const chain = CHAIN_BY_ID[NETWORK_CHAIN_IDS[network]] || sepolia;
  const rpcUrl = env.ETHEREUM_RPC_URL || env.SEPOLIA_RPC_URL;

  const client = createPublicClient({
    chain,
    transport: http(rpcUrl),
  }) as PublicClient;

  cachedClient = { network, client };
  return client;
}

function resolveNetwork(): SupportedNetwork | undefined {
  const declared = env.NEXT_PUBLIC_TOKEN_NETWORK;
  if (!declared || isPlaceholder(declared)) return undefined;
  if (declared in NETWORK_CHAIN_IDS) return declared as SupportedNetwork;
  return undefined;
}

/**
 * Read the current state of the CrystalFlakCoin contract.
 *
 * Returns `{ deployed: false }` if the contract address is not set,
 * is a placeholder, or the network is not declared.
 */
export async function readTokenState(networkOverride?: SupportedNetwork): Promise<TokenState> {
  const address = env.NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS as Address | undefined;

  if (!tokenIsDeployed || !address || isPlaceholder(address)) {
    return { deployed: false };
  }

  const network = networkOverride || resolveNetwork();
  if (!network) {
    return { deployed: false };
  }

  const client = getClient(network);

  try {
    const [name, symbol, decimals, totalSupply, maxSupply, owner] = await Promise.all([
      client.readContract({ address, abi: ERC20_ABI, functionName: 'name' }) as Promise<string>,
      client.readContract({ address, abi: ERC20_ABI, functionName: 'symbol' }) as Promise<string>,
      client.readContract({ address, abi: ERC20_ABI, functionName: 'decimals' }) as Promise<number>,
      client.readContract({ address, abi: ERC20_ABI, functionName: 'totalSupply' }) as Promise<bigint>,
      client.readContract({ address, abi: ERC20_ABI, functionName: 'MAX_SUPPLY' }) as Promise<bigint>,
      client.readContract({ address, abi: ERC20_ABI, functionName: 'owner' }) as Promise<Address>,
    ]);

    return {
      deployed: true,
      network,
      address,
      name,
      symbol,
      decimals,
      totalSupply,
      totalSupplyFormatted: formatUnits(totalSupply, decimals),
      maxSupply,
      maxSupplyFormatted: formatUnits(maxSupply, decimals),
      owner,
      immutable: owner === '0x0000000000000000000000000000000000000000',
      explorerUrl: explorerFor(network, address),
    };
  } catch (err) {
    // If the read fails (wrong network, wrong address, RPC down), return a safe state.
    return { deployed: false };
  }
}

/**
 * Synchronous check: is the contract deployed (based on env vars only)?
 * Use this in render paths; use `readTokenState()` when you actually need data.
 */
export function tokenDeploymentConfigured(): boolean {
  return tokenIsDeployed && !!resolveNetwork();
}

/**
 * Returns the configured network, or undefined if not configured.
 */
export function tokenNetwork(): SupportedNetwork | undefined {
  return resolveNetwork();
}
