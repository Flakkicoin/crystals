/**
 * Rate limiting — in-memory fallback for dev, Upstash Redis in production.
 * Sliding-window per-key counter.
 */
import { env } from './env';

type Bucket = { count: number; resetAt: number };
const memoryStore = new Map<string, Bucket>();

export async function rateLimit(opts: { key: string; limit: number; windowMs: number }) {
  const { key, limit, windowMs } = opts;
  const now = Date.now();

  if (env.RATE_LIMIT_PROVIDER === 'upstash' && env.UPSTASH_REDIS_REST_URL && env.UPSTASH_REDIS_REST_TOKEN) {
    // Real Upstash sliding-window via REST. (Optional — not required in dev.)
    try {
      const res = await fetch(`${env.UPSTASH_REDIS_REST_URL}/pipeline`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.UPSTASH_REDIS_REST_TOKEN}`, 'Content-Type': 'application/json' },
        body: JSON.stringify([
          ['INCR', key],
          ['PEXPIRE', key, windowMs],
        ]),
      });
      const json = (await res.json()) as Array<{ result: number }>;
      const count = json[0]?.result ?? 0;
      return { ok: count <= limit, count, remaining: Math.max(0, limit - count), resetAt: now + windowMs };
    } catch (e) {
      console.error('[rate-limit] upstash error, falling back to memory', e);
    }
  }

  // Memory fallback
  const bucket = memoryStore.get(key);
  if (!bucket || bucket.resetAt < now) {
    memoryStore.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, count: 1, remaining: limit - 1, resetAt: now + windowMs };
  }
  bucket.count++;
  const ok = bucket.count <= limit;
  return { ok, count: bucket.count, remaining: Math.max(0, limit - bucket.count), resetAt: bucket.resetAt };
}

export function clientKeyFromRequest(req: Request): string {
  const forwarded = req.headers.get('x-forwarded-for');
  const ip = (forwarded ? forwarded.split(',')[0].trim() : req.headers.get('x-real-ip')) || 'unknown';
  return ip;
}
