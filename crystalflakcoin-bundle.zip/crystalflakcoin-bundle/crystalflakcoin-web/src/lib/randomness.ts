/**
 * Randomness sources for the daily spin.
 *
 * Today: ServerRandomness (server-issued 32-byte seed + wallet + UTC date).
 * Tomorrow: CommitRevealRandomness and ChainlinkVRFRandomness stubs.
 *
 * The spin endpoint never instantiates a randomness source directly.
 * It calls `getActiveRandomness()` which reads RandomnessConfig and
 * returns the configured source. This lets the admin panel switch
 * sources without code changes.
 */
import { createHash, randomBytes } from 'node:crypto';
import { prisma } from './prisma';

export interface RandomnessResult {
  /** The deterministic input that produced the outcome. */
  seed: string;
  /** The numeric roll in [0, totalWeight). */
  roll: number;
  /** The source identifier, for audit logs. */
  source: string;
  /** Optional: a public proof the user can verify. */
  proof?: string;
}

export interface RandomnessSource {
  id: string;
  label: string;
  description: string;
  /** Compute a roll in [0, totalWeight) for the given (wallet, date). */
  roll(opts: { wallet: string; date: string; totalWeight: number }): Promise<RandomnessResult>;
}

/** Server-issued 32-byte seed, combined with the wallet + date. */
export class ServerRandomness implements RandomnessSource {
  id = 'server';
  label = 'Server RNG (SHA-256 of wallet + date + seed)';
  description = 'A 32-byte server-issued random seed is combined with the wallet address and UTC date, then SHA-256-hashed. The first 8 hex chars of the hash, modulo the prize total weight, give the outcome. The seed is recorded in the audit log for verification.';

  async roll({ wallet, date, totalWeight }: { wallet: string; date: string; totalWeight: number }) {
    const seed = randomBytes(32).toString('hex');
    const hash = createHash('sha256').update(`${wallet}:${date}:${seed}`).digest('hex');
    const roll = parseInt(hash.slice(0, 8), 16) % totalWeight;
    return {
      seed,
      roll,
      source: this.id,
      proof: `sha256("${wallet}:${date}:${seed}").slice(0,8) % ${totalWeight} = ${roll}`,
    };
  }
}

/**
 * Commit-reveal scheme. The server commits to a hash of (seed, nonce) BEFORE
 * the spin, then reveals the seed after. The user can verify the hash matches.
 *
 * NOT YET WIRED — included as the documented migration path.
 */
export class CommitRevealRandomness implements RandomnessSource {
  id = 'commit-reveal';
  label = 'Commit-reveal (two-phase)';
  description = 'Server commits to SHA-256(seed || nonce) before the spin. The user sees the commitment hash. After the spin, the server reveals the seed and nonce. The user can verify the original commitment matches. Requires a two-step spin flow.';

  async roll(_opts: { wallet: string; date: string; totalWeight: number }): Promise<RandomnessResult> {
    throw new Error('CommitRevealRandomness is not yet implemented. Set RandomnessConfig.source to "server".');
  }
}

/**
 * Chainlink VRF integration. The server requests a verifiable random
 * function from the Chainlink oracle, waits for the callback, then derives
 * the outcome. Requires a funded VRF subscription and a deployed VRF
 * consumer contract.
 *
 * NOT YET WIRED — included as the documented migration path.
 */
export class ChainlinkVRFRandomness implements RandomnessSource {
  id = 'chainlink-vrf';
  label = 'Chainlink VRF (verifiable on-chain)';
  description = 'A Chainlink VRF request is sent from a consumer contract. The oracle returns a verifiable random word, which is combined with the wallet + date to produce the outcome. Highest assurance but requires gas + a deployed consumer contract.';

  async roll(_opts: { wallet: string; date: string; totalWeight: number }): Promise<RandomnessResult> {
    throw new Error('ChainlinkVRFRandomness is not yet implemented. Set RandomnessConfig.source to "server".');
  }
}

const SOURCES: Record<string, RandomnessSource> = {
  server: new ServerRandomness(),
  'commit-reveal': new CommitRevealRandomness(),
  'chainlink-vrf': new ChainlinkVRFRandomness(),
};

let cachedSource: { id: string; source: RandomnessSource; fetchedAt: number } | null = null;
const CACHE_MS = 5_000; // 5s — admin changes take effect quickly without thrashing the DB

/** Returns the currently active randomness source. */
export async function getActiveRandomness(): Promise<RandomnessSource> {
  const now = Date.now();
  if (cachedSource && now - cachedSource.fetchedAt < CACHE_MS) {
    return cachedSource.source;
  }
  const config = await prisma.randomnessConfig.findFirst({ where: { isEnabled: true } });
  const id = (config?.source || 'server').toLowerCase();
  const source = SOURCES[id] || SOURCES.server;
  cachedSource = { id, source, fetchedAt: now };
  return source;
}

/** Invalidate the cache (call from admin endpoints after a config change). */
export function invalidateRandomnessCache() {
  cachedSource = null;
}

/** List all available sources — used by the admin panel. */
export function listAvailableSources(): { id: string; label: string; description: string; enabled: boolean }[] {
  return Object.values(SOURCES).map((s) => ({ id: s.id, label: s.label, description: s.description, enabled: s.id === 'server' }));
}
