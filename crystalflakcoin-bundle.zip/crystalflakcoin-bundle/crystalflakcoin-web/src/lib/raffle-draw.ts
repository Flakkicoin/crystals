/**
 * Raffle draw — picks winners from a pool of RaffleEntry rows for a
 * given period using a deterministic, server-seeded RNG.
 *
 * Algorithm:
 * 1. Load all RaffleEntry rows for the period.
 * 2. Generate a server seed.
 * 3. For each active RaffleTier (in order), pick `numWinners` winners
 *    by hashing (seed + tierCode + index). The same (seed, period)
 *    always produces the same winners.
 * 4. The output is a JSON-serialisable mapping of { tierCode: [wallets] }.
 */
import { createHash, randomBytes } from 'node:crypto';
import { prisma } from './prisma';

export interface DrawResult {
  period: string;
  serverSeed: string;
  totalEntries: number;
  totalUniqueWallets: number;
  winnersByTier: Record<string, string[]>;
  proofsByTier: Record<string, string[]>;
  // Idempotency check
  alreadyDrawn: boolean;
}

export async function runRaffleDraw(opts: { period: string; drawnBy: string; dryRun?: boolean }): Promise<DrawResult> {
  const existing = await prisma.raffleDraw.findUnique({ where: { period: opts.period } });
  if (existing) {
    return {
      period: opts.period,
      serverSeed: existing.serverSeed,
      totalEntries: existing.totalEntries,
      totalUniqueWallets: existing.totalUniqueWallets,
      winnersByTier: JSON.parse(existing.resultJson),
      proofsByTier: {}, // not stored for past draws; recompute on demand
      alreadyDrawn: true,
    };
  }

  const entries = await prisma.raffleEntry.findMany({ where: { period: opts.period } });
  if (entries.length === 0) {
    throw new Error(`No raffle entries for period ${opts.period}.`);
  }
  const uniqueWallets = new Set(entries.map((e) => e.walletAddress));

  const tiers = await prisma.raffleTier.findMany({ where: { isActive: true }, orderBy: [{ order: 'asc' }, { numWinners: 'desc' }] });
  if (tiers.length === 0) {
    throw new Error('No active raffle tiers configured.');
  }

  const serverSeed = randomBytes(32).toString('hex');
  const winnersByTier: Record<string, string[]> = {};
  const proofsByTier: Record<string, string[]> = {};
  // For each tier, pick `numWinners` distinct wallets from the pool.
  // We sample without replacement using a Fisher–Yates-style shuffle seeded
  // by SHA-256(serverSeed || tierCode || index).
  for (const tier of tiers) {
    const winners: string[] = [];
    const proofs: string[] = [];
    const remaining = [...entries];
    for (let i = 0; i < tier.numWinners && remaining.length > 0; i++) {
      const h = createHash('sha256').update(`${serverSeed}:${tier.code}:${i}`).digest('hex');
      const roll = parseInt(h.slice(0, 8), 16) % remaining.length;
      const winner = remaining[roll];
      remaining.splice(roll, 1);
      winners.push(winner.walletAddress);
      proofs.push(`sha256("${serverSeed}:${tier.code}:${i}").slice(0,8) % ${remaining.length + 1} = ${roll} → ${winner.id}`);
    }
    winnersByTier[tier.code] = winners;
    proofsByTier[tier.code] = proofs;
  }

  if (opts.dryRun) {
    return {
      period: opts.period,
      serverSeed,
      totalEntries: entries.length,
      totalUniqueWallets: uniqueWallets.size,
      winnersByTier,
      proofsByTier,
      alreadyDrawn: false,
    };
  }

  // Persist
  const draw = await prisma.raffleDraw.create({
    data: {
      period: opts.period,
      drawnBy: opts.drawnBy,
      totalEntries: entries.length,
      totalUniqueWallets: uniqueWallets.size,
      serverSeed,
      resultJson: JSON.stringify(winnersByTier),
      status: 'complete',
    },
  });

  // Persist individual winners
  for (const tier of tiers) {
    const winners = winnersByTier[tier.code] || [];
    for (let i = 0; i < winners.length; i++) {
      const winnerAddr = winners[i];
      // Find the original entry for this winner
      const sourceEntry = entries.find((e) => e.walletAddress === winnerAddr);
      if (!sourceEntry) continue;
      await prisma.raffleWinner.create({
        data: {
          drawId: draw.id,
          tierId: tier.id,
          walletAddress: winnerAddr,
          chainId: sourceEntry.chainId,
          ticketIndex: entries.indexOf(sourceEntry),
          sourceEntryId: sourceEntry.id,
        },
      });
    }
  }

  return {
    period: opts.period,
    serverSeed,
    totalEntries: entries.length,
    totalUniqueWallets: uniqueWallets.size,
    winnersByTier,
    proofsByTier,
    alreadyDrawn: false,
  };
}
