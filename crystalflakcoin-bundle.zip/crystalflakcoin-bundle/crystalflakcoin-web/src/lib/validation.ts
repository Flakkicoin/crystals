/**
 * Zod schemas for request validation.
 * Use these at the boundary of every API route.
 */
import { z } from 'zod';

export const AddressSchema = z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'Invalid EIP-55 address format');

export const TokenMetadataUpdateSchema = z.object({
  name: z.string().min(1).max(64).optional(),
  symbol: z.string().min(1).max(16).optional(),
  decimals: z.number().int().min(0).max(36).optional(),
  network: z.string().max(64).optional(),
  chainId: z.number().int().positive().optional(),
  contractAddress: z.string().refine(
    (v) => v === '' || /^0x[a-fA-F0-9]{40}$/.test(v),
    'Invalid contract address',
  ).optional(),
  isDeployed: z.boolean().optional(),
  description: z.string().max(2000).optional(),
});

export const TokenomicsAllocationSchema = z.object({
  category: z.string().min(1).max(64),
  label: z.string().min(1).max(128),
  percentage: z.number().min(0).max(100).nullable().optional(),
  amount: z.string().max(64).nullable().optional(),
  vestingMonths: z.number().int().min(0).max(120).nullable().optional(),
  cliffMonths: z.number().int().min(0).max(120).nullable().optional(),
  unlockDate: z.string().datetime().nullable().optional(),
  walletAddress: z.string().refine(
    (v) => !v || v === '' || /^0x[a-fA-F0-9]{40}$/.test(v),
    'Invalid wallet address',
  ).nullable().optional(),
  notes: z.string().max(1000).nullable().optional(),
  order: z.number().int().min(0).max(1000).optional(),
});

export const AnnouncementSchema = z.object({
  slug: z.string().min(1).max(128).regex(/^[a-z0-9-]+$/, 'slug must be lowercase letters, numbers, hyphens'),
  title: z.string().min(1).max(200),
  body: z.string().min(1).max(20_000),
  severity: z.enum(['info', 'warning', 'critical']).default('info'),
  published: z.boolean().default(false),
});

export const DocumentationPageSchema = z.object({
  slug: z.string().min(1).max(128).regex(/^[a-z0-9-]+$/),
  title: z.string().min(1).max(200),
  body: z.string().min(1).max(50_000),
  category: z.enum(['getting-started', 'security', 'developers', 'legal']),
  order: z.number().int().min(0).max(1000).default(0),
  published: z.boolean().default(false),
});

export const SecurityReportSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().min(1).max(10_000),
  severity: z.enum(['low', 'medium', 'high', 'critical']),
  reporter: z.string().email().optional().or(z.literal('')),
  details: z.string().max(20_000).optional(),
});

export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(256),
});

export const SiweLoginSchema = z.object({
  message: z.string().min(1),
  signature: z.string().regex(/^0x[a-fA-F0-9]+$/, 'Invalid signature'),
});
