/**
 * Append-only audit log for admin actions.
 * Never log secrets, signatures, or seed phrases.
 */
import { prisma } from './prisma';

export async function audit(opts: {
  userId?: string;
  action: string;
  resource?: string;
  ip?: string | null;
  userAgent?: string | null;
  metadata?: Record<string, unknown>;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: opts.userId,
        action: opts.action,
        resource: opts.resource,
        ip: opts.ip ?? null,
        userAgent: opts.userAgent ?? null,
        metadata: opts.metadata as any,
      },
    });
  } catch (e) {
    // Never let audit failures break the request — log to stderr.
    console.error('[audit] failed to write audit log', e);
  }
}
