/**
 * Auth — server-side session via iron-session + optional email/password (argon2) + SIWE.
 * No private keys or seed phrases are ever stored or transmitted through the API.
 */
import { getIronSession, SessionOptions } from 'iron-session';
import { cookies } from 'next/headers';
import argon2 from 'argon2';
import { prisma } from './prisma';
import { env } from './env';
import { SiweMessage } from 'siwe';
import { createPublicClient, http } from 'viem';
import { mainnet, sepolia } from 'viem/chains';

export type SessionData = {
  userId?: string;
  email?: string;
  role?: string;
  permissions?: string[];
  isLoggedIn?: boolean;
  csrf?: string;
  siwe?: { address: string; chainId: number; issuedAt: string };
};

const sessionOptions: SessionOptions = {
  password: env.SESSION_PASSWORD,
  cookieName: env.SESSION_COOKIE_NAME,
  ttl: env.SESSION_TTL_SECONDS,
  cookieOptions: {
    secure: env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
  },
};

export async function getSession() {
  return getIronSession<SessionData>(cookies(), sessionOptions);
}

export async function requireAdmin() {
  const session = await getSession();
  if (!session.isLoggedIn || !session.userId) {
    return { ok: false as const, status: 401, error: 'Not authenticated' };
  }
  if (session.role !== 'ADMIN') {
    return { ok: false as const, status: 403, error: 'Insufficient permissions' };
  }
  return { ok: true as const, session };
}

export async function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, { type: argon2.argon2id });
}

export async function verifyPassword(hash: string, plain: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plain);
  } catch {
    return false;
  }
}

export async function loginWithEmail(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email }, include: { role: true } });
  if (!user || !user.passwordHash) return null;
  const ok = await verifyPassword(user.passwordHash, password);
  if (!ok) return null;
  return user;
}

/**
 * Verify a SIWE message server-side. Returns the recovered address or null.
 * We never receive a private key — only a signed message and the user's address.
 */
export async function verifySiwe(message: string, signature: string): Promise<{ address: string; chainId: number } | null> {
  try {
    const siwe = new SiweMessage(message);
    const chainId = siwe.chainId;
    const rpc = chainId === mainnet.id ? env.ETHEREUM_RPC_URL : chainId === sepolia.id ? env.SEPOLIA_RPC_URL : undefined;
    if (!rpc) return null;
    const client = createPublicClient({ chain: chainId === mainnet.id ? mainnet : sepolia, transport: http(rpc) });
    const result = await siwe.verify({ signature, nonce: siwe.nonce });
    if (!result.success) return null;
    // Re-verify against on-chain to confirm address controls the account
    await client.getBlockNumber(); // touches RPC; ensures reachable
    return { address: siwe.address, chainId };
  } catch {
    return null;
  }
}

export function generateCsrfToken(): string {
  // 32-byte URL-safe random
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  return Buffer.from(arr).toString('base64url');
}
