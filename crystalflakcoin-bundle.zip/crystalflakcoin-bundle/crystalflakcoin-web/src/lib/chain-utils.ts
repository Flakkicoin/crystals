/**
 * Address utilities — checksum validation (EIP-55).
 */
import { getAddress, isAddress } from 'viem';

export function toChecksumAddress(addr: string): string | null {
  try {
    if (!isAddress(addr)) return null;
    return getAddress(addr);
  } catch {
    return null;
  }
}

export function shortenAddress(addr: string, head = 6, tail = 4): string {
  if (!addr) return '';
  if (addr.length <= head + tail) return addr;
  return `${addr.slice(0, head)}…${addr.slice(-tail)}`;
}
