/**
 * Wagmi + RainbowKit configuration.
 * Server-side import-safe (does not instantiate the connector on import).
 */
import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import { mainnet, sepolia } from 'wagmi/chains';
import { env, isPlaceholder, supportedChainIds } from './env';

const projectId = isPlaceholder(env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID)
  ? '00000000000000000000000000000000' // RainbowKit requires a project id; this is a development placeholder
  : env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID!;

const chains = [mainnet, sepolia].filter((c) => supportedChainIds.includes(c.id));

export const wagmiConfig = getDefaultConfig({
  appName: env.NEXT_PUBLIC_APP_NAME,
  projectId,
  chains: chains as any,
  ssr: true,
});
