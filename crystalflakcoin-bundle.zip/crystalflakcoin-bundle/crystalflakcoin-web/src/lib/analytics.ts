/**
 * Privacy-friendly analytics event tracking.
 *
 * Safe to call from any client or server code:
 *   - On the client, events are sent to Plausible (if configured)
 *   - On the server, the call is silently dropped (no-op)
 *   - When Plausible isn't configured (no NEXT_PUBLIC_PLAUSIBLE_DOMAIN), the call is silently dropped
 *
 * No personally identifiable information (PII) is ever sent. Use opaque IDs
 * (event names + categorical props) only.
 */

export type AnalyticsProps = Record<string, string | number | boolean>;

export interface AnalyticsWindow {
  plausible?: (event: string, options?: { props?: AnalyticsProps; callback?: () => void }) => void;
}

/**
 * Fire a custom analytics event.
 *
 * @param name    Event name (e.g. "wallet_connected")
 * @param props   Optional categorical properties (no PII)
 */
export function trackEvent(name: string, props?: AnalyticsProps) {
  if (typeof window === 'undefined') return;
  const w = window as AnalyticsWindow;
  if (typeof w.plausible !== 'function') return;
  try {
    w.plausible(name, props ? { props } : undefined);
  } catch {
    // never let analytics crash the app
  }
}

/**
 * Pageview (only relevant when manual pageviews are enabled).
 */
export function trackPageview(url?: string) {
  if (typeof window === 'undefined') return;
  const w = window as AnalyticsWindow;
  if (typeof w.plausible !== 'function') return;
  try {
    w.plausible('pageview', { props: url ? { url } : undefined });
  } catch {
    /* no-op */
  }
}

/**
 * Standard event names. Use these constants to keep events consistent
 * across the codebase and so the analytics page can enumerate them.
 */
export const EVENTS = {
  // Wallet
  WALLET_CONNECTED: 'wallet_connected',
  WALLET_DISCONNECTED: 'wallet_disconnected',

  // Daily prize
  DAILY_PRIZE_PAGE_VIEWED: 'daily_prize_page_viewed',
  DAILY_PRIZE_SPIN_STARTED: 'daily_prize_spin_started',
  DAILY_PRIZE_SPIN_COMPLETED: 'daily_prize_spin_completed',
  DAILY_PRIZE_PRIZE_WON: 'daily_prize_prize_won',
  DAILY_PRIZE_MILESTONE: 'daily_prize_milestone',
  DAILY_PRIZE_LEADERBOARD_VIEWED: 'daily_prize_leaderboard_viewed',
  DAILY_PRIZE_DRAWS_VIEWED: 'daily_prize_draws_viewed',

  // Donations
  DONATION_CLICKED: 'donation_clicked',
  SPONSORS_PAGE_VIEWED: 'sponsors_page_viewed',

  // Content
  DOCS_VIEWED: 'docs_viewed',
  TRANSPARENCY_VIEWED: 'transparency_viewed',
  PRESS_PAGE_VIEWED: 'press_page_viewed',

  // External link
  EXTERNAL_LINK_CLICKED: 'external_link_clicked',

  // Admin (only logged if admin is signed in; never includes credentials)
  ADMIN_LOGIN_ATTEMPT: 'admin_login_attempt',
  ADMIN_LOGIN_SUCCESS: 'admin_login_success',
  ADMIN_LOGIN_FAILED: 'admin_login_failed',
  ADMIN_TOKEN_METADATA_UPDATED: 'admin_token_metadata_updated',
  ADMIN_RAFFLE_DRAW_TRIGGERED: 'admin_raffle_draw_triggered',
} as const;

export type EventName = (typeof EVENTS)[keyof typeof EVENTS];

/**
 * Standard event prop keys. Use these for consistency.
 */
export const EVENT_PROPS = {
  WALLET_TYPE: 'wallet_type',
  ADDRESS_TYPE: 'address_type',
  PRIZE_CODE: 'prize_code',
  PRIZE_CATEGORY: 'prize_category',
  STREAK: 'streak',
  METHOD: 'method',
  SECTION: 'section',
  URL: 'url',
  ADMIN_ROLE: 'admin_role',
} as const;
