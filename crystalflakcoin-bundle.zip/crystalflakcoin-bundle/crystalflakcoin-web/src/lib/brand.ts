/**
 * Brand constants and the canonical list of forbidden legacy terms.
 * Re-exported for use in the legacy-brand scanner and other validators.
 */
export const BRAND = {
  name: 'CrystalFlakCoin',
  shortName: 'CFC',
  ticker: 'CFC',
  tagline: 'A transparent digital asset project built for the open internet.',
  url: 'https://crystalflakcoin.example', // Updated by NEXT_PUBLIC_APP_URL
} as const;

/**
 * Forbidden legacy brand references.
 * The prebuild scanner reads this list and fails the build if any are found.
 */
export const FORBIDDEN_TERMS: ReadonlyArray<{ term: string; reason: string }> = [
  { term: 'iCoinPro', reason: 'legacy brand reference' },
  { term: 'ICP Corporate', reason: 'legacy brand reference' },
  { term: 'ICP corporate', reason: 'legacy brand reference' },
  { term: 'Legacy Bonus', reason: 'legacy brand reference' },
  { term: 'legacy bonus', reason: 'legacy brand reference' },
  { term: 'Auto Trader', reason: 'legacy brand reference' },
  { term: 'auto trader', reason: 'legacy brand reference' },
  { term: 'autotrader', reason: 'legacy brand reference' },
  { term: 'icoinpro', reason: 'legacy brand reference (lowercase)' },
  { term: 'icp-corp', reason: 'legacy brand reference' },
  // Misleading financial claims that must never appear in the project
  { term: 'guaranteed profit', reason: 'misleading financial claim' },
  { term: 'risk-free', reason: 'misleading financial claim' },
  { term: 'passive income', reason: 'misleading financial claim' },
  { term: 'get rich', reason: 'misleading financial claim' },
  { term: 'best trading bot', reason: 'misleading financial claim' },
  { term: '97% win rate', reason: 'fabricated statistic' },
  { term: 'most powerful compensation plan', reason: 'misleading recruitment claim' },
  { term: 'earn by recruiting', reason: 'misleading recruitment claim' },
  { term: 'you cannot lose', reason: 'misleading financial claim' },
  { term: 'limited-time financial opportunity', reason: 'misleading financial claim' },
];
