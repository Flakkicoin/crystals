/**
 * CrystalFlakCoin — Daily Prize / Spin catalogue
 * --------------------------------------------------------
 * IMPORTANT — what this actually is:
 *
 * 1. The "daily spin" is a community engagement mechanic, not a slot machine.
 * 2. Every prize is **non-monetary** and has no cash value while the token
 *    contract is undeployed. The site renders this clearly.
 * 3. When a token contract is deployed, community points may become
 *    convertible to token units at a ratio that will be published in advance
 *    and approved through governance. Until then, the conversion ratio is
 *    "to be announced".
 * 4. Raffle entries are entries into a periodic on-chain draw, not guaranteed
 *    payouts. The draw mechanism, eligibility, and prizes will be published
 *    before any entry is redeemed.
 * 5. All odds disclosed below are server-enforced and tested.
 *
 * DO NOT:
 * - Change weights without updating the disclosure on the public page.
 * - Add a prize that implies a guaranteed monetary outcome.
 * - Add a prize that requires the user to deposit funds to claim.
 */

export type PrizeCategory = 'points' | 'raffle' | 'badge' | 'streak_freeze' | 'none';

export interface PrizeDef {
  code: string;
  label: string;
  description: string;
  category: PrizeCategory;
  // Outcome bucket weights (relative; need not sum to 100)
  weight: number;
  // Visual style for the wheel
  color: string; // tailwind gradient pair
  // Result values
  points?: number;
  raffles?: number;
  // Whether this prize preserves the streak if it's about to break
  freezesStreak?: boolean;
  // Disclosure text shown in the prize table
  disclosure: string;
}

// Weights are in basis points (1 = 0.01%) to avoid float math.
// The sum of `weight` across all prizes is the basis-point total.
// `pickPrize(roll)` rolls a number in [0, total) and walks the table.
export const PRIZE_CATALOG: PrizeDef[] = [
  {
    code: 'COMMON_10',
    label: '+10 Community Points',
    description: 'Ten community points. Points are non-transferable and have no cash value until a token contract is deployed.',
    category: 'points',
    weight: 4500, // 45%
    color: 'from-violet-700/40 to-violet-500/20',
    points: 10,
    disclosure: 'Non-monetary. Becomes convertible to token units only if and when a token contract is published and a conversion ratio is announced.',
  },
  {
    code: 'COMMON_25',
    label: '+25 Community Points',
    description: 'Twenty-five community points. Same terms as the small-points prize.',
    category: 'points',
    weight: 1800, // 18%
    color: 'from-fuchsia-700/40 to-violet-500/20',
    points: 25,
    disclosure: 'Non-monetary.',
  },
  {
    code: 'RAFFLE_1',
    label: '+1 Raffle Entry',
    description: 'One entry into the current quarterly on-chain draw. The draw, eligibility, and prizes are published before entries are redeemed.',
    category: 'raffle',
    weight: 1800, // 18%
    color: 'from-sky-700/40 to-sky-500/20',
    raffles: 1,
    disclosure: 'Non-monetary until a draw is run. The draw mechanism, eligibility window, and prize pool will be published before any entry is redeemed.',
  },
  {
    code: 'RAFFLE_2',
    label: '+2 Raffle Entries',
    description: 'Two entries into the current quarterly on-chain draw.',
    category: 'raffle',
    weight: 900, // 9%
    color: 'from-cyan-700/40 to-sky-500/20',
    raffles: 2,
    disclosure: 'Non-monetary until a draw is run.',
  },
  {
    code: 'POINTS_50',
    label: '+50 Community Points',
    description: 'Fifty community points.',
    category: 'points',
    weight: 500, // 5%
    color: 'from-indigo-700/40 to-violet-500/20',
    points: 50,
    disclosure: 'Non-monetary.',
  },
  {
    code: 'RAFFLE_5',
    label: '+5 Raffle Entries',
    description: 'Five entries into the current quarterly on-chain draw.',
    category: 'raffle',
    weight: 250, // 2.5%
    color: 'from-emerald-700/40 to-cyan-500/20',
    raffles: 5,
    disclosure: 'Non-monetary.',
  },
  {
    code: 'STREAK_FREEZE',
    label: 'Streak Freeze',
    description: 'One streak-freeze token. If you miss a day, this automatically protects your streak.',
    category: 'streak_freeze',
    weight: 200, // 2%
    color: 'from-slate-600/40 to-slate-400/20',
    freezesStreak: true,
    disclosure: 'Cosmetic utility only. No monetary value.',
  },
  {
    code: 'BRONZE_BADGE',
    label: 'Bronze Supporter Badge',
    description: 'A bronze supporter badge. Visible in your profile and on the public supporters list.',
    category: 'badge',
    weight: 40, // 0.4%
    color: 'from-amber-800/40 to-amber-500/20',
    disclosure: 'Cosmetic, off-chain. No monetary value.',
  },
  {
    code: 'JACKPOT',
    label: 'Jackpot: 100 Raffle Entries',
    description: 'One hundred raffle entries. The rarest outcome. Independent of streak.',
    category: 'raffle',
    weight: 10, // 0.1%
    color: 'from-yellow-500/40 to-amber-300/20',
    raffles: 100,
    disclosure: 'Non-monetary until a draw is run.',
  },
];

export const TOTAL_WEIGHT = PRIZE_CATALOG.reduce((acc, p) => acc + p.weight, 0);

/** Pick a prize by a roll in [0, TOTAL_WEIGHT). */
export function pickPrize(roll: number): { prize: PrizeDef; index: number } {
  if (roll < 0 || roll >= TOTAL_WEIGHT || !Number.isFinite(roll)) {
    // Defensive: bad RNG — pick the highest-weight prize to remain deterministic.
    return { prize: PRIZE_CATALOG[0], index: 0 };
  }
  let acc = 0;
  for (let i = 0; i < PRIZE_CATALOG.length; i++) {
    acc += PRIZE_CATALOG[i].weight;
    if (roll < acc) return { prize: PRIZE_CATALOG[i], index: i };
  }
  return { prize: PRIZE_CATALOG[PRIZE_CATALOG.length - 1], index: PRIZE_CATALOG.length - 1 };
}

/** Compute the visual target angle (in degrees) for the wheel so that `index` lands under the pointer. */
export function angleForIndex(index: number): number {
  const segs = PRIZE_CATALOG.length;
  const seg = 360 / segs;
  // Center the segment under the pointer (pointer is at top = 0deg after our CSS).
  return 360 * 6 - (index * seg + seg / 2);
}

/** Streak bonus tier at a given streak count. */
export interface StreakBonus {
  code: string;
  threshold: number;
  label: string;
  description: string;
}

export const STREAK_BONUSES: StreakBonus[] = [
  { code: 'BRONZE', threshold: 3, label: 'Bronze Supporter', description: 'Earned at a 3-day streak. A persistent badge in your profile.' },
  { code: 'SILVER', threshold: 7, label: 'Silver Supporter', description: 'Earned at a 7-day streak. Includes +5 bonus raffle entries.' },
  { code: 'GOLD', threshold: 30, label: 'Gold Supporter', description: 'Earned at a 30-day streak. Reserved allocation in any future community distribution (subject to governance).' },
  { code: 'FOUNDER', threshold: 100, label: "Founder's Circle", description: 'Earned at a 100-day streak. Permanent recognition + a reserved allocation at token launch (subject to governance).' },
];

/** The next un-earned streak bonus at the given streak, or null. */
export function nextStreakBonus(streak: number, earnedCodes: string[]): StreakBonus | null {
  for (const b of STREAK_BONUSES) {
    if (streak >= b.threshold && !earnedCodes.includes(b.code)) return b;
  }
  return null;
}

/** ISO date (UTC) — used as the per-day key. */
export function utcDateString(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}

/** Has the streak broken? True if the last spin was before yesterday. */
export function streakIsBroken(lastSpinDate: string | null, today: string): boolean {
  if (!lastSpinDate) return false;
  const last = new Date(lastSpinDate + 'T00:00:00Z').getTime();
  const now = new Date(today + 'T00:00:00Z').getTime();
  const diffDays = (now - last) / 86_400_000;
  return diffDays > 1.5; // beyond yesterday = broken
}

/** Spin availability state. */
export function spinAvailability(lastSpinDate: string | null, now: Date = new Date()): {
  canSpin: boolean;
  nextSpinAt: string;
  cooldownRemainingMs: number;
} {
  const today = utcDateString(now);
  if (lastSpinDate !== today) return { canSpin: true, nextSpinAt: '', cooldownRemainingMs: 0 };
  // Compute ms until next UTC midnight
  const tomorrow = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  return { canSpin: false, nextSpinAt: tomorrow.toISOString(), cooldownRemainingMs: tomorrow.getTime() - now.getTime() };
}
