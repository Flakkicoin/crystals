/**
 * CSRF protection — double-submit cookie pattern.
 * The server sets a CSRF cookie; the client must echo it in X-CSRF-Token header.
 * SameSite=Lax on the session cookie also helps; this is defense-in-depth.
 */
import { getSession, generateCsrfToken } from './auth';

export async function getOrIssueCsrf(): Promise<string> {
  const session = await getSession();
  if (!session.csrf) {
    session.csrf = generateCsrfToken();
    await session.save();
  }
  return session.csrf;
}

export async function verifyCsrf(token: string | null | undefined): Promise<boolean> {
  if (!token) return false;
  const session = await getSession();
  if (!session.csrf) return false;
  // constant-time compare
  if (token.length !== session.csrf.length) return false;
  let mismatch = 0;
  for (let i = 0; i < token.length; i++) mismatch |= token.charCodeAt(i) ^ session.csrf.charCodeAt(i);
  return mismatch === 0;
}
