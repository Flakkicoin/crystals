/**
 * CrystalFlakCoin — Brand color tokens, typography, and design tokens.
 *
 * This is the single source of truth for brand colors. Use these constants
 * instead of hardcoded hex values across the project.
 *
 * CSS variables are exported as a string for injection into <style> tags
 * or for use in tailwind.config.ts.
 */

export const BRAND_COLORS = {
  // Core palette
  bg: '#07021a',
  surface: '#0d0530',
  surfaceElevated: '#0f1729',
  navy: '#0a1530',
  // Crystal accents
  crystal: '#7dd3fc',
  crystalBright: '#bae6fd',
  violet: '#a855f7',
  violetDeep: '#7c3aed',
  magenta: '#d946ef',
  ice: '#38bdf8',
  // Neutrals
  ink0: '#ffffff',
  ink1: '#e9d8ff',
  ink2: '#b6a3d4',
  ink3: '#7d6aa0',
  // Semantic
  success: '#22c55e',
  warning: '#facc15',
  danger: '#ff6b9d',
} as const;

export const BRAND_GRADIENTS = {
  ice: 'linear-gradient(135deg, #7dd3fc 0%, #38bdf8 50%, #a855f7 100%)',
  violet: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 50%, #d946ef 100%)',
  crystal: 'linear-gradient(180deg, #0a1530 0%, #0f1729 50%, #1e1b4b 100%)',
  glass: 'linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.01) 100%)',
} as const;

export const TYPOGRAPHY = {
  display: 'Orbitron, system-ui, sans-serif',
  body: 'Inter, system-ui, -apple-system, sans-serif',
  mono: 'ui-monospace, SFMono-Regular, Menlo, monospace',
} as const;

export const SPACING = {
  xs: '4px',
  sm: '8px',
  md: '16px',
  lg: '24px',
  xl: '32px',
  '2xl': '48px',
  '3xl': '64px',
} as const;

export const RADII = {
  sm: '6px',
  md: '12px',
  lg: '18px',
  xl: '24px',
  full: '9999px',
} as const;

/**
 * CSS variable export. Inject via:
 *   <style dangerouslySetInnerHTML={{ __html: BRAND_CSS_VARS }} />
 */
export const BRAND_CSS_VARS = `:root{${Object.entries(BRAND_COLORS)
  .map(([k, v]) => `--cfc-${k}: ${v};`)
  .join('')}}`;

/**
 * Tailwind config snippet (for tailwind.config.ts `theme.extend.colors`).
 */
export const BRAND_TAILWIND_COLORS = Object.fromEntries(
  Object.entries(BRAND_COLORS).map(([k, v]) => [k, v]),
);

export const BRAND = {
  name: 'CrystalFlakCoin',
  ticker: 'CFC',
  url: 'https://crystalflakcoin.example',
  tagline: 'A transparent digital asset project built for the open internet.',
} as const;
