import { AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface RiskDisclaimerProps {
  variant?: 'banner' | 'inline' | 'compact';
  context?: string;
}

export function RiskDisclaimer({ variant = 'banner', context }: RiskDisclaimerProps) {
  if (variant === 'compact') {
    return (
      <div className="text-xs text-muted-foreground border-l-2 border-amber-500/50 pl-3">
        <strong className="text-amber-400">Risk notice:</strong>{' '}
        Digital assets are volatile and may result in partial or total loss. Not financial advice.
      </div>
    );
  }
  return (
    <Alert className="border-amber-500/30 bg-amber-500/5 my-6">
      <AlertTriangle className="h-4 w-4 text-amber-400" />
      <AlertTitle className="text-amber-300">Risk disclosure</AlertTitle>
      <AlertDescription className="text-amber-100/80">
        {context ? `${context} ` : ''}
        CrystalFlakCoin (CFC) is a digital asset project. Holding or transacting in digital assets
        involves technical, market, regulatory, and operational risks. You may lose some or all of
        the value of your assets. Nothing on this site is financial, investment, legal, or tax
        advice. Always verify contract addresses, do your own research, and never share your seed
        phrase or private key with anyone.
      </AlertDescription>
    </Alert>
  );
}
