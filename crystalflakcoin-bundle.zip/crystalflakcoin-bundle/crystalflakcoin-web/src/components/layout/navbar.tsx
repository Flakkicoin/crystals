'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/', label: 'Home' },
  { href: '/daily-prize', label: 'Spin' },
  { href: '/daily-prize/leaderboard', label: 'Leaderboard' },
  { href: '/daily-prize/draws', label: 'Draws' },
  { href: '/about', label: 'About' },
  { href: '/token', label: 'Token' },
  { href: '/tokenomics', label: 'Tokenomics' },
  { href: '/ecosystem', label: 'Ecosystem' },
  { href: '/governance', label: 'Governance' },
  { href: '/transparency', label: 'Transparency' },
  { href: '/docs', label: 'Docs' },
  { href: '/faq', label: 'FAQ' },
  { href: '/press', label: 'Press' },
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="h-8 w-8 rounded-md bg-gradient-ice flex items-center justify-center font-bold text-background text-sm crystal-float">
            ◆
          </div>
          <div>
            <div className="font-display font-bold text-base leading-none">CrystalFlakCoin</div>
            <div className="text-[10px] text-muted-foreground tracking-widest leading-none mt-0.5">CFC</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-white/5"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link href="/legal">Risk</Link>
          </Button>
          <WalletButtonClient />
        </div>

        <button
          className="lg:hidden p-2 rounded-md hover:bg-white/5"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-white/5 bg-background/95 backdrop-blur-md">
          <nav className="container py-4 grid gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm rounded-md hover:bg-white/5"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/legal"
              className="px-3 py-2 text-sm rounded-md hover:bg-white/5 flex items-center gap-2"
              onClick={() => setOpen(false)}
            >
              <Shield className="h-4 w-4" /> Risk & Legal
            </Link>
            <div className="pt-2">
              <WalletButtonClient />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

// Inline client component (kept here for simplicity)
function WalletButtonClient() {
  return (
    <Button asChild size="sm" variant="ice">
      <Link href="/connect">Connect Wallet</Link>
    </Button>
  );
}
