import Link from 'next/link';
import { BRAND } from '@/lib/brand';
import { Github, Twitter, MessageCircle, Send } from 'lucide-react';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-white/5 bg-background/40 mt-20">
      <div className="container py-12 grid gap-8 md:grid-cols-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md bg-gradient-ice flex items-center justify-center font-bold text-background text-sm">◆</div>
            <div>
              <div className="font-display font-bold">{BRAND.name}</div>
              <div className="text-[10px] text-muted-foreground tracking-widest">{BRAND.ticker}</div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground max-w-xs">
            A transparent digital asset project. Nothing on this site is financial advice.
          </p>
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-3">Project</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link href="/about" className="hover:text-foreground">About</Link></li>
            <li><Link href="/token" className="hover:text-foreground">Token</Link></li>
            <li><Link href="/tokenomics" className="hover:text-foreground">Tokenomics</Link></li>
            <li><Link href="/ecosystem" className="hover:text-foreground">Ecosystem</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-3">Trust</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link href="/transparency" className="hover:text-foreground">Transparency</Link></li>
            <li><Link href="/docs" className="hover:text-foreground">Documentation</Link></li>
            <li><Link href="/governance" className="hover:text-foreground">Governance</Link></li>
            <li><Link href="/legal" className="hover:text-foreground">Legal & Risk</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-sm mb-3">Contact</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link href="/contact" className="hover:text-foreground">Contact form</Link></li>
            <li><Link href="/transparency" className="hover:text-foreground">Security report</Link></li>
            <li><Link href="/faq" className="hover:text-foreground">FAQ</Link></li>
          </ul>
          <div className="flex items-center gap-3 mt-4">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="GitHub"><Github className="h-4 w-4" /></a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="Twitter"><Twitter className="h-4 w-4" /></a>
            <a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="Discord"><MessageCircle className="h-4 w-4" /></a>
            <a href="https://t.me" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground" aria-label="Telegram"><Send className="h-4 w-4" /></a>
          </div>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="container py-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-muted-foreground">
          <div>© {year} CrystalFlakCoin. All rights reserved.</div>
          <div className="max-w-2xl text-right">
            Digital assets are subject to market, technical, and regulatory risk. Past performance does not indicate future results.
            Not financial advice. Verify all information independently.
          </div>
        </div>
      </div>
    </footer>
  );
}
