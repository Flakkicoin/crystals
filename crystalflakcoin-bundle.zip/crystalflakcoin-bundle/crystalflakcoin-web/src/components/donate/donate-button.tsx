'use client';

/**
 * Donation click tracker — a small client wrapper that fires an analytics
 * event when a user clicks a donation link, then navigates normally.
 *
 * Server components can wrap their donation links with this and the click
 * will be recorded. PII is never sent — only the donation method label.
 */
import { trackEvent, EVENTS, EVENT_PROPS } from '@/lib/analytics';
import { type AnchorHTMLAttributes } from 'react';

interface DonateLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  method: 'github_sponsors' | 'open_collective' | 'ethereum' | 'bitcoin' | 'other';
  href: string;
  children: React.ReactNode;
}

export function DonateLink({ method, href, children, ...rest }: DonateLinkProps) {
  return (
    <a
      href={href}
      onClick={() => trackEvent(EVENTS.DONATION_CLICKED, { [EVENT_PROPS.METHOD]: method })}
      {...rest}
    >
      {children}
    </a>
  );
}
