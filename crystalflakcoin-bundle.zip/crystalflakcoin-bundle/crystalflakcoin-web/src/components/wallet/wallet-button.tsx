'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Wallet, AlertTriangle, ExternalLink, Copy } from 'lucide-react';
import { shortenAddress } from '@/lib/chain-utils';
import { isPlaceholder } from '@/lib/env';
import { trackEvent, EVENTS, EVENT_PROPS } from '@/lib/analytics';

interface WalletButtonProps {
  // When we wire wagmi this will come from useAccount()
  address?: string | null;
  chainId?: number | null;
  onConnect?: () => Promise<void>;
  onDisconnect?: () => void;
}

export function WalletButton({ address, chainId, onConnect, onDisconnect }: WalletButtonProps) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  if (address) {
    return (
      <div className="flex items-center gap-2">
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
          {shortenAddress(address)}
        </div>
        {chainId && !isChainSupported(chainId) && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
            <AlertTriangle className="h-3 w-3" /> Unsupported network
          </div>
        )}
        <Button size="sm" variant="outline" onClick={onDisconnect}>Disconnect</Button>
      </div>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ice" size="sm">
          <Wallet className="h-4 w-4 mr-1" /> Connect Wallet
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Connect a wallet</DialogTitle>
          <DialogDescription>
            Choose a wallet to interact with CrystalFlakCoin. CrystalFlakCoin never custodies your funds and never sees your private keys or seed phrase.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-2">
          {['MetaMask', 'WalletConnect', 'Coinbase Wallet', 'Rainbow'].map((w) => (
            <button
              key={w}
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await onConnect?.();
                  setOpen(false);
                  trackEvent(EVENTS.WALLET_CONNECTED, { [EVENT_PROPS.WALLET_TYPE]: w });
                } finally {
                  setBusy(false);
                }
              }}
              className="w-full flex items-center justify-between p-3 rounded-md border border-white/10 hover:border-primary/50 hover:bg-white/5 transition-colors text-left"
            >
              <span className="font-medium">{w}</span>
              <ExternalLink className="h-4 w-4 text-muted-foreground" />
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          By connecting, you confirm you have read and accept the{' '}
          <a href="/legal" className="underline">terms of use</a> and the{' '}
          <a href="/legal#risk" className="underline">risk disclosure</a>.
        </p>
      </DialogContent>
    </Dialog>
  );
}

function isChainSupported(chainId: number) {
  const list = (process.env.NEXT_PUBLIC_SUPPORTED_CHAIN_IDS || '').split(',').map((s) => Number(s.trim()));
  return list.includes(chainId);
}

// Re-export the address copy helper as a small client button
export function CopyAddress({ address }: { address: string }) {
  return (
    <button
      onClick={() => navigator.clipboard.writeText(address)}
      className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
      title="Copy address"
    >
      <Copy className="h-3 w-3" /> {shortenAddress(address)}
    </button>
  );
}
