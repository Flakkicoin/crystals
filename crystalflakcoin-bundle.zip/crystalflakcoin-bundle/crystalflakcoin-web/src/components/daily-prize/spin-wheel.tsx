'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { RiskDisclaimer } from '@/components/layout/risk-disclaimer';
import {
  PRIZE_CATALOG,
  angleForIndex,
  type PrizeDef,
  spinAvailability,
  utcDateString,
} from '@/lib/daily-prize';
import {
  Sparkles, Trophy, Clock, Users, Flame, ShieldCheck, Copy, AlertTriangle, Info, History, Crown,
} from 'lucide-react';
import Link from 'next/link';
import { useAccount, useSignMessage } from 'wagmi';
import { SiweMessage } from 'siwe';
import { shortenAddress } from '@/lib/chain-utils';
import { trackEvent, EVENTS, EVENT_PROPS } from '@/lib/analytics';

interface SpinResult {
  ok: boolean;
  prize: { code: string; label: string; description: string; category: string; points: number; raffles: number; disclosure: string; outcomeIndex: number };
  bonus: { code: string; label: string; description: string } | null;
  streak: { current: number; longest: number; wasReset: boolean };
  nextSpinAt: string;
}

interface StatusPayload {
  connected: boolean;
  address?: string;
  hasSpun?: boolean;
  canSpin?: boolean;
  nextSpinAt?: string;
  currentStreak?: number;
  longestStreak?: number;
  totalSpins?: number;
  totalPoints?: number;
  totalRaffles?: number;
  badges?: { code: string; label: string; earnedAt: string }[];
  nextBonus?: { code: string; label: string; description: string } | null;
}

interface LeaderboardPayload {
  topStreaks: { address: string; longestStreak: number; currentStreak: number; totalSpins: number }[];
  topRaffles: { address: string; totalRaffles: number }[];
  recent: { address: string; prizeCode: string; prizeLabel: string; streak: number; ago: string }[];
}

export function DailyPrizeClient() {
  const { address, isConnected, chainId } = useAccount();
  const { signMessageAsync } = useSignMessage();

  const [prizes, setPrizes] = useState<PrizeDef[]>(PRIZE_CATALOG);
  const [status, setStatus] = useState<StatusPayload | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardPayload | null>(null);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<SpinResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [cooldownMs, setCooldownMs] = useState(0);
  const [manualAddr, setManualAddr] = useState('');

  // Load prize catalogue
  useEffect(() => {
    fetch('/api/daily-prize/spin', { method: 'GET' })
      .then((r) => r.json())
      .then((j) => setPrizes(j.prizes))
      .catch(() => setPrizes(PRIZE_CATALOG));
  }, []);

  // Load leaderboard
  useEffect(() => {
    fetch('/api/daily-prize/leaderboard')
      .then((r) => r.json())
      .then(setLeaderboard)
      .catch(() => null);
  }, [result]);

  // Load status whenever address or chain changes
  useEffect(() => {
    if (!address) {
      setStatus({ connected: false });
      return;
    }
    refreshStatus(address, chainId);
  }, [address, chainId, result]);

  async function refreshStatus(addr: string, chId?: number) {
    try {
      const r = await fetch('/api/daily-prize/status', {
        headers: { 'x-cfc-wallet': addr, ...(chId ? { 'x-cfc-chain': String(chId) } : {}) },
      });
      if (r.ok) setStatus(await r.json());
    } catch { /* noop */ }
  }

  // Countdown ticker
  useEffect(() => {
    if (!status?.nextSpinAt) { setCooldownMs(0); return; }
    const tick = () => {
      const ms = Math.max(0, new Date(status.nextSpinAt!).getTime() - Date.now());
      setCooldownMs(ms);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [status?.nextSpinAt]);

  async function spin() {
    if (spinning) return;
    setErr(null);
    setInfo(null);

    let wallet: string | undefined = address;
    let chain = chainId;

    // If not connected, use manual address
    if (!wallet) {
      if (!/^0x[a-fA-F0-9]{40}$/.test(manualAddr)) {
        setErr('Enter a wallet address to demo, or connect your wallet.');
        return;
      }
      wallet = manualAddr as `0x${string}`;
      chain = chain ?? 1;
    }
    if (!wallet) return;

    setSpinning(true);
    trackEvent(EVENTS.DAILY_PRIZE_SPIN_STARTED);
    try {
      // Issue a nonce first
      const nonceRes = await fetch('/api/daily-prize/nonce', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletAddress: wallet, chainId: chain }),
      });
      if (!nonceRes.ok) {
        const j = await nonceRes.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to issue spin nonce');
      }
      const { nonce } = await nonceRes.json();

      // Build the body. If a wallet is connected, sign a SIWE-style message and
      // send it in the body for server-side verification. If not (demo path),
      // send the wallet+nonce in headers instead.
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const body: any = {};

      if (isConnected && address && signMessageAsync) {
        try {
          const message = new SiweMessage({
            domain: typeof window !== 'undefined' ? window.location.host : 'localhost:3000',
            address: address as `0x${string}`,
            statement: 'Claim today\'s CrystalFlakCoin community spin.',
            uri: typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
            version: '1',
            chainId: chain ?? 1,
            nonce,
          });
          const prepared = message.prepareMessage();
          const signature = await signMessageAsync({ message: prepared });
          body.siwe_message = prepared;
          body.siwe_signature = signature;
        } catch (e) {
          setInfo('Signature not provided — continuing with nonce-based auth (demo).');
          headers['x-cfc-wallet'] = wallet;
          headers['x-cfc-chain'] = String(chain);
          headers['x-cfc-nonce'] = nonce;
        }
      } else {
        headers['x-cfc-wallet'] = wallet;
        headers['x-cfc-chain'] = String(chain);
        headers['x-cfc-nonce'] = nonce;
      }

      const res = await fetch('/api/daily-prize/spin', { method: 'POST', headers, body: JSON.stringify(body) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || 'Spin failed');

      // Animate to the actual outcome index
      const target = angleForIndex(j.prize.outcomeIndex);
      setAngle((prev) => prev + target + 360);
      trackEvent(EVENTS.DAILY_PRIZE_SPIN_COMPLETED, {
        [EVENT_PROPS.PRIZE_CODE]: j.prize.code,
        [EVENT_PROPS.PRIZE_CATEGORY]: j.prize.category,
      });
      setTimeout(() => {
        setResult(j);
        setSpinning(false);
        trackEvent(EVENTS.DAILY_PRIZE_PRIZE_WON, {
          [EVENT_PROPS.PRIZE_CODE]: j.prize.code,
          [EVENT_PROPS.PRIZE_CATEGORY]: j.prize.category,
        });
      }, 5100);
    } catch (e: any) {
      setErr(e?.message || 'Something went wrong.');
      setSpinning(false);
    }
  }

  const canSpin = !!status && (status.canSpin ?? true) && !spinning;
  const segs = prizes.length;
  const seg = 360 / segs;

  function buildShareText(streak: number) {
    return `I just hit a ${streak}-day streak on CrystalFlakCoin's community spin. ${streak} days. ${streak >= 30 ? "Founder's Circle." : streak >= 7 ? 'Silver Supporter.' : 'Bronze Supporter.'} https://crystalflakcoin.example/daily-prize`;
  }

  return (
    <div className="container py-12 space-y-10 max-w-6xl">
      <header className="space-y-3 text-center">
        <span className="eyebrow">Daily community spin</span>
        <h1 className="font-display text-3xl md:text-5xl font-bold mt-3">One free spin, every UTC day</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Connect your wallet, sign once, and claim a non-monetary community prize. No deposits.
          No promises. Just a fun way to grow with the project before the token contract is
          deployed.
        </p>
      </header>

      <RiskDisclaimer
        variant="banner"
        context="All prizes are non-monetary. They have no cash value while the token contract is undeployed."
      />

      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-8 items-start">
        {/* WHEEL */}
        <Card className="crystal-card">
          <CardContent className="pt-6 flex flex-col items-center gap-5">
            <div className="relative w-full max-w-[420px] aspect-square">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-sky-400/10 via-violet-500/10 to-transparent blur-2xl" />
              <svg viewBox="0 0 400 400" className="w-full h-full" style={{ transform: `rotate(${angle}deg)`, transition: spinning ? 'transform 5s cubic-bezier(.17,.67,.12,.99)' : 'none' }}>
                {prizes.map((p, i) => {
                  const a0 = i * seg - 90;
                  const a1 = a0 + seg;
                  const rad = Math.PI / 180;
                  const cx = 200, cy = 200, r = 195;
                  const x0 = cx + r * Math.cos(a0 * rad);
                  const y0 = cy + r * Math.sin(a0 * rad);
                  const x1 = cx + r * Math.cos(a1 * rad);
                  const y1 = cy + r * Math.sin(a1 * rad);
                  const large = seg > 180 ? 1 : 0;
                  const path = `M${cx},${cy} L${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 ${large} 1 ${x1.toFixed(2)},${y1.toFixed(2)} Z`;
                  const aMid = (a0 + a1) / 2;
                  const lr = r * 0.62;
                  const lx = cx + lr * Math.cos(aMid * rad);
                  const ly = cy + lr * Math.sin(aMid * rad);
                  const rot = aMid + 90;
                  const [from, to] = p.color.replace('from-', '').replace('to-', '').split(' ');
                  return (
                    <g key={p.code}>
                      <path d={path} fill={`url(#grad-${p.code})`} stroke="rgba(255,255,255,.15)" strokeWidth="1" />
                      <g transform={`translate(${lx.toFixed(2)},${ly.toFixed(2)}) rotate(${rot.toFixed(2)})`}>
                        <text textAnchor="middle" dominantBaseline="middle" fill="#fff" fontSize="12" fontFamily="Inter, system-ui" fontWeight="700">
                          {p.code === 'STREAK_FREEZE' ? 'FREEZE' :
                           p.code === 'JACKPOT' ? 'JACKPOT' :
                           p.label.replace('Community Points', 'PTS').replace('Raffle Entries', 'RAFFLE').replace('Streak Freeze', 'FREEZE').replace('Bronze Supporter Badge', 'BRONZE').replace('Supporter', '').replace('+', '')}
                        </text>
                        <text textAnchor="middle" dominantBaseline="middle" y="14" fill="rgba(255,255,255,.7)" fontSize="9" fontFamily="Inter, system-ui" letterSpacing="1">
                          {p.code === 'COMMON_10' ? '45%' :
                           p.code === 'COMMON_25' ? '18%' :
                           p.code === 'RAFFLE_1' ? '18%' :
                           p.code === 'RAFFLE_2' ? '9%' :
                           p.code === 'POINTS_50' ? '5%' :
                           p.code === 'RAFFLE_5' ? '2.5%' :
                           p.code === 'STREAK_FREEZE' ? '2%' :
                           p.code === 'BRONZE_BADGE' ? '0.4%' :
                           p.code === 'JACKPOT' ? '0.1%' : ''}
                        </text>
                      </g>
                    </g>
                  );
                })}
                <defs>
                  {prizes.map((p) => (
                    <linearGradient key={p.code} id={`grad-${p.code}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor={
                        p.code === 'COMMON_10' ? '#7c3aed' :
                        p.code === 'COMMON_25' ? '#a855f7' :
                        p.code === 'RAFFLE_1' ? '#0284c7' :
                        p.code === 'RAFFLE_2' ? '#0ea5e9' :
                        p.code === 'POINTS_50' ? '#4f46e5' :
                        p.code === 'RAFFLE_5' ? '#10b981' :
                        p.code === 'STREAK_FREEZE' ? '#475569' :
                        p.code === 'BRONZE_BADGE' ? '#b45309' :
                        p.code === 'JACKPOT' ? '#eab308' :
                        '#7c3aed'
                      } />
                      <stop offset="100%" stopColor={
                        p.code === 'COMMON_10' ? '#a855f7' :
                        p.code === 'COMMON_25' ? '#d946ef' :
                        p.code === 'RAFFLE_1' ? '#38bdf8' :
                        p.code === 'RAFFLE_2' ? '#22d3ee' :
                        p.code === 'POINTS_50' ? '#7c3aed' :
                        p.code === 'RAFFLE_5' ? '#22d3ee' :
                        p.code === 'STREAK_FREEZE' ? '#94a3b8' :
                        p.code === 'BRONZE_BADGE' ? '#f59e0b' :
                        p.code === 'JACKPOT' ? '#fde68a' :
                        '#a855f7'
                      } stopOpacity=".4" />
                    </linearGradient>
                  ))}
                </defs>
                <circle cx="200" cy="200" r="42" fill="rgba(7,2,26,0.95)" stroke="rgba(168,85,247,.5)" strokeWidth="2" />
              </svg>
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
                <div className="w-0 h-0 border-l-[14px] border-r-[14px] border-t-[24px] border-l-transparent border-r-transparent border-t-sky-300 drop-shadow-[0_4px_8px_rgba(168,85,247,.7)]" />
              </div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                <button
                  onClick={spin}
                  disabled={!canSpin}
                  className="w-[100px] h-[100px] rounded-full bg-gradient-ice text-background font-display font-bold text-sm shadow-2xl shadow-sky-400/30 disabled:opacity-50 disabled:cursor-not-allowed transition hover:scale-105 active:scale-95"
                >
                  {spinning ? '…' : 'SPIN'}
                </button>
              </div>
            </div>

            {!isConnected && (
              <div className="w-full max-w-md space-y-2">
                <p className="text-xs text-center text-muted-foreground">
                  Don&apos;t have a wallet handy? Paste any EVM address to demo the flow (no funds are touched).
                </p>
                <div className="flex gap-2">
                  <Input
                    value={manualAddr}
                    onChange={(e) => setManualAddr(e.target.value)}
                    placeholder="0x…"
                    className="font-mono text-sm"
                  />
                  <Button onClick={spin} disabled={spinning} variant="ice">Demo spin</Button>
                </div>
              </div>
            )}

            {isConnected && address && (
              <p className="text-xs text-muted-foreground">
                Connected: <span className="font-mono">{shortenAddress(address)}</span>
              </p>
            )}

            {err && (
              <Alert variant="destructive" className="w-full">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Couldn&apos;t spin</AlertTitle>
                <AlertDescription>{err}</AlertDescription>
              </Alert>
            )}
            {info && (
              <Alert className="w-full border-sky-500/30 bg-sky-500/5">
                <Info className="h-4 w-4 text-sky-300" />
                <AlertTitle className="text-sky-200">Heads up</AlertTitle>
                <AlertDescription className="text-sky-100/80">{info}</AlertDescription>
              </Alert>
            )}

            {status?.hasSpun && cooldownMs > 0 && (
              <div className="text-center space-y-1">
                <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
                  <Clock className="h-4 w-4" /> Next spin in
                </p>
                <p className="font-display text-2xl font-bold">{formatCountdown(cooldownMs)}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* SIDE PANEL */}
        <div className="space-y-4">
          <StreakPanel status={status} />
          <StreakCalendar status={status} />
          <LeaderboardPanel leaderboard={leaderboard} />
          <Card>
            <CardContent className="pt-6">
              <Button asChild variant="outline" className="w-full">
                <Link href={`/daily-prize/history${address ? `?wallet=${address}` : ''}`}>
                  <History className="h-4 w-4 mr-2" /> View full history & verify seeds
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* PRIZE TABLE */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle>What you can win</CardTitle>
              <CardDescription>Disclosed odds. Non-monetary until a token contract is deployed.</CardDescription>
            </div>
            <Badge variant="ice">Server-enforced</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b border-white/10">
                  <th className="py-2 pr-3">Prize</th>
                  <th className="py-2 pr-3">Odds</th>
                  <th className="py-2 pr-3">Category</th>
                  <th className="py-2 pr-3">Disclosure</th>
                </tr>
              </thead>
              <tbody>
                {prizes.map((p) => (
                  <tr key={p.code} className="border-b border-white/5">
                    <td className="py-2 pr-3">
                      <div className="font-medium">{p.label}</div>
                      <div className="text-xs text-muted-foreground">{p.description}</div>
                    </td>
                    <td className="py-2 pr-3 font-display font-bold">{(p.weight / PRIZE_CATALOG.reduce((a, x) => a + x.weight, 0) * 100).toFixed(2)}%</td>
                    <td className="py-2 pr-3"><Badge variant="muted">{p.category}</Badge></td>
                    <td className="py-2 pr-3 text-xs text-muted-foreground">{p.disclosure}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <RiskDisclaimer variant="compact" />

      {result && <ResultModal result={result} onClose={() => setResult(null)} />}
    </div>
  );
}

function formatCountdown(ms: number) {
  if (ms <= 0) return '00:00:00';
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms / 60_000) % 60);
  const s = Math.floor((ms / 1000) % 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function StreakPanel({ status }: { status: StatusPayload | null }) {
  if (!status?.connected) {
    return (
      <Card>
        <CardContent className="pt-6 space-y-2">
          <h3 className="font-display text-lg font-bold flex items-center gap-2"><Flame className="h-5 w-5 text-amber-400" /> Your streak</h3>
          <p className="text-sm text-muted-foreground">Connect your wallet or enter a demo address to start tracking your daily streak.</p>
        </CardContent>
      </Card>
    );
  }
  return (
    <Card>
      <CardContent className="pt-6 space-y-4">
        <h3 className="font-display text-lg font-bold flex items-center gap-2"><Flame className="h-5 w-5 text-amber-400" /> Your stats</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <Stat label="Current streak" value={`${status.currentStreak ?? 0} days`} />
          <Stat label="Longest" value={`${status.longestStreak ?? 0} days`} />
          <Stat label="Total spins" value={String(status.totalSpins ?? 0)} />
          <Stat label="Points" value={String(status.totalPoints ?? 0)} />
          <Stat label="Raffle entries" value={String(status.totalRaffles ?? 0)} />
          <Stat label="Badges" value={String(status.badges?.length ?? 0)} />
        </div>
        {status.nextBonus && (
          <div className="p-3 rounded-md border border-sky-500/30 bg-sky-500/5 text-sm">
            <p className="font-medium text-sky-200 flex items-center gap-2"><Trophy className="h-4 w-4" /> Next bonus</p>
            <p className="text-sky-100/80 text-xs mt-1">
              <strong>{status.nextBonus.label}.</strong> {status.nextBonus.description}
            </p>
          </div>
        )}
        {status.badges && status.badges.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {status.badges.map((b) => (
              <Badge key={b.code} variant="ice" className="text-xs">{b.label}</Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 rounded-md border border-white/10 bg-white/[0.02]">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-lg font-bold mt-0.5">{value}</div>
    </div>
  );
}

function StreakCalendar({ status }: { status: StatusPayload | null }) {
  const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const streak = status?.currentStreak ?? 0;
  const todayIdx = (new Date().getDay() + 6) % 7;
  return (
    <Card>
      <CardContent className="pt-6 space-y-3">
        <h3 className="font-display text-lg font-bold flex items-center gap-2"><Sparkles className="h-5 w-5 text-sky-300" /> Streak</h3>
        <div className="grid grid-cols-7 gap-1.5">
          {DAYS.map((d, i) => {
            const isToday = i === todayIdx;
            const isClaimed = i < todayIdx ? streak > 0 : false;
            const isTodayClaimed = i === todayIdx && status?.hasSpun;
            return (
              <div
                key={i}
                className={[
                  'aspect-square rounded-md flex flex-col items-center justify-center text-[10px] font-semibold',
                  isTodayClaimed
                    ? 'bg-gradient-to-br from-emerald-600/40 to-sky-500/30 border border-emerald-400/50 text-white'
                    : isClaimed
                    ? 'bg-gradient-to-br from-violet-600/30 to-violet-500/20 border border-violet-400/30 text-white'
                    : isToday
                    ? 'border border-sky-400/60 text-white bg-sky-400/10'
                    : 'border border-white/10 text-muted-foreground',
                ].join(' ')}
              >
                {i + 1}
                <span className="text-[8px] mt-0.5 opacity-70">{d}</span>
              </div>
            );
          })}
        </div>
        <p className="text-xs text-muted-foreground">Resets if you skip a day (unless you have a Streak Freeze).</p>
      </CardContent>
    </Card>
  );
}

function LeaderboardPanel({ leaderboard }: { leaderboard: LeaderboardPayload | null }) {
  if (!leaderboard) return null;
  return (
    <Card>
      <CardContent className="pt-6 space-y-3">
        <h3 className="font-display text-lg font-bold flex items-center gap-2"><Users className="h-5 w-5 text-sky-300" /> Recent winners</h3>
        <ul className="text-sm space-y-1.5">
          {leaderboard.recent.length === 0 ? (
            <li className="text-muted-foreground text-xs">No spins yet — be the first.</li>
          ) : leaderboard.recent.map((r, i) => (
            <li key={i} className="flex items-center justify-between border-b border-white/5 pb-1.5">
              <span className="font-mono text-xs">{r.address}</span>
              <span className="text-xs">{r.prizeLabel}</span>
              <span className="text-xs text-muted-foreground">×{r.streak}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

function ResultModal({ result, onClose }: { result: SpinResult; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/85 backdrop-blur-sm p-4" onClick={onClose}>
      <Card className="max-w-md w-full relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="absolute inset-0 pointer-events-none opacity-30 bg-[radial-gradient(circle_at_top,rgba(168,85,247,0.4),transparent_60%)]" />
        <CardContent className="pt-8 text-center space-y-3 relative">
          <Sparkles className="h-10 w-10 mx-auto text-sky-300" />
          <h3 className="font-display text-2xl font-bold">You won</h3>
          <p className="font-display text-3xl font-bold grad-text">{result.prize.label}</p>
          <p className="text-sm text-muted-foreground">{result.prize.description}</p>
          <div className="p-3 rounded-md border border-white/10 bg-white/[0.02] text-xs text-muted-foreground flex items-start gap-2">
            <ShieldCheck className="h-4 w-4 mt-0.5 shrink-0" />
            <p>{result.prize.disclosure}</p>
          </div>
          {result.bonus && (
            <div className="p-3 rounded-md border border-amber-500/30 bg-amber-500/5 text-sm">
              <p className="font-medium text-amber-200 flex items-center justify-center gap-1.5"><Trophy className="h-4 w-4" /> Streak bonus: {result.bonus.label}</p>
              <p className="text-xs text-amber-100/80 mt-1">{result.bonus.description}</p>
            </div>
          )}
          <div className="text-xs text-muted-foreground">
            Streak: {result.streak.current} day{result.streak.current === 1 ? '' : 's'}
            {result.streak.wasReset && ' (reset today)'}
          </div>
          <div className="flex gap-2 justify-center pt-2">
            <Button variant="ice" onClick={onClose}>Done</Button>
            <Button variant="ghost" onClick={shareResult}><Copy className="h-4 w-4 mr-1" /> Share</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function shareResult() {
  if (typeof navigator === 'undefined') return;
  navigator.clipboard?.writeText('I just spun the CrystalFlakCoin daily wheel — no deposit, no risk, just fun. https://crystalflakcoin.example/daily-prize');
}
