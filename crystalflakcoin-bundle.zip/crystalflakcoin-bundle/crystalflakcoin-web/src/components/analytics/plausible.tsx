'use client';

/**
 * Plausible Analytics — privacy-friendly, cookie-free, GDPR/CCPA compliant.
 *
 * - Only loads when `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set (no-op otherwise)
 * - No cookies, no personal data, no cross-site tracking
 * - Free for sites under 10k pageviews/month
 * - Self-hostable (set NEXT_PUBLIC_PLAUSIBLE_SCRIPT to your instance URL)
 *
 * Reference: https://plausible.io/docs
 */
import Script from 'next/script';
import { useEffect } from 'react';
import { env } from '@/lib/env';

interface PlausibleProps {
  domain?: string;
  scriptSrc?: string;
  manualPageviews?: boolean;
}

export function Plausible({ domain, scriptSrc, manualPageviews }: PlausibleProps) {
  const targetDomain = domain || env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
  const targetScript = scriptSrc || env.NEXT_PUBLIC_PLAUSIBLE_SCRIPT || 'https://plausible.io/js/script.js';
  const enabled = env.NEXT_PUBLIC_ANALYTICS_ENABLED !== false;

  // Suppress unused import warning when Script isn't rendered.
  useEffect(() => {}, []);

  if (!enabled || !targetDomain) return null;

  const dataAttrs: Record<string, string> = {
    'data-domain': targetDomain,
  };
  if (manualPageviews) dataAttrs['data-manual-pageview'] = 'true';

  return (
    <Script
      defer
      data-domain={targetDomain}
      src={targetScript}
      strategy="afterInteractive"
      data-manual-pageview={manualPageviews ? 'true' : undefined}
    />
  );
}

/**
 * Server-safe pageview trigger for use in event handlers.
 * Useful when NEXT_PUBLIC_ANALYTICS_MANUAL is true.
 */
export function trackPageview(path?: string) {
  if (typeof window === 'undefined') return;
  const w = window as unknown as { plausible?: (event: string, opts?: { u?: string }) => void };
  if (typeof w.plausible === 'function') {
    w.plausible('pageview', { u: path || window.location.href });
  }
}
