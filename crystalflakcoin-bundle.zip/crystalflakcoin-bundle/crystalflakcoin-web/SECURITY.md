# Security Policy — CrystalFlakCoin (CFC) Web Platform

This document describes how to report security issues to the CrystalFlakCoin
project, what is and is not in scope, and the security controls that are
already in place in this codebase. It is written to be accurate, not
promotional: where a control is partial or has caveats, those are stated.

The web platform is the Next.js 14 application in this repository. It is the
read-only dashboard, marketing site, and admin panel. It does **not** host
the on-chain token contract; smart-contract issues are out of scope for the
file-based intake described here (see [Scope](#scope) below).

---

## 1. Supported versions

The project is in pre-release (`package.json` version `0.1.0`) and is being
prepared for an initial public deployment. Versioning follows semver
intent, but the first production tag has not been cut yet.

| Version | Supported                                          |
| ------- | -------------------------------------------------- |
| `main`  | Yes — the default branch receives security updates  |
| latest tagged release | Yes, until the next release supersedes it |
| any branch / commit older than 30 days | No, best-effort only |
| forks and unofficial builds | Not supported |

Until a stable `1.0.0` is published, treat every release as a moving target
and pin your deployments to a specific commit hash. There is **no** long-term
support branch and no extended-support commitment.

---

## 2. Reporting a vulnerability

### Contact

Email: **${NEXT_PUBLIC_SECURITY_EMAIL}**

> **Placeholder.** The `NEXT_PUBLIC_SECURITY_EMAIL` value in
> `.env.example` is set to `security@CHANGE_ME`. Until a real address is
> configured in the deployment environment, treat the placeholder as
> unpublished and reach out via the public report form below or open a
> private issue on the project's GitHub mirror. Once the operator fills in
> `NEXT_PUBLIC_SECURITY_EMAIL`, the rendered address on the public site is
> the canonical contact.

### Public report form (preferred for non-sensitive issues)

`POST /api/security-report` — see `src/app/api/security-report/route.ts`.

- Validated with the `SecurityReportSchema` Zod schema in
  `src/lib/validation.ts`.
- Rate-limited to 3 submissions per IP per hour
  (`src/lib/rate-limit.ts`).
- Stored in the `SecurityReport` table (`prisma/schema.prisma`) and
  surfaced in the admin panel at `/admin/security`.

For sensitive issues (e.g. exploitable bug with user impact), prefer email
or GitHub's private vulnerability reporting — do not post details publicly
before coordination.

### PGP / encryption

The project does not currently publish a PGP key. If your report includes
sensitive data (proof-of-concept exploit payloads, private telemetry, etc.),
send it in a password-protected archive and share the password out-of-band.
The team will treat the contents as confidential regardless of channel.

### What to include

A useful report contains:

1. The affected component (web route, API endpoint, admin page, header
   value, model, or feature flag).
2. A reproducible description or proof-of-concept.
3. The impact you believe it has and the affected user population
   (anonymous visitor, authenticated admin, etc.).
4. Whether the issue is currently being exploited.
5. Your preferred name/alias and contact method for follow-up questions
   and acknowledgement (see [Hall of Fame](#hall-of-fame)).

---

## 3. What to expect — response and disclosure

These are commitments, not aspirations. The team will communicate when any
of them cannot be met.

| Stage                      | Target / policy                                                           |
| -------------------------- | ------------------------------------------------------------------------- |
| Acknowledgement            | Within **5 business days** of receipt                                     |
| Triage decision            | Within **10 business days** of acknowledgement                            |
| Fix or mitigation for High / Critical | Best-effort, typically within **30 days**; tracked in `SecurityReport.status` |
| Fix or mitigation for Low / Medium   | Best-effort, typically within **90 days**                      |
| Public disclosure         | After a fix is released, or **90 days** after acknowledgement, whichever is sooner |
| Extensions                 | Available on request if a fix requires upstream coordination               |
| Good-faith compliance      | We will not pursue legal action against researchers acting in good faith  |

The project follows **coordinated disclosure**. Do not publish details,
exploit code, or screen captures of an unpatched issue before the agreed
disclosure date. The team will credit reporters in the
[Hall of Fame](#hall-of-fame) on request; tell us if you would prefer to
remain anonymous.

If a report is determined to be out of scope, not a security issue, or a
duplicate, the team will explain the reasoning.

---

## 4. Scope

### In scope

- This repository and any deployment of the same commit hash.
- Web application bugs in the Next.js App Router, including server
  components, server actions, and client components
  (`src/app/...`).
- API routes under `src/app/api/**` (e.g. `/api/security-report`,
  `/api/health`, `/api/admin/**`, `/api/auth/**`, `/api/csrf/**`).
- Admin panel authentication, session, CSRF, and authorization logic
  (`src/middleware.ts`, `src/lib/auth.ts`, `src/lib/csrf.ts`,
  `src/app/admin/**`).
- Server-side request handling, including header injection, request
  smuggling, and Open Redirect.
- Database interaction through Prisma (`src/lib/prisma.ts`,
  `prisma/schema.prisma`).
- Wallet / SIWE flows implemented in this repository
  (`src/lib/auth.ts::verifySiwe`).
- Security-relevant configuration in `next.config.mjs`, `src/lib/env.ts`,
  `Dockerfile`, `docker-compose.yml`, and CI workflows.
- The legacy-brand scanner (`scripts/legacy-brand-scan.mjs`) and its
  deny-list in `src/lib/brand.ts` (anything that could weaken the
  prohibition on legacy terms or misleading financial claims).
- Information disclosure via headers, error pages, source maps, or
  default error responses.

### Out of scope

The following are explicitly **not** covered by this policy. Where
possible, links or pointers are given, but the team will generally close
these as `wontfix` without further action.

- **Smart-contract issues.** The token contract is not yet deployed and is
  not part of this repository. When a contract is published, a separate
  disclosure channel will be announced. Until then, on-chain bugs are out
  of scope here.
- **Volumetric / denial-of-service attacks** against the hosted
  application or its upstream providers. The team relies on the hosting
  platform for DDoS mitigation; please report only application-level
  resource-exhaustion bugs.
- **Social engineering, phishing, or impersonation** of the project or
  its contributors.
- **Vulnerabilities in third-party services** the project depends on but
  does not operate (WalletConnect Cloud, public RPC providers, Etherscan,
  email/transaction-relay services, hosting platform, etc.). Please
  report those upstream.
- **Browser extension or end-user device issues** (malicious wallets,
  compromised seed phrases, clipboard hijacking by other extensions).
- **Loss of funds** caused by user error (signing a malicious transaction,
  sending tokens to a wrong address, falling for a scam). The web app
  never holds custody and cannot reverse on-chain transactions.
- **Best-practice suggestions that are not exploitable** (e.g. "please
  add a new HTTP header", "consider tightening this rate-limit value").
  These are welcome as regular issues, not security reports.
- **Automated scanner output with no demonstrated impact** (e.g. a single
  flagged dependency without a known exploit path). The team will close
  these as `wontfix` until an exploit is shown.
- **Vulnerabilities only present in development builds** that the build
  pipeline (`npm run build` → `scripts/legacy-brand-scan.mjs` →
  `next build`) would prevent from shipping.

---

## 5. Security features already in place

This is a description of controls that exist in the code today, not a
marketing list. Each item includes a path or file so you can verify it.

### Transport and browser hardening

Set in `next.config.mjs` and applied to every response:

- **Content-Security-Policy** — `default-src 'self'`, `frame-ancestors 'none'`,
  `base-uri 'self'`, `form-action 'self'`, with explicit allowances for
  WalletConnect, Google Fonts, and `connect-src https: wss:`.
  *Caveat:* the policy still includes `'unsafe-inline'` and `'unsafe-eval'`
  in `script-src` to keep RainbowKit/wagmi tooling functional. A stricter
  CSP is on the roadmap.
- **Strict-Transport-Security** — `max-age=63072000; includeSubDomains;
  preload` on every response.
- **X-Frame-Options: DENY** and `frame-ancestors 'none'`.
- **X-Content-Type-Options: nosniff**.
- **Referrer-Policy: strict-origin-when-cross-origin**.
- **Permissions-Policy: camera=(), microphone=(), geolocation=()`.
- `X-DNS-Prefetch-Control: on`.
- `poweredByHeader: false` so the `X-Powered-By: Next.js` header is not
  emitted.
- `images.remotePatterns` is set to `https` only.

### Authentication and sessions

Implemented in `src/lib/auth.ts` using `iron-session` and `argon2`:

- **Argon2id** (`argon2.hash(plain, { type: argon2.argon2id })`) for
  password hashing.
- **iron-session** for server-side session storage. Cookies are
  `httpOnly: true`, `sameSite: 'lax'`, `secure: true` in production.
- **SIWE (Sign-In With Ethereum)** verification on the server
  (`verifySiwe`) — only signed messages are accepted, never private keys
  or seed phrases.
- Session TTL is `SESSION_TTL_SECONDS` (default 86 400 s = 24 h).
- The session secret is enforced to be **at least 32 characters** by the
  startup-time Zod validator in `src/lib/env.ts`.
- Edge-level gate at `src/middleware.ts` redirects unauthenticated
  requests on `/admin/**` (except `/admin/login`) to the login page; the
  Node-side route handlers re-validate the session.

### CSRF

- Double-submit cookie CSRF, implemented in `src/lib/csrf.ts`.
- The server issues a 32-byte random token (`generateCsrfToken` in
  `src/lib/auth.ts`), stores it in the session, and the client must echo
  it in the `X-CSRF-Token` header. The server uses a constant-time
  comparison.
- `SameSite=Lax` on the session cookie is the second line of defence.

### Rate limiting

- Implemented in `src/lib/rate-limit.ts`.
- **In-memory sliding window** for single-process development.
- **Upstash Redis** sliding window when `RATE_LIMIT_PROVIDER=upstash` and
  credentials are configured. Falls back to in-memory if Upstash is
  unreachable.
- *Caveat:* the in-memory store is per-process. In a multi-replica
  deployment without Upstash, the limit becomes per-replica, not global.
  Production deployments should configure Upstash.
- Per-IP keying (`clientKeyFromRequest`) using `x-forwarded-for` and
  `x-real-ip`. Behind a misconfigured proxy this can be spoofed.
- Applied to the security-report endpoint at 3 requests / IP / hour
  (`src/app/api/security-report/route.ts`).

### Input validation

- **Zod** schemas in `src/lib/validation.ts` validate every API request
  body (token metadata, tokenomics, announcements, documentation,
  security reports, login, SIWE).
- Startup-time environment validation in `src/lib/env.ts` throws on
  missing or invalid `SESSION_PASSWORD`, `DATABASE_URL`,
  `NEXT_PUBLIC_APP_URL`, etc. in production.
- `AddressSchema` constrains EVM addresses to a basic format; the
  stricter check is done with `viem`'s EIP-55 utilities in
  `src/lib/chain-utils.ts::toChecksumAddress`.

### Database access

- **Prisma** is the only database access layer (`src/lib/prisma.ts`).
  All queries are generated by the Prisma client and use parameterised
  statements. There is no string concatenation of user input into
  raw SQL in the application code (the only raw query is
  `SELECT 1` in `src/app/api/health/route.ts`, with no user input).
- Schema is in `prisma/schema.prisma`; all models include `createdAt`
  and `updatedAt` for auditability, plus indexed fields where useful.

### Audit logging

- Append-only `AuditLog` model in `prisma/schema.prisma`.
- Helper in `src/lib/audit.ts` writes `{ userId, action, resource, ip,
  userAgent, metadata }`. It never logs secrets, signatures, or seed
  phrases. Failures are caught and printed to stderr so that audit
  problems do not break the user request.
- Surfaced in the admin panel at `/admin/logs`.
- The schema treats audit rows as write-once — there is no `update` or
  `delete` path exposed by the application.

### Wallet / Web3

- WalletConnect and RainbowKit are configured in `src/lib/wagmi.ts` with
  explicit `chains` allow-list (`mainnet`, `sepolia`).
- All on-chain calls performed by the server are **read-only by
  default** (`createPublicClient` in `src/lib/auth.ts::verifySiwe`).
  Transaction signing happens client-side in the user's wallet; the
  server never holds, asks for, or transmits private keys or seed
  phrases.
- EIP-55 address checksum validation is performed wherever an address
  is accepted (`src/lib/chain-utils.ts`, plus Zod format checks in
  `src/lib/validation.ts`).
- The `RandomnessConfig` table and `src/lib/randomness.ts` abstract the
  randomness source for the daily spin feature so it can be migrated to
  commit-reveal or Chainlink VRF without code changes.

### CI / supply-chain guardrails

- The **legacy-brand scanner** in `scripts/legacy-brand-scan.mjs`
  (mirrored from `src/lib/brand.ts`) runs in `prebuild` and as the
  first step of `npm run build`. It fails the build if any forbidden
  legacy term or misleading financial claim from the deny-list is
  found. This protects against accidental reintroduction of
  historical brand references and against unverified copy.
- The build pipeline is `prisma generate` → `legacy-brand-scan.mjs` →
  `next build` (see `package.json` "scripts").
- `prisma migrate deploy` is the documented production migration
  command (no schema drift in prod).

### Operational guardrails in code

- The bootstrap admin (`ADMIN_BOOTSTRAP_EMAIL` /
  `ADMIN_BOOTSTRAP_PASSWORD` in `src/lib/env.ts`) is a one-time
  convenience for the seed script. Production deployments must not
  set these and must rotate or remove the seeded account.
- `SecurityReport.details` is marked in the schema as the place where
  envelope-encrypted long-form content would live; the field accepts
  free text in the current code, so do not put secrets there in
  cleartext.

---

## 6. Operational security (for operators of this codebase)

This section is for the team deploying and running the application.

### Secret rotation

- `SESSION_PASSWORD` is the iron-session key. Rotating it invalidates
  every existing session. Plan rotations during low-traffic windows
  and expect all logged-in admins to be signed out.
- `DATABASE_URL` / `DIRECT_DATABASE_URL` should be rotated by
  double-writing (read replica first, then primary) and then cut over.
  Use the managed database provider's rotation tooling.
- `UPSTASH_REDIS_REST_TOKEN`, `SMTP_PASSWORD`, `ETHERSCAN_API_KEY` —
  rotate on the same cadence as any other production credential
  (suggested: every 90 days, immediately on personnel change).
- `NEXT_PUBLIC_*` values are exposed to the browser by design. Do not
  put any secret in a `NEXT_PUBLIC_*` variable; the build will not
  warn you.
- `.env` is in `.gitignore`; never commit it. The project ships
  `.env.example` as the only environment template. Treat
  `CHANGE_ME_*` placeholders as unconfigured.

### Admin role management

- The `Role` model (`prisma/schema.prisma`) supports named roles
  (`ADMIN`, `EDITOR`, `VIEWER`) and a `permissions String[]` field.
  The `requireAdmin` check in `src/lib/auth.ts` currently accepts only
  `role === 'ADMIN'`. A finer-grained permission check is a TODO.
- Add admins through the database, not by reusing the bootstrap
  credentials. The seed script (`prisma/seed.ts`) is the only
  legitimate creator of the first admin.
- Disable, do not delete, accounts when someone leaves. Set
  `emailVerified` to `null` and rotate the password.
- Enforce unique emails. The `User.email` column has `@unique`.
- Audit-log every admin write path; the `audit()` helper in
  `src/lib/audit.ts` is already called from the security-report
  route. Add an equivalent call to every new admin mutation.
- The `User` model has `mfaEnabled` / `mfaSecret` columns; enforcement
  is **not yet implemented in code** and must not be assumed.
  Track TOTP/SMS enrollment as a follow-up before exposing the admin
  panel to untrusted networks.

### Database backups and integrity

- The Prisma schema is the source of truth; back it up alongside the
  database dump so a restore can be re-applied via
  `npx prisma migrate deploy`.
- Recommended cadence: daily snapshot + transaction-log shipping for
  point-in-time recovery. Encrypt backups at rest; the keys live
  outside the database tier.
- Restores must be tested, not assumed. Schedule periodic restore
  drills against a non-production environment.
- The append-only `AuditLog` table is the forensic record for
  security incidents. Back it up separately if your retention policy
  exceeds the application's `SESSION_TTL_SECONDS`; do not let it be
  pruned by routine maintenance.
- `SecurityReport.details` is meant to hold envelope-encrypted
  content. Until KMS integration is wired up, treat it as
  cleartext-on-disk and apply table-level encryption at the database
  layer.

### Application configuration

- Run `npm run build` (which runs the legacy-brand scanner) before
  every release.
- Run `npm run typecheck`, `npm run lint`, `npm run test`, and
  `npm run test:e2e` as the release gate. See `package.json`
  `scripts.test:all`.
- Pin Node to the version in `package.json` `engines` (`>=18.18.0`).
  CI should use the same major.
- The Docker setup in `docker-compose.yml` is **for local
  development**. Production should use a managed Postgres and a
  hardened image built from the included `Dockerfile`.

---

## 7. Threat model summary

The project is designed to defend against the threats below and
explicitly does not defend against the ones it cannot.

### In scope of the design

- **Server-side request forgery, header injection, and response
  splitting** — mitigated by the security headers, the
  per-route Zod validation, and the allow-list approach to
  RPCs and external services.
- **Cross-site request forgery** on state-changing endpoints — CSRF
  tokens (`src/lib/csrf.ts`), `SameSite=Lax` cookies, and
  per-IP rate limiting.
- **Brute-force credential attacks** on the admin login — rate
  limiting and Argon2id cost (deliberately tuned for CPU work).
  *Partial:* account lockout is not implemented; the rate limit
  is the only backstop.
- **Session fixation and theft** — `httpOnly`, `Secure` (in
  production), `SameSite=Lax`, and iron-session's signed
  encrypted cookies.
- **Injection** (SQL, command, template) — Prisma parameterised
  queries and Zod input validation; no `eval`, no
  `dangerouslySetInnerHTML` on user input, no raw SQL
  concatenation.
- **Clickjacking** — `X-Frame-Options: DENY` and
  `frame-ancestors 'none'`.
- **Cross-origin leakage** via Referer — `Referrer-Policy:
  strict-origin-when-cross-origin`.
- **Unauthorised admin actions** — middleware gate at
  `src/middleware.ts` plus `requireAdmin` re-check in every admin
  route, plus audit log.
- **In-memory rate-limit resets on deploy** — by design; the
  Upstash backend is the durable option for production.
- **Reintroduction of legacy brand or misleading financial
  language** — denied at build time by the scanner.

### Explicitly out of scope of the design

- **On-chain security.** The web app does not custody funds and
  has no authority to pause, upgrade, or recover a deployed
  contract. Once a contract exists, its security is a separate
  problem.
- **User-side threats.** A user who signs a malicious transaction,
  pastes a seed phrase into a phishing site, or installs a
  malicious browser extension is outside the threat model. The
  application cannot prevent these; the README's risk disclosure
  covers them in prose.
- **Volumetric DDoS.** The project relies on the hosting platform
  for network-layer and L7 DDoS protection.
- **Compromise of third-party services.** WalletConnect Cloud, the
  RPC provider, Etherscan, and the SMTP relay are trusted
  dependencies. A breach of any of them is a breach of the
  application's trust boundary, not a bug in this codebase.
- **Nation-state / targeted intrusion.** Within the application's
  control: strong session secrets, TLS, parameterised queries, and
  audit logging. Beyond its control: 0-day exploits in dependencies
  and infrastructure compromise.
- **Insider risk** beyond the controls in [Section 6](#operational-security-for-operators-of-this-codebase).
  The application logs admin actions, but it cannot prevent a
  determined admin from misusing their own access.

---

## 8. Disclosure contact / security.txt

The project follows the `security.txt` convention (RFC 9116). The
canonical endpoint is:

```
https://<NEXT_PUBLIC_APP_URL>/.well-known/security.txt
```

The file is **not** present in the repository at the time of writing.
A static file at `public/.well-known/security.txt` should be added
before the first public deployment. Recommended contents (replace
placeholders before publishing):

```
# RFC 9116 — security.txt
Contact: mailto:${NEXT_PUBLIC_SECURITY_EMAIL}
Contact: https://github.com/CHANGE_ME/crystalflakcoin/security/advisories/new
Expires: 2026-12-31T23:59:59Z
Preferred-Languages: en
Canonical: https://<NEXT_PUBLIC_APP_URL>/.well-known/security.txt
```

Until that file is deployed, this `SECURITY.md` file, the
`POST /api/security-report` endpoint, and the
`${NEXT_PUBLIC_SECURITY_EMAIL}` environment value together form the
disclosure contact surface.

---

## Hall of Fame

This section acknowledges researchers who have followed this policy
and reported a verified security issue. It will be updated as reports
are triaged and resolved.

| Reporter                | Report          | Severity      | Status        |
| ----------------------- | --------------- | ------------- | ------------- |
| _no entries yet_        |                 |               |               |

If you would like to be acknowledged, include the name or alias you
would like to use in your report. If you prefer to remain anonymous,
the report is closed without an entry.

---

_Last updated: see the file's git history._
