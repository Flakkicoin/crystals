# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

> **Source-available license.** The license for this codebase is to be announced;
> until it is, treat the code as "all rights reserved" by the copyright holder and
> contact the maintainers before redistribution.

---

## [Unreleased]

### Added

- **Public site (13 pages):** Home, About, Token, Tokenomics, Ecosystem, Swap,
  Stake, Governance, Transparency, Docs, FAQ, Legal, Contact — each with explicit
  "not yet deployed" / "to be announced" placeholders where on-chain values are
  missing (see `src/app/page.tsx`, `src/app/about/page.tsx`, etc.).
- **Admin panel (9 pages):** sign-in, overview, token metadata, tokenomics
  allocations, content, announcements, security reports, audit log, and networks
  — guarded by `src/middleware.ts` and per-route RBAC.
- **Public API routes:** health, token, governance, security-report (rate-limited
  public submission), and the daily-prize surface (status, spin, history,
  leaderboard, draws, nonce, randomness).
- **Admin API routes:** token, tokenomics, and the daily-prize admin surface
  (catalog, randomness, raffle tiers, raffle draw, stats). All admin writes are
  CSRF-protected, Zod-validated, rate-limited, and audit-logged.
- **Daily Prize spin wheel** (`src/app/daily-prize/`, `src/lib/daily-prize.ts`):
  one free spin per UTC day with **server-enforced cooldowns**; the API rejects
  early re-spins with a structured cooldown payload. Prize probabilities are
  table-driven and read-only from the client.
- **Spin history** with **client-side verification**: each spin returns a signed
  server seed and a derived HMAC; the public history page re-derives the outcome
  in the browser so users can confirm the server's result is authentic.
- **Public leaderboard** (`/daily-prize/leaderboard`) with four sort modes:
  longest streak, raffle entries, points, and spins.
- **Raffle draw system** with **deterministic Fisher–Yates** selection
  (`src/lib/raffle-draw.ts`) seeded by the configured server randomness, so any
  past draw can be reproduced from the stored seed.
- **Streak milestones** with shareable cards: Bronze Supporter (3-day streak),
  Silver Supporter (7-day), Gold Supporter (30-day), and Founder's Circle
  (100-day). Each milestone is a persistent badge; the page exposes a copy-link
  helper for the share card.
- **Prisma schema** (`prisma/schema.prisma`) with **20 models**: `User`, `Role`,
  `Wallet`, `Announcement`, `DocumentationPage`, `TokenMetadata`,
  `TokenomicsAllocation`, `SupportedNetwork`, `GovernanceProposal`,
  `SecurityReport`, `AuditLog`, `DailySpin`, `SpinStreak`, `Badge`, `RaffleEntry`,
  `PrizeCatalogItem`, `RandomnessConfig`, `RaffleTier`, `RaffleDraw`,
  `RaffleWinner`. Every model includes `createdAt` / `updatedAt` for auditability.
- **Authentication & access control:**
  - **SIWE (Sign-In With Ethereum)** wallet authentication via `siwe` and `viem`.
  - **Email + password** admin login with Argon2id hashing and iron-session cookies
    (HTTP-only, `SameSite=Lax`, `Secure` in production).
  - **RBAC** roles (`ADMIN`, `EDITOR`, `VIEWER`) with per-route permission checks
    (`src/lib/auth.ts`).
  - **CSRF** protection on every state-changing request via double-submit cookie
    tokens (`src/lib/csrf.ts`).
  - **Rate limiting** — per-IP sliding window; in-memory in development and
    Upstash Redis in production (`src/lib/rate-limit.ts`).
  - **Audit logging** of every admin write to `AuditLog` (`src/lib/audit.ts`).
- **Security headers** configured in `next.config.mjs`:
  `Content-Security-Policy`, `Strict-Transport-Security`, `X-Frame-Options: DENY`,
  `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`,
  and a `Permissions-Policy` that disables camera, microphone, and geolocation.
- **Legacy-brand scanner** (`scripts/legacy-brand-scan.mjs`) — a CI gate that
  fails the build if any forbidden legacy term or misleading financial claim is
  present in the source tree. Wired into `prebuild`, `build`, and
  `npm run brand:scan`.
- **Tests:** **Jest** (31 tests passing across unit + integration), **Playwright**
  end-to-end (`tests/e2e/home.spec.ts`), and a smoke integration test against
  the public API surface. Run with `npm test` and `npm run test:e2e`.
- **Docker** support: `Dockerfile` and `docker-compose.yml` for local development
  and production. `docker compose up --build` brings up the web app and Postgres.
- **GitHub Actions** in `.github/workflows/`:
  - `ci.yml` — typecheck, lint, Jest, Playwright, brand scan, build.
  - `security-scan.yml` — dependency review and brand-scan on PRs and `main`.
  - `release.yml` — release pipeline (versioning and container image publish).
- **Documentation:**
  - `SECURITY.md` — supported versions, vulnerability reporting, response SLAs,
    scope, threat model, and `security.txt` policy.
  - `DEPLOYMENT.md` — pre-flight checklist, three deployment targets, database
    migration & seed, post-deploy verification, monitoring, backups, and
    rollback procedure.
  - `ADMIN_GUIDE.md` — first-time setup, signing in, every admin page, best
    practices, and a glossary.
  - `README.md` — quick start, project structure, scripts, security model, and
    risk disclosure.
- **`security.txt`** at `/.well-known/security.txt` (RFC 9116) with contact,
  expiry, preferred languages, and a canonical URL.

### Changed

- None yet — this is the first tracked release.

### Deprecated

- None.

### Removed

- None.

### Fixed

- None.

### Security

- See `SECURITY.md` for the supported-versions matrix and disclosure policy.

---

## [0.0.1] - YYYY-MM-DD — Initial scaffold

> The dates below are placeholders until a release is tagged. The intent is to
> record the pre-`Unreleased` history without inventing specific dates.

### Added

- Initial Next.js 14 + TypeScript + Tailwind project scaffold.
- Base shadcn/ui-style component library and theme.
- Empty `prisma/` directory and a placeholder Prisma schema.
- `package.json` with core dependencies pinned.
- `.env.example` documenting the required environment variables.
- `Dockerfile` and `docker-compose.yml` (no app code wired in yet).
- README skeleton.

---

## [0.0.0] - YYYY-MM-DD — Repository created

### Added

- Empty repository for the CrystalFlakCoin web platform.
- `.gitignore`, `.eslintrc.json`, and `tsconfig.json` baseline.
- Initial copyright header in `README.md`.

---

[Unreleased]: https://example.invalid/crystalflakcoin-web/compare/v0.0.1...HEAD
[0.0.1]: https://example.invalid/crystalflakcoin-web/compare/v0.0.0...v0.0.1
[0.0.0]: https://example.invalid/crystalflakcoin-web/releases/tag/v0.0.0
