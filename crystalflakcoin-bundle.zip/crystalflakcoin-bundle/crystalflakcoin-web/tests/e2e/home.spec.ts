import { test, expect } from '@playwright/test';

test('home page loads and shows brand', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('CrystalFlakCoin').first()).toBeVisible();
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
});

test('navigation contains all main pages', async ({ page }) => {
  await page.goto('/');
  for (const label of ['About', 'Token', 'Tokenomics', 'Governance', 'Transparency', 'Docs', 'FAQ', 'Risk']) {
    await expect(page.getByRole('link', { name: label }).first()).toBeVisible();
  }
});

test('legal page shows risk notice', async ({ page }) => {
  await page.goto('/legal');
  await expect(page.getByText('Risk summary')).toBeVisible();
  await expect(page.getByText('Not financial advice')).toBeVisible();
});
