import { shortenAddress, toChecksumAddress } from '@/lib/chain-utils';

describe('chain-utils', () => {
  test('shortenAddress truncates to head and tail', () => {
    expect(shortenAddress('0x1234567890abcdef1234567890abcdef12345678')).toBe('0x1234…5678');
  });

  test('shortenAddress returns input when too short', () => {
    expect(shortenAddress('0xab')).toBe('0xab');
  });

  test('toChecksumAddress accepts valid lowercase', () => {
    const lower = '0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359';
    const cs = toChecksumAddress(lower);
    expect(cs).toBeTruthy();
    expect(cs!.startsWith('0x')).toBe(true);
  });

  test('toChecksumAddress rejects invalid', () => {
    expect(toChecksumAddress('0xZZZZ')).toBeNull();
  });
});
