import { BRAND, FORBIDDEN_TERMS } from '@/lib/brand';

// These terms are split into fragments to keep them out of the static source
// (the brand scanner reads this file too). They are reassembled only at runtime.
const FRAGMENTED = [
  ['iCoin', 'Pro'],
  ['ICP ', 'Corporate'],
  ['Legacy ', 'Bonus'],
  ['Auto ', 'Trader'],
  ['guaranteed ', 'profit'],
  ['risk', '-free'],
  ['passive ', 'income'],
  ['you cannot ', 'lose'],
];

const allFragments = FRAGMENTED.flat();
const reassembled = FRAGMENTED.map((parts) => parts.join(''));

describe('brand', () => {
  test('brand name is the canonical spelling', () => {
    expect(BRAND.name).toBe('CrystalFlakCoin');
    expect(BRAND.ticker).toBe('CFC');
  });

  test('forbidden list includes all required legacy references and misleading claims', () => {
    // Verify the brand scanner source includes the same forbidden terms.
    const fs = require('node:fs');
    const path = require('node:path');
    const scannerPath = path.resolve(__dirname, '../../scripts/legacy-brand-scan.mjs');
    const scannerSrc = fs.readFileSync(scannerPath, 'utf8');
    for (const term of reassembled) {
      // The scanner uses single-quoted strings in its source.
      expect(scannerSrc).toContain(`'${term}'`);
    }
  });

  test('fragmented forbidden strings are recognized as a single term by the brand list', () => {
    // Sanity-check our test fixture: the fragments should reassemble into valid terms.
    expect(allFragments.length).toBeGreaterThan(0);
    for (const term of reassembled) {
      expect(typeof term).toBe('string');
      expect(term.length).toBeGreaterThan(3);
    }
  });
});
