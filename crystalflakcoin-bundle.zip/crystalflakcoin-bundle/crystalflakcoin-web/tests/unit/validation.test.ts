import { TokenMetadataUpdateSchema, TokenomicsAllocationSchema, SecurityReportSchema } from '@/lib/validation';

describe('validation', () => {
  test('rejects bad contract addresses', () => {
    expect(TokenMetadataUpdateSchema.safeParse({ contractAddress: '0xnotanaddress' }).success).toBe(false);
  });

  test('accepts valid EIP-55 contract', () => {
    expect(TokenMetadataUpdateSchema.safeParse({ contractAddress: '0x' + 'a'.repeat(40) }).success).toBe(true);
  });

  test('rejects percentages out of range', () => {
    expect(TokenomicsAllocationSchema.safeParse({ category: 'x', label: 'X', percentage: 150, order: 0 }).success).toBe(false);
  });

  test('security report requires severity', () => {
    expect(SecurityReportSchema.safeParse({ title: 'a', description: 'b', severity: 'ultra' }).success).toBe(false);
  });
});
