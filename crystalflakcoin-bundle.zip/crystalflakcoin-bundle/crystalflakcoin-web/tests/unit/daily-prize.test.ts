import {
  PRIZE_CATALOG,
  TOTAL_WEIGHT,
  pickPrize,
  angleForIndex,
  spinAvailability,
  streakIsBroken,
  nextStreakBonus,
  utcDateString,
  STREAK_BONUSES,
} from '@/lib/daily-prize';

describe('daily prize', () => {
  test('prize weights sum to a positive total', () => {
    expect(TOTAL_WEIGHT).toBeGreaterThan(0);
    const sum = PRIZE_CATALOG.reduce((a, p) => a + p.weight, 0);
    expect(sum).toBe(TOTAL_WEIGHT);
  });

  test('every prize has a code, label, and disclosure', () => {
    for (const p of PRIZE_CATALOG) {
      expect(p.code.length).toBeGreaterThan(0);
      expect(p.label.length).toBeGreaterThan(0);
      expect(p.disclosure.length).toBeGreaterThan(0);
    }
  });

  test('no prize claims a guaranteed monetary value', () => {
    for (const p of PRIZE_CATALOG) {
      const blob = `${p.label} ${p.description} ${p.disclosure}`.toLowerCase();
      // No dollar amounts
      expect(blob).not.toMatch(/\$\d/);
      // No "guaranteed" or "real money" or "promise" language
      expect(blob).not.toMatch(/guaranteed/);
      expect(blob).not.toMatch(/real money/);
      expect(blob).not.toMatch(/real \$/);
      // Every prize must explicitly disclaim cash value (negated phrases are fine)
      const hasDisclaimedValue =
        blob.includes('non-monetary') ||
        blob.includes('no cash value') ||
        blob.includes('no monetary value') ||
        blob.includes('cosmetic') ||
        blob.includes('utility only');
      expect(hasDisclaimedValue).toBe(true);
    }
  });

  test('pickPrize returns a valid prize for any roll in [0, total)', () => {
    for (let i = 0; i < 100; i++) {
      const roll = Math.random() * TOTAL_WEIGHT;
      const { prize, index } = pickPrize(roll);
      expect(prize).toBeDefined();
      expect(index).toBeGreaterThanOrEqual(0);
      expect(index).toBeLessThan(PRIZE_CATALOG.length);
    }
  });

  test('pickPrize is approximately weight-faithful over 10k samples', () => {
    const samples = 10_000;
    const counts: Record<string, number> = {};
    for (let i = 0; i < samples; i++) {
      const roll = Math.random() * TOTAL_WEIGHT;
      const { prize } = pickPrize(roll);
      counts[prize.code] = (counts[prize.code] || 0) + 1;
    }
    for (const p of PRIZE_CATALOG) {
      const expected = (p.weight / TOTAL_WEIGHT) * samples;
      const actual = counts[p.code] || 0;
      // Allow 50% deviation — this is a smoke test, not a chi-square.
      // 50% is generous on purpose; the real distribution is server-enforced.
      const tolerance = Math.max(expected * 0.5, 2);
      expect(actual).toBeGreaterThanOrEqual(Math.max(0, expected - tolerance));
      expect(actual).toBeLessThanOrEqual(expected + tolerance);
    }
  });

  test('angleForIndex returns positive degrees', () => {
    for (let i = 0; i < PRIZE_CATALOG.length; i++) {
      expect(angleForIndex(i)).toBeGreaterThan(0);
    }
  });

  test('spinAvailability allows a fresh wallet to spin', () => {
    const a = spinAvailability(null, new Date());
    expect(a.canSpin).toBe(true);
    expect(a.cooldownRemainingMs).toBe(0);
  });

  test('spinAvailability blocks a wallet that spun today', () => {
    const today = utcDateString(new Date());
    const a = spinAvailability(today, new Date());
    expect(a.canSpin).toBe(false);
    expect(a.cooldownRemainingMs).toBeGreaterThan(0);
  });

  test('streakIsBroken: null is not broken, yesterday is not, day-before-yesterday is', () => {
    const today = utcDateString(new Date());
    const yesterday = utcDateString(new Date(Date.now() - 86_400_000));
    const dayBefore = utcDateString(new Date(Date.now() - 2 * 86_400_000));
    expect(streakIsBroken(null, today)).toBe(false);
    expect(streakIsBroken(yesterday, today)).toBe(false);
    expect(streakIsBroken(dayBefore, today)).toBe(true);
  });

  test('nextStreakBonus returns the next un-earned bonus', () => {
    // Streak 2 — no bonus yet
    expect(nextStreakBonus(2, [])).toBeNull();
    // Streak 3, none earned — Bronze is next
    expect(nextStreakBonus(3, [])?.code).toBe('BRONZE');
    // Streak 7, Bronze earned — Silver is next
    expect(nextStreakBonus(7, ['BRONZE'])?.code).toBe('SILVER');
    // Streak 30, all earned — none
    expect(nextStreakBonus(100, STREAK_BONUSES.map((b) => b.code))).toBeNull();
  });

  test('utcDateString returns YYYY-MM-DD format', () => {
    const s = utcDateString(new Date('2026-03-15T10:00:00Z'));
    expect(s).toBe('2026-03-15');
  });
});
