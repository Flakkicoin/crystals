/**
 * Tests for the raffle draw math.
 * The draw must:
 * - Be deterministic given a (seed, period, tierCode, index)
 * - Pick `numWinners` distinct wallets per tier
 * - Never exceed the available pool
 * - Always produce a 64-char hex server seed
 */
import { createHash } from 'node:crypto';

describe('raffle draw math', () => {
  test('hash of (seed:tier:index) is deterministic', () => {
    const seed = 'a'.repeat(64);
    const a = createHash('sha256').update(`${seed}:FOUNDER:0`).digest('hex');
    const b = createHash('sha256').update(`${seed}:FOUNDER:0`).digest('hex');
    expect(a).toBe(b);
  });

  test('different tierCodes produce different hashes for the same index', () => {
    const seed = 'a'.repeat(64);
    const a = createHash('sha256').update(`${seed}:FOUNDER:0`).digest('hex');
    const b = createHash('sha256').update(`${seed}:SILVER:0`).digest('hex');
    expect(a).not.toBe(b);
  });

  test('different indices produce different hashes for the same tier', () => {
    const seed = 'a'.repeat(64);
    const a = createHash('sha256').update(`${seed}:FOUNDER:0`).digest('hex');
    const b = createHash('sha256').update(`${seed}:FOUNDER:1`).digest('hex');
    expect(a).not.toBe(b);
  });

  test('roll is within [0, pool) for any hash', () => {
    const pool = 100;
    for (let i = 0; i < 100; i++) {
      const seed = Math.random().toString(16).slice(2).padEnd(64, '0');
      const h = createHash('sha256').update(`${seed}:TEST:0`).digest('hex');
      const roll = parseInt(h.slice(0, 8), 16) % pool;
      expect(roll).toBeGreaterThanOrEqual(0);
      expect(roll).toBeLessThan(pool);
    }
  });

  test('sampling without replacement: total winners <= pool size', () => {
    // Simulate the Fisher-Yates-style draw
    const pool = Array.from({ length: 50 }, (_, i) => `wallet-${i}`);
    const tier = { numWinners: 10 };
    const seed = 'a'.repeat(64);
    const remaining = [...pool];
    const winners: string[] = [];
    for (let i = 0; i < tier.numWinners && remaining.length > 0; i++) {
      const h = createHash('sha256').update(`${seed}:TIER:${i}`).digest('hex');
      const roll = parseInt(h.slice(0, 8), 16) % remaining.length;
      winners.push(remaining[roll]);
      remaining.splice(roll, 1);
    }
    expect(winners.length).toBe(tier.numWinners);
    // Winners are distinct
    expect(new Set(winners).size).toBe(winners.length);
    // All winners came from the original pool
    for (const w of winners) expect(pool).toContain(w);
  });

  test('drawing more winners than pool size caps at pool size', () => {
    const pool = ['a', 'b', 'c'];
    const tier = { numWinners: 10 };
    const seed = 'b'.repeat(64);
    const remaining = [...pool];
    const winners: string[] = [];
    for (let i = 0; i < tier.numWinners && remaining.length > 0; i++) {
      const h = createHash('sha256').update(`${seed}:TIER:${i}`).digest('hex');
      const roll = parseInt(h.slice(0, 8), 16) % remaining.length;
      winners.push(remaining[roll]);
      remaining.splice(roll, 1);
    }
    expect(winners.length).toBe(3); // capped at pool size
    expect(new Set(winners).size).toBe(3);
  });

  test('same seed produces same winners (idempotency)', () => {
    function runDraw(seed: string, pool: string[], numWinners: number) {
      const remaining = [...pool];
      const winners: string[] = [];
      for (let i = 0; i < numWinners && remaining.length > 0; i++) {
        const h = createHash('sha256').update(`${seed}:TIER:${i}`).digest('hex');
        const roll = parseInt(h.slice(0, 8), 16) % remaining.length;
        winners.push(remaining[roll]);
        remaining.splice(roll, 1);
      }
      return winners;
    }
    const seed = 'c'.repeat(64);
    const pool = Array.from({ length: 100 }, (_, i) => `wallet-${i}`);
    const a = runDraw(seed, pool, 5);
    const b = runDraw(seed, pool, 5);
    expect(a).toEqual(b);
  });
});
