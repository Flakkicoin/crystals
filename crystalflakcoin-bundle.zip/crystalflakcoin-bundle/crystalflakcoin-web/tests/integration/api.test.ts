/**
 * Integration tests for the public API.
 * Mocks the Prisma client so we don't require a live database.
 */

// Mock the prisma module before any imports that pull it in.
jest.mock('@/lib/prisma', () => ({
  prisma: {
    $queryRaw: jest.fn().mockResolvedValue([{ '?column?': 1 }]),
    tokenMetadata: {
      findFirst: jest.fn().mockResolvedValue({
        name: 'CrystalFlakCoin',
        symbol: 'CFC',
        decimals: 18,
        network: null,
        chainId: null,
        contractAddress: null,
        isDeployed: false,
        description: null,
      }),
    },
  },
}));

import { GET as healthGET } from '@/app/api/health/route';
import { GET as tokenGET } from '@/app/api/token/route';

describe('public api', () => {
  test('health endpoint returns a JSON shape', async () => {
    const res = await healthGET();
    const j = await res.json();
    expect(typeof j.status).toBe('string');
    expect(typeof j.timestamp).toBe('string');
  });

  test('token endpoint returns name and symbol', async () => {
    const res = await tokenGET();
    const j = await res.json();
    expect(j.name).toBe('CrystalFlakCoin');
    expect(j.symbol).toBe('CFC');
    expect(j.isDeployed).toBe(false);
  });
});
