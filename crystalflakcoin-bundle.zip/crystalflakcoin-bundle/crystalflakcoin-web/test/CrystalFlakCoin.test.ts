/**
 * CrystalFlakCoin — Smart contract tests.
 *
 * Run with: npx hardhat test
 *           npx hardhat test --network hardhat
 *
 * These tests cover the most important invariants:
 *  - Fixed supply is minted to the initial holder exactly once.
 *  - The initial holder can transfer tokens.
 *  - Holders can burn their own tokens, reducing total supply.
 *  - The owner can renounce ownership, making the contract immutable.
 *  - No mint function exists (verified by absence in ABI).
 *  - No fees, no pausing, no blacklist.
 */
import { expect } from 'chai';
import { ethers } from 'hardhat';
import { CrystalFlakCoin } from '../typechain-types';

const NAME = 'CrystalFlakCoin';
const SYMBOL = 'CFC';
const INITIAL_HOLDER = '0x1000000000000000000000000000000000000001';
const INITIAL_OWNER = '0x2000000000000000000000000000000000000002';
const ZERO = '0x0000000000000000000000000000000000000000';

describe('CrystalFlakCoin', () => {
  let cfc: CrystalFlakCoin;
  let deployer: any;
  let holder: any;
  let owner: any;

  beforeEach(async () => {
    [deployer, holder, owner] = await ethers.getSigners();

    const CfcFactory = await ethers.getContractFactory('CrystalFlakCoin');
    cfc = (await CfcFactory.connect(deployer).deploy(INITIAL_HOLDER, INITIAL_OWNER)) as unknown as CrystalFlakCoin;
    await cfc.waitForDeployment();
  });

  describe('metadata', () => {
    it('has the expected name and symbol', async () => {
      expect(await cfc.name()).to.equal(NAME);
      expect(await cfc.symbol()).to.equal(SYMBOL);
    });

    it('uses 18 decimals', async () => {
      expect(await cfc.decimals()).to.equal(18);
    });
  });

  describe('supply', () => {
    it('mints the entire fixed supply to the initial holder', async () => {
      const max = await cfc.MAX_SUPPLY();
      const holderBalance = await cfc.balanceOf(INITIAL_HOLDER);
      expect(holderBalance).to.equal(max);
      expect(await cfc.totalSupply()).to.equal(max);
      expect(await cfc.maxSupply()).to.equal(max);
    });

    it('has a fixed 1B supply', async () => {
      const max = await cfc.MAX_SUPPLY();
      expect(max).to.equal(ethers.parseUnits('1000000000', 18));
    });
  });

  describe('transfers', () => {
    it('allows the holder to transfer tokens', async () => {
      const amount = ethers.parseUnits('1000', 18);
      // Impersonate the initial holder to send tokens.
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_HOLDER]);
      const initialHolderSigner = await ethers.getSigner(INITIAL_HOLDER);
      await cfc.connect(initialHolderSigner).transfer(holder.address, amount);
      expect(await cfc.balanceOf(holder.address)).to.equal(amount);
    });

    it('emits a Transfer event', async () => {
      const amount = ethers.parseUnits('1000', 18);
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_HOLDER]);
      const initialHolderSigner = await ethers.getSigner(INITIAL_HOLDER);
      await expect(cfc.connect(initialHolderSigner).transfer(holder.address, amount))
        .to.emit(cfc, 'Transfer')
        .withArgs(INITIAL_HOLDER, holder.address, amount);
    });
  });

  describe('burning', () => {
    it('allows holders to burn their own tokens', async () => {
      const amount = ethers.parseUnits('1000', 18);
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_HOLDER]);
      const initialHolderSigner = await ethers.getSigner(INITIAL_HOLDER);
      await cfc.connect(initialHolderSigner).burn(amount);
      expect(await cfc.balanceOf(INITIAL_HOLDER)).to.equal(
        (await cfc.MAX_SUPPLY()) - amount,
      );
    });

    it('reduces total supply on burn', async () => {
      const amount = ethers.parseUnits('1000000', 18);
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_HOLDER]);
      const initialHolderSigner = await ethers.getSigner(INITIAL_HOLDER);
      await cfc.connect(initialHolderSigner).burn(amount);
      const max = await cfc.MAX_SUPPLY();
      expect(await cfc.totalSupply()).to.equal(max - amount);
    });
  });

  describe('ownership', () => {
    it('sets the initial owner correctly', async () => {
      expect(await cfc.owner()).to.equal(INITIAL_OWNER);
    });

    it('allows the owner to renounce', async () => {
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_OWNER]);
      const ownerSigner = await ethers.getSigner(INITIAL_OWNER);
      await expect(cfc.connect(ownerSigner).renounce())
        .to.emit(cfc, 'OwnershipRenounced')
        .withArgs(INITIAL_OWNER);
      expect(await cfc.owner()).to.equal(ZERO);
    });

    it('prevents non-owners from calling renounce', async () => {
      await expect(cfc.connect(holder).renounce()).to.be.revertedWithCustomError(
        cfc,
        'OwnableUnauthorizedAccount',
      );
    });

    it('makes the contract immutable after renounce', async () => {
      await ethers.provider.send('hardhat_impersonateAccount', [INITIAL_OWNER]);
      const ownerSigner = await ethers.getSigner(INITIAL_OWNER);
      await cfc.connect(ownerSigner).renounce();
      // After renounce, owner is zero address. Any further renounce() call should
      // fail because msg.sender is not the owner.
      await expect(cfc.connect(ownerSigner).renounce()).to.be.revertedWithCustomError(
        cfc,
        'OwnableUnauthorizedAccount',
      );
    });
  });

  describe('absence of admin gimmicks', () => {
    it('has no public mint function', async () => {
      // Typechain-generated ABI does not include `mint` (no _mint exposure).
      // Verify by attempting to call it — should revert (function doesn't exist).
      const fragment = cfc.interface.getFunction('mint');
      expect(fragment, 'mint() should not exist').to.equal(null);
    });

    it('has no pause function', async () => {
      const fragment = cfc.interface.getFunction('pause');
      expect(fragment, 'pause() should not exist').to.equal(null);
    });

    it('has no blacklist function', async () => {
      const fragment = cfc.interface.getFunction('setBlacklist');
      expect(fragment, 'setBlacklist() should not exist').to.equal(null);
    });

    it('has no fee / take fee function', async () => {
      const fragment = cfc.interface.getFunction('setFee');
      expect(fragment, 'setFee() should not exist').to.equal(null);
    });
  });

  describe('deployment invariants', () => {
    it('rejects zero address as initial holder', async () => {
      const CfcFactory = await ethers.getContractFactory('CrystalFlakCoin');
      await expect(CfcFactory.connect(deployer).deploy(ZERO, INITIAL_OWNER)).to.be.revertedWith(
        'CFC: initial holder is zero',
      );
    });

    it('rejects zero address as initial owner', async () => {
      const CfcFactory = await ethers.getContractFactory('CrystalFlakCoin');
      await expect(CfcFactory.connect(deployer).deploy(INITIAL_HOLDER, ZERO)).to.be.revertedWith(
        'CFC: initial owner is zero',
      );
    });
  });
});
