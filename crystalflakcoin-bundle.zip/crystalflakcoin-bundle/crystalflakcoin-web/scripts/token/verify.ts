/**
 * CrystalFlakCoin — Verification script (Etherscan + Sourcify).
 *
 * Usage:
 *   npx hardhat verify --network sepolia <DEPLOYED_ADDRESS> <INITIAL_HOLDER> <INITIAL_OWNER>
 *
 * Notes:
 *  - Etherscan verification requires an ETHERSCAN_API_KEY in your .env.
 *  - Sourcify verification is automatic if `sourcify.enabled = true` in hardhat.config.ts.
 *  - If you don't have an Etherscan API key, verify manually on https://sourcify.dev.
 */
import { run } from 'hardhat';

async function main() {
  const address = process.env.CFC_DEPLOYED_ADDRESS;
  const initialHolder = process.env.CFC_INITIAL_HOLDER;
  const initialOwner = process.env.CFC_INITIAL_OWNER;

  if (!address || !initialHolder || !initialOwner) {
    throw new Error(
      'Missing CFC_DEPLOYED_ADDRESS, CFC_INITIAL_HOLDER, or CFC_INITIAL_OWNER env vars.',
    );
  }

  console.log('Verifying CrystalFlakCoin on Etherscan...');
  try {
    await run('verify:verify', {
      address,
      constructorArguments: [initialHolder, initialOwner],
    });
    console.log('✅ Verified on Etherscan');
  } catch (err: any) {
    if (err.message?.includes('Already Verified')) {
      console.log('✅ Already verified on Etherscan');
    } else {
      console.error('❌ Etherscan verification failed:', err.message);
      console.log('Tip: Sourcify (https://sourcify.dev) verifies without an API key.');
    }
  }

  console.log('Verifying CrystalFlakCoin on Sourcify...');
  try {
    await run('verify:sourcify', { address });
    console.log('✅ Verified on Sourcify');
  } catch (err: any) {
    console.error('❌ Sourcify verification failed:', err.message);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
