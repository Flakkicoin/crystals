/**
 * CrystalFlakCoin — Read state from a deployed contract.
 *
 * Usage:
 *   npx hardhat run scripts/token/read.ts --network sepolia
 *
 * Required env vars:
 *   CFC_DEPLOYED_ADDRESS  — the deployed contract address
 */
import { ethers } from 'hardhat';

const MINIMAL_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function MAX_SUPPLY() view returns (uint256)',
  'function maxSupply() view returns (uint256)',
  'function owner() view returns (address)',
  'function DOMAIN_SEPARATOR() view returns (bytes32)',
];

async function main() {
  const address = process.env.CFC_DEPLOYED_ADDRESS;
  if (!address) {
    throw new Error('Missing CFC_DEPLOYED_ADDRESS env var.');
  }

  const cfc = new ethers.Contract(address, MINIMAL_ABI, ethers.provider);

  const [name, symbol, decimals, totalSupply, maxSupply, owner, domainSeparator] = await Promise.all([
    cfc.name(),
    cfc.symbol(),
    cfc.decimals(),
    cfc.totalSupply(),
    cfc.MAX_SUPPLY(),
    cfc.owner(),
    cfc.DOMAIN_SEPARATOR(),
  ]);

  const formattedSupply = ethers.formatUnits(totalSupply, decimals);
  const formattedMax = ethers.formatUnits(maxSupply, decimals);
  const pctRemaining = (Number(totalSupply) / Number(maxSupply)) * 100;

  console.log('CrystalFlakCoin (CFC) state');
  console.log('============================');
  console.log(`Address:            ${address}`);
  console.log(`Name:               ${name}`);
  console.log(`Symbol:             ${symbol}`);
  console.log(`Decimals:           ${decimals}`);
  console.log(`Max supply:         ${formattedMax}`);
  console.log(`Circulating supply: ${formattedSupply} (${pctRemaining.toFixed(2)}% of max)`);
  console.log(`Owner:              ${owner === ethers.ZeroAddress ? '(renounced — immutable)' : owner}`);
  console.log(`Domain separator:   ${domainSeparator}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
