/**
 * Direct solc compile test — bypasses hardhat's compiler downloader.
 * Used to verify the contract compiles in environments where hardhat
 * can't download the solc binary.
 */
import { readFileSync } from 'node:fs';
import * as path from 'node:path';
import solc from 'solc';

const CONTRACT_PATH = path.join(__dirname, '../../contracts/CrystalFlakCoin.sol');
const OZ_PATH = path.join(__dirname, '../../node_modules/@openzeppelin/contracts');

function findImports(importPath: string) {
  // Resolve @openzeppelin/... imports to node_modules/@openzeppelin/contracts/...
  if (importPath.startsWith('@openzeppelin/contracts/')) {
    const filePath = path.join(OZ_PATH, importPath.replace('@openzeppelin/contracts/', ''));
    try {
      return { contents: readFileSync(filePath, 'utf8') };
    } catch (e: any) {
      return { error: 'File not found: ' + filePath };
    }
  }
  return { error: 'Unknown import: ' + importPath };
}

async function main() {
  const source = readFileSync(CONTRACT_PATH, 'utf8');

  const input = {
    language: 'Solidity',
    sources: {
      'CrystalFlakCoin.sol': {
        content: source,
      },
    },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: {
        '*': {
          '*': ['abi', 'evm.bytecode.object'],
        },
      },
    },
  };

  const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));

  if (output.errors) {
    const fatal = output.errors.filter((e: any) => e.severity === 'error');
    const warnings = output.errors.filter((e: any) => e.severity === 'warning');

    if (warnings.length > 0) {
      console.log('Warnings:');
      for (const w of warnings) console.log('  ' + w.formattedMessage);
    }
    if (fatal.length > 0) {
      console.error('Errors:');
      for (const e of fatal) console.error('  ' + e.formattedMessage);
      process.exit(1);
    }
  }

  const contract = output.contracts['CrystalFlakCoin.sol']['CrystalFlakCoin'];
  if (!contract) {
    console.error('CrystalFlakCoin contract not found in output');
    process.exit(1);
  }

  console.log('✅ CrystalFlakCoin.sol compiled successfully');
  console.log(`Bytecode size: ${(contract.evm.bytecode.object.length / 2 - 1).toLocaleString()} bytes`);
  console.log(`ABI entries: ${contract.abi.length}`);
  console.log(`Functions: ${contract.abi.filter((x: any) => x.type === 'function').map((x: any) => x.name).join(', ')}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
