/**
 * CrystalFlakCoin — One-shot launch script.
 *
 * Combines deploy + verify + renounce in a single run. Intended to be the
 * final command in the project's launch checklist.
 *
 * Usage:
 *   npx hardhat run scripts/token/launch.ts --network sepolia
 *
 * Required env vars:
 *   DEPLOYER_PRIVATE_KEY   — funded deployer wallet
 *   CFC_INITIAL_HOLDER     — address that receives the 1B supply
 *   CFC_INITIAL_OWNER      — address that owns the contract (must equal deployer
 *                            if you want to renounce in the same script)
 *
 * Optional env vars:
 *   CFC_SKIP_VERIFY        — set to "true" to skip Etherscan verification
 *   CFC_SKIP_RENOUNCE      — set to "true" to skip ownership renouncement
 *   ETHERSCAN_API_KEY      — for Etherscan verification
 *
 * What this script does, in order:
 *   1. Deploys the contract with the supplied constructor args.
 *   2. Waits for the deployment receipt.
 *   3. Verifies the source on Sourcify (free, no API key needed).
 *   4. Verifies the source on Etherscan (free with API key, optional).
 *   5. Renounces ownership (only if the deployer is the initial owner).
 *   6. Writes the result to deployments/<network>.json with full provenance.
 *
 * After the script finishes:
 *   - Copy NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS from deployments/<network>.json
 *     into your Next.js .env
 *   - Redeploy the website
 *   - Announce the deployment through your normal channels
 */
import { ethers, run, network } from 'hardhat';
import { writeFileSync, mkdirSync } from 'node:fs';
import * as path from 'node:path';

async function main() {
  const initialHolder = process.env.CFC_INITIAL_HOLDER;
  const initialOwner = process.env.CFC_INITIAL_OWNER;
  const skipVerify = process.env.CFC_SKIP_VERIFY === 'true';
  const skipRenounce = process.env.CFC_SKIP_RENOUNCE === 'true';

  if (!initialHolder || !initialOwner) {
    throw new Error('Missing CFC_INITIAL_HOLDER or CFC_INITIAL_OWNER env vars.');
  }

  const [deployer] = await ethers.getSigners();
  const net = await ethers.provider.getNetwork();

  console.log('===========================================');
  console.log('CrystalFlakCoin (CFC) one-shot launch');
  console.log('===========================================');
  console.log(`Network:        ${network.name} (chainId ${net.chainId})`);
  console.log(`Deployer:       ${deployer.address}`);
  console.log(`Initial holder: ${initialHolder}`);
  console.log(`Initial owner:  ${initialOwner}`);
  console.log(`Initial supply: 1,000,000,000 CFC (1B, fixed)`);
  console.log('-------------------------------------------');

  // Step 1 — Deploy
  console.log('\n[1/5] Deploying contract...');
  const Cfc = await ethers.getContractFactory('CrystalFlakCoin');
  const cfc = await Cfc.deploy(initialHolder, initialOwner);
  await cfc.waitForDeployment();
  const address = await cfc.getAddress();
  const deployTx = cfc.deploymentTransaction();
  const receipt = await deployTx?.wait();
  console.log(`     ✅ Deployed at ${address}`);
  console.log(`     Tx: ${deployTx?.hash} (block ${receipt?.blockNumber})`);
  console.log(`     Gas used: ${receipt?.gasUsed?.toString()}`);

  // Step 2 — Verify on Sourcify
  if (!skipVerify) {
    console.log('\n[2/5] Verifying on Sourcify (free, no API key)...');
    try {
      await run('verify:sourcify', { address });
      console.log('     ✅ Verified on Sourcify');
    } catch (err: any) {
      console.log(`     ⚠️  Sourcify verification failed: ${err.message}`);
    }

    // Step 3 — Verify on Etherscan
    console.log('\n[3/5] Verifying on Etherscan (free with API key)...');
    try {
      await run('verify:verify', {
        address,
        constructorArguments: [initialHolder, initialOwner],
      });
      console.log('     ✅ Verified on Etherscan');
    } catch (err: any) {
      if (err.message?.includes('Already Verified')) {
        console.log('     ✅ Already verified on Etherscan');
      } else {
        console.log(`     ⚠️  Etherscan verification failed: ${err.message}`);
        console.log('     (skip — verify manually at https://sourcify.dev)');
      }
    }
  } else {
    console.log('\n[2-3/5] Skipped verification (CFC_SKIP_VERIFY=true)');
  }

  // Step 4 — Renounce ownership
  if (!skipRenounce) {
    console.log('\n[4/5] Renouncing ownership...');
    if (initialOwner.toLowerCase() !== deployer.address.toLowerCase()) {
      console.log(`     ⚠️  Initial owner (${initialOwner}) is not the deployer (${deployer.address}).`);
      console.log('     Skipping renounce — the owner must call renounce() themselves.');
    } else {
      try {
        const tx = await cfc.renounce();
        const r = await tx.wait();
        console.log(`     ✅ Renounced in tx ${r?.hash}`);
        console.log('     Contract is now fully immutable.');
      } catch (err: any) {
        console.log(`     ⚠️  Renounce failed: ${err.message}`);
      }
    }
  } else {
    console.log('\n[4/5] Skipped renounce (CFC_SKIP_RENOUNCE=true)');
  }

  // Step 5 — Write deployment artifact
  console.log('\n[5/5] Writing deployment artifact...');
  const deploymentsDir = path.join(__dirname, '../../deployments');
  mkdirSync(deploymentsDir, { recursive: true });
  const artifact = {
    network: network.name,
    chainId: Number(net.chainId),
    timestamp: new Date().toISOString(),
    contract: {
      name: 'CrystalFlakCoin',
      symbol: 'CFC',
      address,
      deployer: deployer.address,
      initialHolder,
      initialOwner,
      deployTxHash: deployTx?.hash,
      deployBlock: receipt?.blockNumber,
      gasUsed: receipt?.gasUsed?.toString(),
    },
    verification: {
      sourcify: !skipVerify,
      etherscan: !skipVerify,
    },
    renounced: !skipRenounce,
    abi: 'See contracts/CrystalFlakCoin.sol and artifacts/contracts/CrystalFlakCoin.sol/CrystalFlakCoin.json',
  };
  const artifactPath = path.join(deploymentsDir, `${network.name}.json`);
  writeFileSync(artifactPath, JSON.stringify(artifact, null, 2));
  console.log(`     💾 Saved to ${artifactPath}`);

  console.log('\n===========================================');
  console.log('✅ CrystalFlakCoin launched');
  console.log('===========================================');
  console.log(`Address:  ${address}`);
  console.log(`Network:  ${network.name} (chainId ${net.chainId})`);
  console.log(`Explorer: https://${network.name === 'sepolia' ? 'sepolia.' : ''}etherscan.io/address/${address}`);
  console.log('');
  console.log('Next steps:');
  console.log(`  1. Set NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS=${address}`);
  console.log(`  2. Set NEXT_PUBLIC_TOKEN_NETWORK=${network.name}`);
  console.log('  3. Redeploy the website (DEPLOY_FREE.md)');
  console.log('  4. Announce through your normal communication channels.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
