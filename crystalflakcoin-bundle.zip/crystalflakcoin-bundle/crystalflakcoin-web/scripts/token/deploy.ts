/**
 * CrystalFlakCoin — Deployment script.
 *
 * Usage:
 *   npx hardhat run scripts/token/deploy.ts --network sepolia
 *   npx hardhat run scripts/token/deploy.ts --network baseSepolia
 *   npx hardhat run scripts/token/deploy.ts --network base
 *   npx hardhat run scripts/token/deploy.ts --network optimism
 *
 * Required env vars (see .env.example):
 *   DEPLOYER_PRIVATE_KEY          — funded deployer wallet
 *   CFC_INITIAL_HOLDER            — address that receives the 1B supply
 *   CFC_INITIAL_OWNER             — address that owns the contract (call renounce() later)
 *
 * Optional:
 *   ETHERSCAN_API_KEY             — for Etherscan verification
 *   SEPOLIA_RPC_URL etc.          — custom RPC URLs
 *
 * After deployment:
 *   1. Verify on Sourcify (free, no API key):  npx hardhat verify --network <net>
 *   2. Save the deployed address in env:       NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS=0x...
 *   3. (Recommended) Renounce ownership:       cast send <addr> "renounce()" --from <owner>
 */
import { ethers } from 'hardhat';

async function main() {
  const initialHolder = process.env.CFC_INITIAL_HOLDER;
  const initialOwner = process.env.CFC_INITIAL_OWNER;

  if (!initialHolder || !initialOwner) {
    throw new Error(
      'Missing CFC_INITIAL_HOLDER or CFC_INITIAL_OWNER env vars. See DEPLOY_TOKEN_FREE.md.',
    );
  }
  if (initialHolder === ethers.ZeroAddress || initialOwner === ethers.ZeroAddress) {
    throw new Error('CFC_INITIAL_HOLDER and CFC_INITIAL_OWNER must not be the zero address.');
  }

  const [deployer] = await ethers.getSigners();
  const network = await ethers.provider.getNetwork();

  console.log('====================================');
  console.log('CrystalFlakCoin (CFC) deployment');
  console.log('====================================');
  console.log(`Network:        ${network.name} (chainId ${network.chainId})`);
  console.log(`Deployer:       ${deployer.address}`);
  console.log(`Initial holder: ${initialHolder}`);
  console.log(`Initial owner:  ${initialOwner}`);
  console.log(`Initial supply: 1,000,000,000 CFC (1B, fixed)`);
  console.log('------------------------------------');

  const balance = await ethers.provider.getBalance(deployer.address);
  console.log(`Deployer balance: ${ethers.formatEther(balance)} native`);

  const Cfc = await ethers.getContractFactory('CrystalFlakCoin');
  const cfc = await Cfc.deploy(initialHolder, initialOwner);
  await cfc.waitForDeployment();

  const address = await cfc.getAddress();
  const deployTx = cfc.deploymentTransaction();

  console.log('------------------------------------');
  console.log(`✅ CrystalFlakCoin deployed`);
  console.log(`Address:        ${address}`);
  console.log(`Deploy TX hash: ${deployTx?.hash}`);
  console.log(`Block explorer: https://${network.name === 'sepolia' ? 'sepolia.' : ''}etherscan.io/address/${address}`);
  console.log('------------------------------------');
  console.log('Next steps:');
  console.log(`1. npx hardhat verify --network ${network.name} ${address} ${initialHolder} ${initialOwner}`);
  console.log('2. Save the address as NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS in your .env');
  console.log(`3. Renounce ownership: cfc.renounce() (or use scripts/token/renounce.ts)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
