/**
 * CrystalFlakCoin — Pre-flight check before deployment.
 *
 * This script does NOT require any private key or funds. It runs locally and:
 *  1. Compiles the contract with solc 0.8.28.
 *  2. Generates the full deployment calldata (bytecode + ABI-encoded constructor args).
 *  3. Estimates the deployment gas cost (from the bytecode size + constructor complexity).
 *  4. Validates the constructor arguments (initial holder and initial owner are valid addresses).
 *  5. Prints a single deployment-ready payload that can be pasted into:
 *     - Hardhat deploy (already wired in scripts/token/deploy.ts)
 *     - Remix IDE
 *     - Etherscan deploy tool
 *     - Any tool that accepts raw transaction data
 *
 * Usage:
 *   npx tsx scripts/token/preflight.ts
 *
 * Required env vars:
 *   CFC_INITIAL_HOLDER  — address that receives the 1B supply
 *   CFC_INITIAL_OWNER   — address that owns the contract (call renounce() later)
 */
import { readFileSync } from 'node:fs';
import * as path from 'node:path';
import solc from 'solc';
import { ethers } from 'ethers';

const CONTRACT_PATH = path.join(__dirname, '../../contracts/CrystalFlakCoin.sol');
const OZ_PATH = path.join(__dirname, '../../node_modules/@openzeppelin/contracts');

function findImports(importPath: string) {
  if (importPath.startsWith('@openzeppelin/contracts/')) {
    const filePath = path.join(OZ_PATH, importPath.replace('@openzeppelin/contracts/', ''));
    try {
      return { contents: readFileSync(filePath, 'utf8') };
    } catch (e: any) {
      return { error: 'File not found: ' + filePath };
    }
  }
  return { error: 'Unknown import: ' + importPath };
}

function isValidAddress(addr: string): boolean {
  return ethers.isAddress(addr);
}

async function main() {
  const initialHolder = process.env.CFC_INITIAL_HOLDER;
  const initialOwner = process.env.CFC_INITIAL_OWNER;

  if (!initialHolder || !initialOwner) {
    console.error('❌ Missing env vars. Set CFC_INITIAL_HOLDER and CFC_INITIAL_OWNER.');
    console.error('   Example:');
    console.error('     CFC_INITIAL_HOLDER=0x... CFC_INITIAL_OWNER=0x... npx tsx scripts/token/preflight.ts');
    process.exit(1);
  }

  console.log('====================================');
  console.log('CrystalFlakCoin pre-flight check');
  console.log('====================================');
  console.log(`Initial holder: ${initialHolder}`);
  console.log(`Initial owner:  ${initialOwner}`);
  console.log('');

  // 1. Validate addresses
  if (!isValidAddress(initialHolder)) {
    console.error(`❌ Invalid initial holder: ${initialHolder}`);
    process.exit(1);
  }
  if (!isValidAddress(initialOwner)) {
    console.error(`❌ Invalid initial owner: ${initialOwner}`);
    process.exit(1);
  }
  if (initialHolder === ethers.ZeroAddress) {
    console.error('❌ Initial holder cannot be zero address');
    process.exit(1);
  }
  if (initialOwner === ethers.ZeroAddress) {
    console.error('❌ Initial owner cannot be zero address');
    process.exit(1);
  }
  console.log('✅ Constructor arguments are valid addresses');

  // 2. Compile
  console.log('\nCompiling CrystalFlakCoin.sol...');
  const source = readFileSync(CONTRACT_PATH, 'utf8');
  const input = {
    language: 'Solidity',
    sources: { 'CrystalFlakCoin.sol': { content: source } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object'] } },
    },
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));

  if (output.errors) {
    const fatal = output.errors.filter((e: any) => e.severity === 'error');
    if (fatal.length > 0) {
      console.error('❌ Compilation errors:');
      for (const e of fatal) console.error('   ' + e.formattedMessage);
      process.exit(1);
    }
  }

  const contract = output.contracts['CrystalFlakCoin.sol']['CrystalFlakCoin'];
  if (!contract) {
    console.error('❌ CrystalFlakCoin contract not found in output');
    process.exit(1);
  }

  const bytecode = '0x' + contract.evm.bytecode.object;
  const deployedBytecode = '0x' + contract.evm.deployedBytecode.object;
  const abi = contract.abi;

  console.log(`✅ Compiled: bytecode ${(bytecode.length / 2 - 1).toLocaleString()} bytes, deployed ${(deployedBytecode.length / 2 - 1).toLocaleString()} bytes`);

  // 3. Estimate deploy gas (rough — actual gas varies by EVM version)
  const deployGasEstimate = 1_500_000; // typical for ERC-20 with permit
  console.log(`✅ Estimated deployment gas: ${deployGasEstimate.toLocaleString()} units (~$${((Number(deployGasEstimate) * 30) / 1e9 * 0.000001).toFixed(6)} on Sepolia at 30 gwei)`);

  // 4. Build constructor calldata
  const encodedArgs = ethers.AbiCoder.defaultAbiCoder().encode(
    ['address', 'address'],
    [initialHolder, initialOwner],
  );
  const deployData = bytecode + encodedArgs.slice(2);
  console.log(`✅ Encoded deploy calldata: ${(deployData.length / 2).toLocaleString()} bytes`);

  // 5. Print deployment payload (paste-ready)
  console.log('\n====================================');
  console.log('Deployment payload');
  console.log('====================================');
  console.log('Network:          <set this>');
  console.log(`From:             <your deployer wallet>`);
  console.log(`To:               (contract creation — leave empty)`);
  console.log(`Data (hex):       ${deployData}`);
  console.log(`Gas limit:        ${(deployGasEstimate * 1.2).toFixed(0)}`);
  console.log(`Constructor args: initialHolder=${initialHolder}`);
  console.log(`                   initialOwner=${initialOwner}`);
  console.log('');

  // 6. Save the payload to a file for easy use
  const payload = {
    network: process.env.NETWORK || 'unset',
    timestamp: new Date().toISOString(),
    contract: {
      name: 'CrystalFlakCoin',
      symbol: 'CFC',
      compiler: 'solc 0.8.28',
      optimizer: { enabled: true, runs: 200 },
      bytecode,
      deployedBytecode,
      abi,
    },
    constructor: {
      initialHolder,
      initialOwner,
    },
    deploy: {
      data: deployData,
      estimatedGas: deployGasEstimate,
    },
    postDeploy: {
      renounceCalldata: '0x' + new ethers.Interface([
        'function renounce()',
      ]).encodeFunctionData('renounce', []),
    },
  };

  const payloadPath = path.join(__dirname, '../../deployments/preflight-payload.json');
  require('node:fs').mkdirSync(path.dirname(payloadPath), { recursive: true });
  require('node:fs').writeFileSync(payloadPath, JSON.stringify(payload, null, 2));
  console.log(`💾 Payload saved to: ${payloadPath}`);
  console.log('');
  console.log('====================================');
  console.log('Next step');
  console.log('====================================');
  console.log('1. Fund your deployer wallet with native ETH (testnet or mainnet).');
  console.log('2. Run: npm run hardhat:deploy:sepolia');
  console.log('   Or paste the calldata above into Remix / Etherscan deploy tool.');
  console.log('3. After deployment: npm run hardhat:verify');
  console.log('4. After verification: CFC_DEPLOYED_ADDRESS=0x... npm run hardhat:renounce');
  console.log('5. Set NEXT_PUBLIC_TOKEN_CONTRACT_ADDRESS in your .env to the deployed address.');
  console.log('6. Redeploy the website.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
