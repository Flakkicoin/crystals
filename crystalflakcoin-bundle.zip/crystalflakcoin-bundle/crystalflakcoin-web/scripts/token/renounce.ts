/**
 * CrystalFlakCoin — Renounce ownership script.
 *
 * After deployment, the recommended final step is to renounce ownership, which
 * makes the contract fully immutable. No admin function can be performed after
 * this call.
 *
 * Usage:
 *   npx hardhat run scripts/token/renounce.ts --network sepolia
 *
 * Required env vars:
 *   CFC_DEPLOYED_ADDRESS  — the deployed contract address
 */
import { ethers } from 'hardhat';

const MINIMAL_ABI = [
  'function owner() view returns (address)',
  'function renounce()',
];

async function main() {
  const address = process.env.CFC_DEPLOYED_ADDRESS;
  if (!address) {
    throw new Error('Missing CFC_DEPLOYED_ADDRESS env var.');
  }

  const [caller] = await ethers.getSigners();
  const cfc = new ethers.Contract(address, MINIMAL_ABI, caller);

  const currentOwner: string = await cfc.owner();
  console.log(`Contract owner: ${currentOwner}`);
  console.log(`Caller:         ${caller.address}`);

  if (currentOwner === ethers.ZeroAddress) {
    console.log('✅ Ownership already renounced — contract is immutable.');
    return;
  }

  if (currentOwner.toLowerCase() !== caller.address.toLowerCase()) {
    throw new Error('Caller is not the current owner. Aborting.');
  }

  console.log('Renouncing ownership...');
  const tx = await cfc.renounce();
  const receipt = await tx.wait();
  console.log(`✅ Renounced in tx ${receipt?.hash}`);
  console.log('Contract is now fully immutable.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
