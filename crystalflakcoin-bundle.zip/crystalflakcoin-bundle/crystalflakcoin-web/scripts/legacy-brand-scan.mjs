#!/usr/bin/env node
/**
 * CrystalFlakCoin — Legacy Brand Reference Scanner
 * -----------------------------------------------
 * Scans the entire project for forbidden legacy brand references
 * and misleading financial claims. Exits non-zero if any are found,
 * which causes `npm run build` to fail.
 *
 * Run with: `npm run brand:scan`
 * Add to CI: `node scripts/legacy-brand-scan.mjs`
 *
 * The forbidden list lives in src/lib/brand.ts as the single source of truth.
 * We re-declare it here to keep the scanner zero-dep and CI-runnable.
 */
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..');

const FORBIDDEN = [
  // legacy brand
  { term: 'iCoinPro', reason: 'legacy brand reference' },
  { term: 'ICP Corporate', reason: 'legacy brand reference' },
  { term: 'ICP corporate', reason: 'legacy brand reference' },
  { term: 'Legacy Bonus', reason: 'legacy brand reference' },
  { term: 'legacy bonus', reason: 'legacy brand reference' },
  { term: 'Auto Trader', reason: 'legacy brand reference' },
  { term: 'auto trader', reason: 'legacy brand reference' },
  { term: 'autotrader', reason: 'legacy brand reference' },
  { term: 'icoinpro', reason: 'legacy brand reference (lowercase)' },
  { term: 'icp-corp', reason: 'legacy brand reference' },
  // misleading financial claims
  { term: 'guaranteed profit', reason: 'misleading financial claim' },
  { term: 'risk-free', reason: 'misleading financial claim' },
  { term: 'passive income', reason: 'misleading financial claim' },
  { term: 'get rich', reason: 'misleading financial claim' },
  { term: 'best trading bot', reason: 'misleading financial claim' },
  { term: '97% win rate', reason: 'fabricated statistic' },
  { term: 'most powerful compensation plan', reason: 'misleading recruitment claim' },
  { term: 'earn by recruiting', reason: 'misleading recruitment claim' },
  { term: 'you cannot lose', reason: 'misleading financial claim' },
  { term: 'limited-time financial opportunity', reason: 'misleading financial claim' },
];

// Directories to scan
const SCAN_DIRS = ['src', 'prisma', 'public', 'tests', 'scripts', 'contracts', 'test', 'hardhat'];
// Files at the root to scan
const SCAN_FILES = ['README.md', 'package.json', 'next.config.mjs', 'tailwind.config.ts', 'hardhat.config.ts', 'DEPLOYMENT.md', 'DEPLOY_FREE.md', 'DEPLOY_TOKEN_FREE.md', 'SECURITY.md', 'ADMIN_GUIDE.md', 'BRAND_GUIDELINES.md', 'ANALYTICS.md', 'MONETIZATION.md', 'LAUNCH_PLAYBOOK.md'];
// Extensions to include
const INCLUDE_EXT = new Set([
  '.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs',
  '.json', '.md', '.mdx', '.css', '.html', '.txt',
  '.yml', '.yaml', '.toml', '.sol',
]);
// Directories to skip
const SKIP_DIRS = new Set(['node_modules', '.next', '.git', 'dist', 'out', 'coverage', 'playwright-report', 'test-results']);

async function* walk(dir) {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (SKIP_DIRS.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      yield* walk(p);
    } else if (e.isFile()) {
      const ext = path.extname(e.name).toLowerCase();
      if (INCLUDE_EXT.has(ext)) yield p;
    }
  }
}

async function scanFile(file) {
  const content = await fs.readFile(file, 'utf8');
  const lines = content.split(/\r?\n/);
  const violations = [];
  // Files that legitimately contain the forbidden list (scanner source, brand policy, etc.)
  const relPath = path.relative(ROOT, file);
  const SELF_EXCLUSION_FILES = new Set([
    'scripts/legacy-brand-scan.mjs',
    'src/lib/brand.ts',
    'DEPLOYMENT.md',
    'DEPLOY_FREE.md',
    'DEPLOY_TOKEN_FREE.md',
    'SECURITY.md',
    'BRAND_GUIDELINES.md',
    'MONETIZATION.md',
    'LAUNCH_PLAYBOOK.md',
    'ADMIN_GUIDE.md',
    'ANALYTICS.md',
  ]);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Skip the scanner source itself
    if (file.endsWith('legacy-brand-scan.mjs')) continue;
    // Skip the canonical brand list (it must contain the forbidden strings)
    if (file.endsWith(path.join('src', 'lib', 'brand.ts'))) continue;
    // Skip policy / docs files that legitimately reference the forbidden list
    if (SELF_EXCLUSION_FILES.has(relPath)) continue;
    for (const f of FORBIDDEN) {
      if (line.includes(f.term)) {
        violations.push({ file, line: i + 1, term: f.term, reason: f.reason, snippet: line.trim().slice(0, 200) });
      }
    }
  }
  return violations;
}

async function main() {
  const start = Date.now();
  const allFiles = [];
  for (const d of SCAN_DIRS) {
    const p = path.join(ROOT, d);
    try {
      await fs.access(p);
      for await (const f of walk(p)) allFiles.push(f);
    } catch { /* missing dir is fine */ }
  }
  for (const f of SCAN_FILES) {
    const p = path.join(ROOT, f);
    try { await fs.access(p); allFiles.push(p); } catch { /* missing */ }
  }

  const all = [];
  for (const f of allFiles) {
    const v = await scanFile(f);
    all.push(...v);
  }

  const elapsed = Date.now() - start;
  if (all.length === 0) {
    console.log(`[brand-scan] OK — scanned ${allFiles.length} files in ${elapsed}ms. No forbidden terms found.`);
    process.exit(0);
  }

  console.error(`[brand-scan] FAIL — found ${all.length} forbidden term(s) in ${allFiles.length} files (${elapsed}ms):\n`);
  for (const v of all) {
    console.error(`  ${v.file}:${v.line}  →  "${v.term}" (${v.reason})`);
    console.error(`    ${v.snippet}`);
  }
  console.error(`\n[brand-scan] Remove the forbidden terms above and re-run.`);
  console.error(`[brand-scan] If a term is a false positive (e.g. quoting the scanner source), update the scanner's self-exclusion list.`);
  process.exit(1);
}

main().catch((e) => {
  console.error('[brand-scan] unexpected error', e);
  process.exit(2);
});
