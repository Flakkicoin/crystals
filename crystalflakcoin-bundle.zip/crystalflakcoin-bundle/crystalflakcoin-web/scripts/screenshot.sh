#!/usr/bin/env bash
# CrystalFlakCoin — Screenshot helper
#
# Captures screenshots of all key public pages and saves them to
# `press/screenshots/` for use in marketing materials, listings, and
# press coverage.
#
# Requires:
#   - A running Next.js dev server at http://localhost:3000 (npm run dev)
#   - playwright installed (npm install -g playwright && playwright install chromium)
#
# Usage:
#   ./scripts/screenshot.sh                    # screenshots local dev server
#   BASE_URL=https://crystalflakcoin.example ./scripts/screenshot.sh
set -euo pipefail

BASE="${BASE_URL:-http://localhost:3000}"
OUT="press/screenshots"
mkdir -p "$OUT"

PAGES=(
  "/|home"
  "/about|about"
  "/token|token"
  "/tokenomics|tokenomics"
  "/ecosystem|ecosystem"
  "/governance|governance"
  "/transparency|transparency"
  "/docs|docs"
  "/faq|faq"
  "/legal|legal"
  "/contact|contact"
  "/connect|connect"
  "/daily-prize|daily-prize"
  "/press|press"
  "/donate|donate"
  "/sponsors|sponsors"
)

if ! command -v npx >/dev/null 2>&1; then
  echo "Error: npx not found. Install Node.js." >&2
  exit 1
fi

if ! command -v playwright >/dev/null 2>&1; then
  echo "Installing Playwright..."
  npm install --no-save playwright
  npx playwright install chromium
fi

echo "Capturing screenshots from $BASE into $OUT/ ..."

for entry in "${PAGES[@]}"; do
  path="${entry%%|*}"
  name="${entry##*|}"
  echo "  - $path -> $OUT/$name.png"
  npx playwright screenshot --viewport-size=1280,800 --full-page \
    --wait-for-timeout=1500 \
    "$BASE$path" "$OUT/$name.png" 2>&1 | grep -v "^$" || true
done

echo "Done. Screenshots saved to $OUT/."
