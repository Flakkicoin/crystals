# CrystalFlakCoin is now live on the web — without the parts that aren't

*A digital asset project goes from repository to deployed site. The token contract is still to be announced.*

**Date:** September 2026
**Author:** The CrystalFlakCoin Team
**Tags:** `launch` · `transparency` · `web3` · `digital-asset`

---

## What we built

A public website and admin panel for the CrystalFlakCoin (CFC) project, on Next.js 14, TypeScript, Tailwind, Prisma, and wagmi/viem. We are not claiming the project is finished. What is on the screen is the truth, including the parts that say "not yet" out loud.

In concrete terms:

- **A public website of fifteen routes** — `/`, `/about`, `/token`, `/tokenomics`, `/ecosystem`, `/swap`, `/stake`, `/governance`, `/transparency`, `/docs`, `/faq`, `/legal`, `/contact`, `/connect`, and `/daily-prize`. Every page that touches tokens, staking, or swapping has a co-located risk disclosure.
- **A role-gated admin panel** at `/admin`, with Argon2id password hashing, iron-session cookies, double-submit CSRF, per-IP rate limiting, Zod input validation, and an append-only audit log of every write.
- **A daily spin / prize feature** at `/daily-prize`, with the randomness source abstracted in a `RandomnessConfig` table so it can later migrate to commit-reveal or Chainlink VRF without code changes. Prizes are not yet disbursed; the page renders "not yet active" until they are.
- **A legacy-brand scanner** that walks the repository in CI and fails the build if anyone reintroduces a forbidden brand reference or a misleading financial claim. It runs on every `prebuild`, before `next build`, and before every test run.
- **A verified deployment** to https://9mqcfm3l5y3.space.minimax.io, accompanied by `DEPLOYMENT.md`, a `Dockerfile` + `docker-compose.yml` for local development, `SECURITY.md` covering the in-scope and out-of-scope controls, and an `ADMIN_GUIDE.md` for non-technical operators.

That is the entire scope of this launch. The site is the deliverable; the token is not.

## What's not built yet

We would rather list the missing pieces here than have you discover them on the site. The following are **to be announced**:

- **The CFC token contract itself.** The web platform is read-mostly; it has no authority to pause, upgrade, or recover a deployed contract. There is no on-chain contract to inspect yet, and the site says so on `/token` and `/transparency`.
- **The actual swap.** The `/swap` page is built and visible, but disabled by feature flag until a verified liquidity pool exists. No fake depth chart, no fake price.
- **The actual staking program.** The `/stake` page is built and visible, but disabled, and explicitly says "Staking is not yet available."
- **The audit report.** The transparency page renders "Not available" rather than waving at a PDF of unclear provenance. A real audit from a named firm will be linked when one exists.
- **A public multisig treasury with named signers.** Also not yet announced. The team is also not yet public.

These are features of the project, not bugs: "honest by design" means the things which do not yet exist are labeled, in the UI, as not yet existing.

## Why we built it this way

Most token sites have three tells: a fake APY, a fake partnership, and a "we never share your keys" disclaimer that is followed immediately by a custodial deposit flow. We have built a site with none of those.

The brand scanner is the most visible part of the discipline: if any contributor — including us — adds a sentence that drifts toward shadiness, the build fails. The risk-first disclosure policy sits beside it. Every page that touches tokens, staking, or swapping has a co-located risk disclosure, and the FAQ answers the questions we wish more projects would — no investment, no promised returns, no trading bot, no recruitment compensation.

The no-fake-stats policy is the third part. The platform has no live market data because there is nothing to measure yet, and the UI does not invent numbers. The five tokenomics buckets render as "Not configured" until configured, and the server rejects any allocation set whose percentages do not sum to exactly one hundred.

## How to try it

- **Live site:** https://9mqcfm3l5y3.space.minimax.io
- **Documentation:** https://9mqcfm3l5y3.space.minimax.io/docs
- **Source code:** the GitHub organization linked from `/transparency`

## How to verify

- **Security policy:** the in-repo `SECURITY.md` describes the in-scope controls, the response-time commitments, the explicit out-of-scope threats, and the disclosure contact.
- **Brand scanner:** `scripts/legacy-brand-scan.mjs` runs in `prebuild`; the deny-list is mirrored in `src/lib/brand.ts`. Run `npm run brand:scan` locally to reproduce.
- **Daily-prize / history verification:** https://9mqcfm3l5y3.space.minimax.io/daily-prize. The schema is designed so that, when randomness migrates on-chain, every historical spin remains verifiable against the on-chain commit.

## What's next

A short, honest list:

- **Token contract deployment** on Sepolia first, then Ethereum mainnet. The address will be published in `/transparency` the moment the deployment transaction confirms, and the contract source will be verified on a public block explorer.
- **A named audit** from a recognized firm, with a public report linked from `/transparency` and from `SECURITY.md`.
- **A multisig treasury** with named signers and a published threshold.
- **Raffle / prize draws** against verified on-chain randomness, only after the contract is deployed and the audit is in hand.

## Disclaimer

CrystalFlakCoin is a digital asset project. It is not an investment vehicle, securities offering, or financial product, and is not registered as a security in any jurisdiction. Nothing on this site is financial, investment, legal, or tax advice. Digital assets are volatile and subject to market, technical, regulatory, and operational risk; you may lose some or all of the value of any assets you hold. Never share your seed phrase or private key with anyone. Always verify contract addresses on a block explorer before interacting. Consult a qualified professional before acting.
